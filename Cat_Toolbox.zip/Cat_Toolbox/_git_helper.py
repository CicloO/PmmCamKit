"""Temporary helper to run git commands."""
import subprocess
import os
import sys

repo_dir = r"C:\Users\Romy\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\Cat_Toolbox"
os.chdir(repo_dir)

if len(sys.argv) < 2:
    print("Usage: python _git_helper.py <command>")
    sys.exit(1)

cmd = sys.argv[1]
if cmd == "status":
    result = subprocess.run(["git", "status"], capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)
elif cmd == "diff":
    result = subprocess.run(["git", "diff"], capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)
elif cmd == "diff-cached":
    result = subprocess.run(["git", "diff", "--cached"], capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)
elif cmd == "add":
    result = subprocess.run(["git", "add", "-A"], capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)
elif cmd == "commit":
    msg = sys.argv[2] if len(sys.argv) > 2 else "Update"
    result = subprocess.run(["git", "commit", "-m", msg], capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)
    print("RETURNCODE:", result.returncode)
else:
    print(f"Unknown command: {cmd}")
