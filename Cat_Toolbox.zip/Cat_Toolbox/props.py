"""Scene properties for Face/Eyes controller transfer."""

from __future__ import annotations

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import PropertyGroup

from .mapping import EYE_L_BONE_CANDIDATES, EYE_R_BONE_CANDIDATES, HEAD_BONE_CANDIDATES
from .placement import find_bone, guess_mmd_objects
from .rigify_compat import COMPAT_AUTO, COMPAT_ITEMS, effective_rigify_compat, is_rigify_compat_scene


class FaceEyesCtrlSettings(PropertyGroup):
    target_armature: PointerProperty(
        name="目标骨架",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == "ARMATURE",
    )
    target_mesh: PointerProperty(
        name="目标网格",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == "MESH",
    )
    head_bone: StringProperty(name="头部骨骼", default="頭")
    eye_l_bone: StringProperty(name="左眼球", default="目.L")
    eye_r_bone: StringProperty(name="右眼球", default="目.R")
    rigify_compat: EnumProperty(
        name="Rigify兼容",
        description="Rigify/MMR：将 Face 骨骼合并进 Rigify 骨架；普通模型仍用独立 Face_Rig",
        items=COMPAT_ITEMS,
        default=COMPAT_AUTO,
    )
    binding_mode: EnumProperty(
        name="绑定模式",
        description="不使用びっくり：取消びっくり，まばたき/笑い下限-0.2，使用工程文件表达式；使用びっくり：默认Morph驱动表达式（含びっくり）",
        items=[
            (
                "COMPAT",
                "不使用びっくり",
                "まばたき/笑い下限-0.2，取消びっくり，使用工程文件驱动表达式",
            ),
            ("STANDARD", "使用びっくり", "按原计划绑定（含びっくり驱动，默认Morph表达式）"),
        ],
        default="COMPAT",
    )
    jelly_mode: EnumProperty(
        name="果冻眼模式",
        description="配布用：使用形态键驱动（兼容性好）；自用：使用CTL骨骼驱动（响应更精准）",
        items=[
            ("DISTRIBUTE", "配布用", "使用形态键驱动（まばたき/笑い），适合配布给他人使用"),
            ("PERSONAL", "自用", "使用CTL骨骼驱动（CTL-eye_blink/CTL-eye_happy），需Face_Rig"),
        ],
        default="DISTRIBUTE",
    )
    last_report: StringProperty(name="上次结果", default="")


def auto_fill_settings(context) -> str:
    """Fill target settings from selection / scene."""
    s = context.scene.face_eyes_ctrl
    guessed = guess_mmd_objects(context)
    if guessed["armature"] and not s.target_armature:
        s.target_armature = guessed["armature"]
    if guessed["mesh"] and not s.target_mesh:
        s.target_mesh = guessed["mesh"]

    arm = s.target_armature
    if arm:
        h = find_bone(arm, HEAD_BONE_CANDIDATES)
        if h:
            s.head_bone = h
        el = find_bone(arm, EYE_L_BONE_CANDIDATES)
        if el:
            s.eye_l_bone = el
        er = find_bone(arm, EYE_R_BONE_CANDIDATES)
        if er:
            s.eye_r_bone = er

    compat = effective_rigify_compat(s.rigify_compat, arm)
    detected = is_rigify_compat_scene(arm) if arm else False
    mode_label = {"AUTO": "自动", "ON": "开", "OFF": "关"}.get(s.rigify_compat, s.rigify_compat)
    parts = [
        f"Arm={s.target_armature.name if s.target_armature else '?'}",
        f"Mesh={s.target_mesh.name if s.target_mesh else '?'}",
        f"Bones={s.head_bone}/{s.eye_l_bone}/{s.eye_r_bone}",
        f"Rigify兼容={mode_label}→{'是' if compat else '否'}"
        + (f"(检测{'到' if detected else '无'})" if s.rigify_compat == COMPAT_AUTO else ""),
    ]
    return "已推断: " + ", ".join(parts)


class CatCameraBakeProps(PropertyGroup):
    """MMD 相机烘焙的 UI 参数。"""
    scale: FloatProperty(
        name="缩放",
        default=0.08,
        min=0.001,
        step=10,
        description="初始化相机的缩放因子",
    )
    camera_source: EnumProperty(
        name="相机来源",
        items=[
            ("CURRENT", "当前相机", "使用当前选中相机"),
            ("SCENE", "场景相机", "使用场景相机"),
        ],
        default="CURRENT",
    )
    min_distance: FloatProperty(
        name="最小距离",
        default=0.1,
        min=0.001,
        step=10,
        description="相机到目标的最小距离（防止穿模）",
    )
    bake_mode: EnumProperty(
        name="关键帧方式",
        items=[
            ("ADAPTIVE", "自适应", "按画面误差自动选关键帧并拟合 VMD 曲线，自动识别切镜"),
            ("FIXED", "固定步长", "每隔 N 帧一个关键帧，线性插值（旧方式）"),
        ],
        default="ADAPTIVE",
    )
    precision_px: FloatProperty(
        name="精度(像素)",
        default=1.0,
        min=0.1,
        max=20.0,
        step=10,
        description="允许的画面跳动，按 1080p 画面高度的像素计。越小关键帧越多",
    )
    allow_negative: BoolProperty(
        name="允许负值曲线",
        default=True,
        description="VMD 曲线控制点可低于 0（原版 MMD 支持），拟合能力更强",
    )
    allow_step1: BoolProperty(
        name="允许步长1（仅30fps输出）",
        default=False,
        description=("同一镜头内允许相邻帧都是关键帧，快速运镜处更精确。"
                     "MMD 以 60fps 以上输出时会把相邻帧关键帧当成切镜，所以只能 30fps 输出"),
    )
    target_mode: EnumProperty(
        name="目标点",
        items=[
            ("AUTO", "自动", "选中的第二个物体 > 相机控制器的 Aim > 对焦物体 > MMD 角色（センター）"),
            ("NONE", "贴近相机", "目标点放在相机前最小距离处（旧方式）"),
        ],
        default="AUTO",
    )
    step: IntProperty(
        name="步长",
        default=2,
        min=1,
        description="每隔 N 帧采样一帧（1=逐帧烘焙）",
    )
    fov_integer: BoolProperty(
        name="视角取整补偿",
        default=True,
        description="VMD 视角只能存整数度：烘焙时取整，并用相机距离补偿误差，避免变焦镜头一卡一卡",
    )
    ref_depth: FloatProperty(
        name="补偿参考深度",
        default=0.0,
        min=0.0,
        step=10,
        unit="LENGTH",
        description="未选目标物体时，此深度处的画面大小保持不变。0=自动（世界原点在视线上的深度）",
    )


class VmdIOProps(PropertyGroup):
    """MMD 导入/导出 VMD 的 UI 参数。"""
    scale: FloatProperty(
        name="导入缩放",
        default=0.08,
        min=0.001,
        step=10,
        description="导入 VMD 动作的缩放因子（MMD 单位转 Blender）",
    )
    export_scale: FloatProperty(
        name="导出缩放",
        default=12.5,
        min=0.001,
        step=10,
        description="导出 VMD 动作的缩放因子（Blender 转 MMD 单位）",
    )
    use_NLA: BoolProperty(
        name="导入为NLA",
        default=False,
        description="将动作导入为 NLA 轨道而非直接套用",
    )
    use_pose_mode: BoolProperty(
        name="当前姿态作为T-Pose",
        default=False,
        description="以当前姿态作为动作的基准姿态（T-Pose / A-Pose 适配）",
    )
    use_mirror: BoolProperty(
        name="镜像动作",
        default=False,
        description="沿 X 轴镜像导入动作",
    )
    update_scene_settings: BoolProperty(
        name="更新场景设置",
        default=True,
        description="导入后自动更新帧范围与帧率（30fps）",
    )
    use_frame_range: BoolProperty(
        name="仅导出当前帧范围",
        default=False,
        description="只导出场景帧范围之内的动画",
    )
    hidden_armature_name: StringProperty(
        name="已隐藏骨骼",
        default="",
        description="一键导入流程中被隐藏的 MMD 骨骼名称",
    )
    last_report: StringProperty(name="上次结果", default="")


CLASSES = (FaceEyesCtrlSettings, CatCameraBakeProps, VmdIOProps)
