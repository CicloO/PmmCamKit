"""Build Face_Rig / Eyes_Rig with full parameter fidelity to 面部绑定_范例.blend."""

from __future__ import annotations

import json
from pathlib import Path

import bpy
from mathutils import Vector

from .rig_template import EYES_RIG_BONES, FACE_RIG_BONES, RIG_META

COL_EYES = "眼部控制器"
COL_FACE = "面部控制器"
COL_WGTS_EYES = "WGTS_Eyes_Rig"
COL_WGTS_FACE = "WGTS_Face_Rig"

FACE_WIDGET_KEYS = ("ring", "nichi", "den", "kou", "frame")
EYES_WIDGET_KEYS = ("eyes_master", "eye_l", "eye_r")

# Original widget object name → internal key used by rig_template custom_shape.widget
_WIDGET_NAME_TO_KEY = {
    "圆环": "ring",
    "日字格": "nichi",
    "田字格": "den",
    "口字格": "kou",
    "WGT-Face_Rig_LMT-eye_look.001": "frame",
    "WGT-rig_eyes": "eyes_master",
    "WGT-rig_eye.L": "eye_l",
    "WGT-rig_eye.R": "eye_r",
}

_WIDGET_MESH_CACHE: dict | None = None


def _load_widget_mesh_data() -> dict:
    global _WIDGET_MESH_CACHE
    if _WIDGET_MESH_CACHE is not None:
        return _WIDGET_MESH_CACHE
    path = Path(__file__).with_name("widget_meshes.json")
    _WIDGET_MESH_CACHE = json.loads(path.read_text(encoding="utf-8"))
    return _WIDGET_MESH_CACHE


def _ensure_child_collection(parent: bpy.types.Collection, name: str) -> bpy.types.Collection:
    for c in parent.children:
        if c.name == name:
            return c
    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
    if col.name not in [c.name for c in parent.children]:
        for sc in bpy.data.collections:
            if col.name in [c.name for c in sc.children]:
                sc.children.unlink(col)
        if col.name in [c.name for c in bpy.context.scene.collection.children]:
            bpy.context.scene.collection.children.unlink(col)
        parent.children.link(col)
    return col


def _ensure_scene_collection(name: str) -> bpy.types.Collection:
    scene_col = bpy.context.scene.collection
    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
        scene_col.children.link(col)
    elif col.name not in [c.name for c in scene_col.children]:
        linked = any(col.name in [c.name for c in p.children] for p in bpy.data.collections)
        if not linked:
            scene_col.children.link(col)
    return col


def _link_only(obj: bpy.types.Object, col: bpy.types.Collection):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    if obj.name not in col.objects:
        col.objects.link(obj)


def _make_mesh_object(name: str, verts, edges, faces=()) -> bpy.types.Object:
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(
        [tuple(v) for v in verts],
        [tuple(e) for e in edges],
        [tuple(f) for f in faces],
    )
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    obj.hide_viewport = True
    obj.hide_render = True
    return obj


def _create_widgets(suffix: str) -> dict[str, bpy.types.Object]:
    """Create widget meshes from exact geometry exported from 面部绑定_范例.blend."""
    data = _load_widget_mesh_data()
    widgets: dict[str, bpy.types.Object] = {}
    for obj_name, key in _WIDGET_NAME_TO_KEY.items():
        if obj_name not in data:
            raise RuntimeError(f"Missing widget mesh data: {obj_name}")
        md = data[obj_name]
        name = f"{obj_name}{suffix}" if suffix else obj_name
        widgets[key] = _make_mesh_object(name, md["verts"], md["edges"], md.get("faces") or ())
    return widgets


def _find_layer_collection(
    layer_coll: bpy.types.LayerCollection, target: bpy.types.Collection
):
    """递归查找 LayerCollection 树中与 target 对应的节点。"""
    if layer_coll.collection == target:
        return layer_coll
    for child in layer_coll.children:
        found = _find_layer_collection(child, target)
        if found is not None:
            return found
    return None


def _exclude_collection_from_view_layers(col: bpy.types.Collection):
    """在所有视图层中排除该集合（等同 Outliner 的「在视图层中排除」）。"""
    if col is None:
        return
    for view_layer in bpy.context.scene.view_layers:
        lc = _find_layer_collection(view_layer.layer_collection, col)
        if lc is not None:
            lc.exclude = True


def _setup_scene_collections(suffix: str) -> dict[str, bpy.types.Collection]:
    """集合层级：面部控制器 ─┬─ WGTS_Face_Rig
                        └─ WGTS_Eyes_Rig

    眼/脸控件网格都挂在「面部控制器」下，不再生成独立的「眼部控制器」集合。
    控件网格集合生成即设为视图层排除（不在视图层中显示），旧工程残留的空
    「眼部控制器」集合会被清理。
    """
    face_ctrl = _ensure_scene_collection(f"{COL_FACE}{suffix}")
    wgts_eyes = _ensure_child_collection(face_ctrl, f"{COL_WGTS_EYES}{suffix}")
    wgts_face = _ensure_child_collection(face_ctrl, f"{COL_WGTS_FACE}{suffix}")
    _exclude_collection_from_view_layers(wgts_eyes)
    _exclude_collection_from_view_layers(wgts_face)

    # 旧版曾把 WGTS_Eyes_Rig 挂在独立的「眼部控制器」下，清理残留空集合
    old_eyes = bpy.data.collections.get(f"{COL_EYES}{suffix}")
    if old_eyes and old_eyes is not face_ctrl:
        if not old_eyes.objects and not old_eyes.children:
            for sc in bpy.data.collections:
                if old_eyes.name in [c.name for c in sc.children]:
                    sc.children.unlink(old_eyes)
            bpy.data.collections.remove(old_eyes)

    return {
        "eyes_ctrl": face_ctrl,  # 兼容旧键：眼控件并入面部控制器集合
        "face_ctrl": face_ctrl,
        "wgts_eyes": wgts_eyes,
        "wgts_face": wgts_face,
    }


def _set_bone_collection_visible(bc, visible: bool):
    """Hide/show a bone collection across Blender 4.x API variants."""
    if hasattr(bc, "is_visible"):
        bc.is_visible = bool(visible)
    if hasattr(bc, "is_solo") and not visible:
        try:
            bc.is_solo = False
        except Exception:
            pass


def apply_bone_collection_visibility(arm_obj: bpy.types.Object, meta_key: str):
    """Re-apply RIG_META visibility (MCH/ROOT default hidden)."""
    arm = arm_obj.data
    if not hasattr(arm, "collections"):
        return
    for mc in RIG_META[meta_key]["armature"]["bone_collections"]:
        bc = arm.collections.get(mc["name"]) if hasattr(arm.collections, "get") else None
        if bc is None:
            for existing in arm.collections:
                if existing.name == mc["name"]:
                    bc = existing
                    break
        if bc is not None:
            _set_bone_collection_visible(bc, bool(mc["is_visible"]))


def _assign_bone_collections(
    arm_obj: bpy.types.Object,
    bone_defs: list,
    meta_key: str,
    *,
    preserve_other_collections: bool = False,
):
    arm = arm_obj.data
    if not hasattr(arm, "collections"):
        return

    meta_cols = RIG_META[meta_key]["armature"]["bone_collections"]
    by_name: dict[str, bpy.types.BoneCollection] = {}
    for mc in meta_cols:
        bc = None
        for existing in arm.collections:
            if existing.name == mc["name"]:
                bc = existing
                break
        if bc is None:
            bc = arm.collections.new(mc["name"])
        _set_bone_collection_visible(bc, bool(mc["is_visible"]))
        by_name[mc["name"]] = bc

    for bd in bone_defs:
        bone = arm.bones.get(bd["name"])
        if not bone:
            continue
        target_name = bd.get("bone_collection")
        if not target_name or target_name not in by_name:
            continue
        for bc in list(arm.collections):
            try:
                bc.unassign(bone)
            except Exception:
                pass
        by_name[target_name].assign(bone)

    if not preserve_other_collections:
        for bc in list(arm.collections):
            if bc.name not in by_name:
                try:
                    arm.collections.remove(bc)
                except Exception:
                    pass

    # 分配后再写一遍可见性，避免默认集合/新建集合把 MCH 露出来
    apply_bone_collection_visibility(arm_obj, meta_key)


def _apply_custom_shape(pb: bpy.types.PoseBone, cs: dict | None, widgets: dict):
    if not cs:
        return
    widget_key = cs.get("widget")
    shape_obj = None
    if widget_key and widget_key in widgets:
        shape_obj = widgets[widget_key]
    elif cs.get("object"):
        # Prefer exact name match among created widgets
        for w in widgets.values():
            if w.name == cs["object"] or w.name.startswith(cs["object"]):
                shape_obj = w
                break
    if not shape_obj:
        return

    pb.custom_shape = shape_obj
    if hasattr(pb, "custom_shape_scale_xyz") and cs.get("scale"):
        pb.custom_shape_scale_xyz = cs["scale"]
    if hasattr(pb, "custom_shape_translation") and cs.get("translation"):
        pb.custom_shape_translation = cs["translation"]
    if hasattr(pb, "custom_shape_rotation_euler") and cs.get("rotation_euler"):
        pb.custom_shape_rotation_euler = cs["rotation_euler"]
    if hasattr(pb, "use_custom_shape_bone_size"):
        pb.use_custom_shape_bone_size = bool(cs.get("use_bone_size", True))
    if hasattr(pb, "custom_shape_wire_width") and cs.get("wire_width") is not None:
        pb.custom_shape_wire_width = float(cs["wire_width"])


# Face 控制器高对比配色（相对 Rigify 默认蓝绿更显眼）
_CTL_FACE_COLOR = {
    "normal": (1.00, 0.18, 0.78),   # 品红
    "select": (1.00, 0.92, 0.20),   # 亮黄
    "active": (1.00, 1.00, 0.45),
}
_CTL_EYE_COLOR = {
    "normal": (0.10, 0.95, 1.00),   # 青
    "select": (1.00, 0.95, 0.25),
    "active": (1.00, 1.00, 0.50),
}
_LMT_COLOR = {
    "normal": (1.00, 0.55, 0.08),   # 橙
    "select": (1.00, 0.88, 0.30),
    "active": (1.00, 1.00, 0.50),
}


def _apply_ctrl_bone_color(pb: bpy.types.PoseBone, bone_name: str):
    """给 CTL/LMT 控制器上自定义骨骼颜色，便于在 Rigify 中辨认。"""
    if not hasattr(pb, "color"):
        return
    if bone_name.startswith("LMT-"):
        colors = _LMT_COLOR
    elif bone_name.startswith(("CTL-eye", "CTRL-eye", "CTL-eyes", "CTRL-eyes")):
        colors = _CTL_EYE_COLOR
    elif bone_name.startswith(("CTL-", "CTRL-", "CTR-")):
        colors = _CTL_FACE_COLOR
    else:
        return
    try:
        pb.color.palette = "CUSTOM"
        pb.color.custom.normal = colors["normal"]
        pb.color.custom.select = colors["select"]
        pb.color.custom.active = colors["active"]
    except Exception:
        pass


def apply_face_ctrl_colors(arm_obj: bpy.types.Object):
    """给骨架上已有的 Face CTL/LMT 骨骼统一上色（合并进 Rigify 后也可调用）。"""
    if not arm_obj or arm_obj.type != "ARMATURE":
        return 0
    n = 0
    for pb in arm_obj.pose.bones:
        name = pb.name
        if name.startswith(("CTL-", "CTRL-", "CTR-", "LMT-")):
            _apply_ctrl_bone_color(pb, name)
            n += 1
    return n


def _apply_limit_location(pb: bpy.types.PoseBone, cd: dict):
    c = pb.constraints.new("LIMIT_LOCATION")
    c.name = cd.get("name", "限定位置")
    c.mute = bool(cd.get("mute", False))
    c.influence = float(cd.get("influence", 1.0))
    c.owner_space = cd.get("owner_space", "LOCAL")
    if hasattr(c, "use_transform_limit"):
        c.use_transform_limit = bool(cd.get("use_transform_limit", True))
    for key in (
        "use_min_x", "use_max_x", "use_min_y", "use_max_y", "use_min_z", "use_max_z",
        "min_x", "max_x", "min_y", "max_y", "min_z", "max_z",
    ):
        if key in cd:
            setattr(c, key, cd[key])


def _apply_damped_track(pb: bpy.types.PoseBone, cd: dict, rig_obj: bpy.types.Object):
    c = pb.constraints.new("DAMPED_TRACK")
    c.name = cd.get("name", "阻尼追踪")
    c.mute = bool(cd.get("mute", False))
    c.target = rig_obj
    c.subtarget = cd.get("subtarget", "")
    c.influence = float(cd.get("influence", 1.0))
    if "track_axis" in cd:
        c.track_axis = cd["track_axis"]
    if "head_tail" in cd:
        c.head_tail = float(cd["head_tail"])


def _apply_object_and_armature_settings(obj: bpy.types.Object, meta_key: str):
    meta = RIG_META[meta_key]
    om = meta["object"]
    am = meta["armature"]
    obj.show_in_front = bool(om.get("show_in_front", True))
    if "display_type" in om:
        obj.display_type = om["display_type"]
    arm = obj.data
    if "display_type" in am:
        arm.display_type = am["display_type"]
    arm.show_names = bool(am.get("show_names", False))
    arm.show_axes = bool(am.get("show_axes", False))


def _create_armature_object(name: str, collection: bpy.types.Collection) -> bpy.types.Object:
    arm_data = bpy.data.armatures.new(name)
    obj = bpy.data.objects.new(name, arm_data)
    collection.objects.link(obj)
    return obj


def build_rig_from_template(
    bone_defs: list,
    name: str,
    suffix: str,
    collection: bpy.types.Collection,
    widgets: dict[str, bpy.types.Object],
    meta_key: str,
) -> bpy.types.Object:
    obj = _create_armature_object(f"{name}{suffix}", collection)
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)

    def _ms(mode: str):
        with bpy.context.temp_override(
            active_object=obj,
            object=obj,
            selected_objects=[obj],
            selected_editable_objects=[obj],
        ):
            bpy.ops.object.mode_set(mode=mode)

    _ms("EDIT")
    edit_bones = obj.data.edit_bones
    created = {}
    for bd in bone_defs:
        eb = edit_bones.new(bd["name"])
        eb.head = Vector(bd["head"])
        eb.tail = Vector(bd["tail"])
        if (eb.tail - eb.head).length < 1e-6:
            eb.tail = eb.head + Vector((0.0, -0.01, 0.0))
        eb.use_connect = bool(bd.get("use_connect", False))
        if "use_deform" in bd:
            eb.use_deform = bool(bd["use_deform"])
        created[bd["name"]] = eb

    for bd in bone_defs:
        parent = bd.get("parent")
        if parent and parent in created:
            created[bd["name"]].parent = created[parent]

    _ms("POSE")

    for bd in bone_defs:
        bone = obj.data.bones[bd["name"]]
        if bd.get("hide"):
            bone.hide = True
        # 原工程：所有 LMT-* 不可选中，避免误拖限位框（只动子级 CTL）
        if "hide_select" in bd:
            bone.hide_select = bool(bd["hide_select"])
        elif bd["name"].startswith("LMT-"):
            bone.hide_select = True

        pb = obj.pose.bones[bd["name"]]
        pb.rotation_mode = bd.get("rotation_mode", "QUATERNION")

        if "lock_location" in bd:
            pb.lock_location = bd["lock_location"]
        if "lock_rotation" in bd:
            pb.lock_rotation = bd["lock_rotation"]
        if "lock_scale" in bd:
            pb.lock_scale = bd["lock_scale"]

        _apply_custom_shape(pb, bd.get("custom_shape"), widgets)
        _apply_ctrl_bone_color(pb, bd["name"])

        for cd in bd.get("constraints") or []:
            ctype = cd["type"]
            # COPY_TRANSFORMS applied later with real target armature
            if ctype == "COPY_TRANSFORMS":
                continue
            if ctype == "LIMIT_LOCATION":
                _apply_limit_location(pb, cd)
            elif ctype == "DAMPED_TRACK":
                _apply_damped_track(pb, cd, obj)

    _ms("OBJECT")
    _assign_bone_collections(obj, bone_defs, meta_key)
    _apply_object_and_armature_settings(obj, meta_key)
    return obj


def create_face_and_eyes_rigs(suffix: str) -> tuple[bpy.types.Object, dict]:
    """创建合并后的 Face_Rig（含原 Eyes 骨骼），控件网格仍分脸/眼集合。"""
    cols = _setup_scene_collections(suffix)
    widgets = _create_widgets(suffix)

    for key in FACE_WIDGET_KEYS:
        _link_only(widgets[key], cols["wgts_face"])
    for key in EYES_WIDGET_KEYS:
        _link_only(widgets[key], cols["wgts_eyes"])

    # 面部 + 眼部骨骼合入同一骨架 Face_Rig
    bone_defs = list(FACE_RIG_BONES) + list(EYES_RIG_BONES)
    rig = build_rig_from_template(
        bone_defs, "Face_Rig", suffix, cols["face_ctrl"], widgets, "Face_Rig"
    )
    apply_bone_collection_visibility(rig, "Face_Rig")
    return rig, cols


# 写入 Rigify 宿主骨架的自定义属性，标记已合并 Face 控制器
MERGED_INTO_PROP = "face_eyes_ctrl_merged"


def face_ctrl_bone_names() -> set[str]:
    return {bd["name"] for bd in list(FACE_RIG_BONES) + list(EYES_RIG_BONES)}


def host_has_face_ctrl_bones(arm_obj: bpy.types.Object) -> bool:
    if not arm_obj or arm_obj.type != "ARMATURE":
        return False
    bones = arm_obj.data.bones
    return "MCH-face_root" in bones and "CTL-eye_blink" in bones


def _mode_set_obj(obj: bpy.types.Object, mode: str):
    view = bpy.context.view_layer
    was_hide = obj.hide_get()
    if was_hide:
        obj.hide_set(False)
    obj.hide_select = False
    view.objects.active = obj
    try:
        obj.select_set(True)
    except Exception:
        pass
    with bpy.context.temp_override(
        active_object=obj,
        object=obj,
        selected_objects=[obj],
        selected_editable_objects=[obj],
    ):
        if obj.mode != mode:
            bpy.ops.object.mode_set(mode=mode)
    return was_hide


def remove_face_ctrl_bones_from_host(arm_obj: bpy.types.Object) -> int:
    """从宿主骨架删除本插件注入的 Face/Eyes 骨骼（Rigify 合并用）。"""
    if not arm_obj or arm_obj.type != "ARMATURE":
        return 0
    names = face_ctrl_bone_names()
    present = [n for n in names if n in arm_obj.data.bones]
    if not present:
        if MERGED_INTO_PROP in arm_obj:
            del arm_obj[MERGED_INTO_PROP]
        return 0

    # 清掉指向这些骨骼的 Look 驱动
    ad = arm_obj.animation_data
    if ad:
        for fc in list(ad.drivers):
            path = fc.data_path or ""
            if any(f'pose.bones["{n}"]' in path or f"pose.bones['{n}']" in path for n in names):
                try:
                    arm_obj.driver_remove(fc.data_path, fc.array_index)
                except Exception:
                    try:
                        arm_obj.driver_remove(fc.data_path)
                    except Exception:
                        pass

    was_hide = _mode_set_obj(arm_obj, "EDIT")
    ebones = arm_obj.data.edit_bones
    removed = 0
    for n in present:
        eb = ebones.get(n)
        if eb:
            ebones.remove(eb)
            removed += 1
    _mode_set_obj(arm_obj, "OBJECT")
    if was_hide:
        arm_obj.hide_set(True)

    # 仅移除本插件的空骨骼集合
    meta_names = {mc["name"] for mc in RIG_META["Face_Rig"]["armature"]["bone_collections"]}
    if hasattr(arm_obj.data, "collections"):
        for bc in list(arm_obj.data.collections):
            if bc.name in meta_names and len(bc.bones) == 0:
                try:
                    arm_obj.data.collections.remove(bc)
                except Exception:
                    pass

    if MERGED_INTO_PROP in arm_obj:
        del arm_obj[MERGED_INTO_PROP]
    return removed


def add_bones_from_template(
    obj: bpy.types.Object,
    bone_defs: list,
    widgets: dict[str, bpy.types.Object],
    meta_key: str,
    *,
    preserve_other_collections: bool = True,
) -> None:
    """向已有骨架追加模板骨骼（不改对象级显示设置，避免破坏 Rigify）。"""
    existing = {b.name for b in obj.data.bones}
    conflicts = [bd["name"] for bd in bone_defs if bd["name"] in existing]
    if conflicts:
        raise RuntimeError(
            "宿主骨架已有同名骨骼，无法合并 Face 控制器: "
            + ", ".join(conflicts[:8])
            + ("..." if len(conflicts) > 8 else "")
        )

    was_hide = _mode_set_obj(obj, "EDIT")
    edit_bones = obj.data.edit_bones
    created = {}
    for bd in bone_defs:
        eb = edit_bones.new(bd["name"])
        eb.head = Vector(bd["head"])
        eb.tail = Vector(bd["tail"])
        if (eb.tail - eb.head).length < 1e-6:
            eb.tail = eb.head + Vector((0.0, -0.01, 0.0))
        eb.use_connect = bool(bd.get("use_connect", False))
        if "use_deform" in bd:
            eb.use_deform = bool(bd["use_deform"])
        created[bd["name"]] = eb

    for bd in bone_defs:
        parent = bd.get("parent")
        if parent and parent in created:
            created[bd["name"]].parent = created[parent]

    _mode_set_obj(obj, "POSE")

    for bd in bone_defs:
        bone = obj.data.bones[bd["name"]]
        if bd.get("hide"):
            bone.hide = True
        if "hide_select" in bd:
            bone.hide_select = bool(bd["hide_select"])
        elif bd["name"].startswith("LMT-"):
            bone.hide_select = True

        pb = obj.pose.bones[bd["name"]]
        pb.rotation_mode = bd.get("rotation_mode", "QUATERNION")
        if "lock_location" in bd:
            pb.lock_location = bd["lock_location"]
        if "lock_rotation" in bd:
            pb.lock_rotation = bd["lock_rotation"]
        if "lock_scale" in bd:
            pb.lock_scale = bd["lock_scale"]
        _apply_custom_shape(pb, bd.get("custom_shape"), widgets)
        _apply_ctrl_bone_color(pb, bd["name"])

        for cd in bd.get("constraints") or []:
            ctype = cd["type"]
            if ctype == "COPY_TRANSFORMS":
                continue
            if ctype == "LIMIT_LOCATION":
                _apply_limit_location(pb, cd)
            elif ctype == "DAMPED_TRACK":
                _apply_damped_track(pb, cd, obj)

    _mode_set_obj(obj, "OBJECT")
    if was_hide:
        obj.hide_set(True)

    _assign_bone_collections(
        obj,
        bone_defs,
        meta_key,
        preserve_other_collections=preserve_other_collections,
    )
    apply_bone_collection_visibility(obj, meta_key)


def inject_face_and_eyes_into_armature(
    host: bpy.types.Object,
    suffix: str = "",
) -> tuple[bpy.types.Object, dict]:
    """将 Face/Eyes 控制器骨骼合并进已有骨架（Rigify RIG-*）。

    CTL 骨骼会分配到 Rigify 原有的 "Face" 集合，使得 Rigify 的 Face
    图层开关可以隐藏/显示注入的面部控制器。
    """
    if not host or host.type != "ARMATURE":
        raise RuntimeError("inject_face_and_eyes_into_armature: host 必须是骨架")
    if host_has_face_ctrl_bones(host):
        raise RuntimeError(f"{host.name} 已包含 Face 控制器骨骼")

    cols = _setup_scene_collections(suffix)
    widgets = _create_widgets(suffix)
    for key in FACE_WIDGET_KEYS:
        _link_only(widgets[key], cols["wgts_face"])
    for key in EYES_WIDGET_KEYS:
        _link_only(widgets[key], cols["wgts_eyes"])

    bone_defs = list(FACE_RIG_BONES) + list(EYES_RIG_BONES)
    add_bones_from_template(
        host,
        bone_defs,
        widgets,
        "Face_Rig",
        preserve_other_collections=True,
    )

    # 注入模式：将 CTL 骨骼分配到 Rigify 的 "Face" 集合，
    # 以便 Rigify 的 Face 层开关能控制它们
    _remap_injected_bone_collections(host, bone_defs)

    host[MERGED_INTO_PROP] = True
    # 合并后便于在 Rigify 上看到控制器
    host.show_in_front = True
    return host, cols


def _remap_injected_bone_collections(host: bpy.types.Object, bone_defs: list):
    """Rigify注入模式：将 CTL 骨骼移至 "Face" 集合，MCH/ROOT 保持隐藏。"""
    arm = host.data
    if not hasattr(arm, "collections"):
        return

    colls = arm.collections

    def _find_or_create(name: str, visible: bool) -> bpy.types.BoneCollection:
        bc = colls.get(name)
        if bc is None:
            bc = colls.new(name)
        _set_bone_collection_visible(bc, visible)
        return bc

    face_col = _find_or_create("Face", True)
    mch_col = _find_or_create("MCH", False)
    root_col = _find_or_create("ROOT", False)

    for bd in bone_defs:
        bone = arm.bones.get(bd["name"])
        if not bone:
            continue
        bc_name = bd.get("bone_collection", "")
        if bc_name == "CTL":
            for bc in list(colls):
                try:
                    bc.unassign(bone)
                except Exception:
                    pass
            face_col.assign(bone)
        elif bc_name == "MCH":
            for bc in list(colls):
                try:
                    bc.unassign(bone)
                except Exception:
                    pass
            mch_col.assign(bone)
        elif bc_name == "ROOT":
            for bc in list(colls):
                try:
                    bc.unassign(bone)
                except Exception:
                    pass
            root_col.assign(bone)

    # 移除可能被自动创建的空 "CTL" 集合
    ctl_col = colls.get("CTL")
    if ctl_col is not None and len(list(ctl_col.bones)) == 0:
        try:
            colls.remove(ctl_col)
        except Exception:
            pass
