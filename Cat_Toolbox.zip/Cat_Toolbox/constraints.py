"""Constraint binding matching 面部绑定_范例-2.blend."""

from __future__ import annotations

import bpy


def _clear_constraints_of_type(pose_bone: bpy.types.PoseBone, ctype: str):
    for c in list(pose_bone.constraints):
        if c.type == ctype:
            pose_bone.constraints.remove(c)


def bind_copy_transforms_to_head(
    rig_obj: bpy.types.Object,
    bone_name: str,
    target_arm: bpy.types.Object,
    head_bone: str,
):
    """Rig 骨骼 → Copy Transforms「复制变换」→ 目標頭（WORLD/WORLD, REPLACE）。"""
    pb = rig_obj.pose.bones.get(bone_name)
    if not pb:
        raise RuntimeError(f"{rig_obj.name} missing bone {bone_name}")
    _clear_constraints_of_type(pb, "COPY_TRANSFORMS")
    c = pb.constraints.new("COPY_TRANSFORMS")
    c.name = "复制变换"
    c.target = target_arm
    c.subtarget = head_bone
    c.influence = 1.0
    c.mix_mode = "REPLACE"
    c.head_tail = 0.0
    c.target_space = "WORLD"
    c.owner_space = "WORLD"
    c.mute = False
    if hasattr(c, "remove_target_shear"):
        c.remove_target_shear = False
    return c


def bind_eyes_root_to_head(eyes_rig: bpy.types.Object, target_arm: bpy.types.Object, head_bone: str):
    """MCH-eyes_root → Copy Transforms「复制变换」→ head。"""
    return bind_copy_transforms_to_head(eyes_rig, "MCH-eyes_root", target_arm, head_bone)


def bind_face_root_to_head(face_rig: bpy.types.Object, target_arm: bpy.types.Object, head_bone: str):
    """MCH-face_root → Copy Transforms「复制变换」→ head（范例-2）。"""
    return bind_copy_transforms_to_head(face_rig, "MCH-face_root", target_arm, head_bone)


def _ensure_object_mode_active(obj: bpy.types.Object):
    """Make obj active/selectable (even if hidden) and switch to OBJECT mode."""
    view = bpy.context.view_layer
    if obj.hide_get():
        obj.hide_set(False)
    obj.hide_viewport = False
    obj.hide_select = False
    for o in view.objects:
        try:
            o.select_set(False)
        except Exception:
            pass
    view.objects.active = obj
    try:
        obj.select_set(True)
    except Exception:
        pass
    if view.objects.active != obj:
        view.objects.active = obj
    if obj.mode != "OBJECT":
        with bpy.context.temp_override(
            active_object=obj,
            object=obj,
            selected_editable_objects=[obj],
            selected_objects=[obj],
        ):
            bpy.ops.object.mode_set(mode="OBJECT")


def _mode_set(obj: bpy.types.Object, mode: str):
    """Safe mode_set with temp_override; unhides obj first if needed."""
    _ensure_object_mode_active(obj)
    if obj.mode == mode:
        return
    with bpy.context.temp_override(
        active_object=obj,
        object=obj,
        selected_editable_objects=[obj],
        selected_objects=[obj],
    ):
        bpy.ops.object.mode_set(mode=mode)


def _restore_eye_parent(
    target_arm: bpy.types.Object,
    eye_bones: tuple[str, ...],
    head_bone: str,
):
    """恢复 目 与 頭 的骨骼父子（若曾被旧绑定切断），不触碰已有父级。"""
    if not head_bone:
        return
    prev = bpy.context.view_layer.objects.active
    was_hidden = target_arm.hide_get()
    _mode_set(target_arm, "EDIT")
    head_eb = target_arm.data.edit_bones.get(head_bone)
    for name in eye_bones:
        eb = target_arm.data.edit_bones.get(name)
        if not eb or eb.parent is not None:
            continue
        if head_eb is not None:
            eb.parent = head_eb
            eb.use_connect = False
    _mode_set(target_arm, "OBJECT")
    if was_hidden:
        target_arm.hide_set(True)
    if prev and prev.name in bpy.data.objects:
        bpy.context.view_layer.objects.active = prev

def _mute_mmd_eye_transform(pose_bone: bpy.types.PoseBone):
    """Mute mmd_tools 両目→目 的 TRANSFORM，避免与眼部控制约束 / 注视抢控制。"""
    for c in pose_bone.constraints:
        if c.type != "TRANSFORM":
            continue
        name = (c.name or "").lower()
        if "mmd" in name or "additional" in name:
            c.mute = True


def _location_data_paths(bone_names: tuple[str, ...]) -> tuple[str, ...]:
    paths: list[str] = []
    for b in bone_names:
        paths.append(f'pose.bones["{b}"].location')
        paths.append(f"pose.bones['{b}'].location")
    return tuple(paths)


def clear_eye_location_animation(target_arm: bpy.types.Object, eye_bones: tuple[str, ...]) -> int:
    """清除 目 / 目先 等骨骼的位移关键帧，并锁定位移通道。"""
    removed = 0
    prefixes = _location_data_paths(eye_bones)

    def scrub_action(action: bpy.types.Action | None):
        nonlocal removed
        if not action:
            return
        for fc in list(action.fcurves):
            if any(fc.data_path == p or fc.data_path.startswith(p) for p in prefixes):
                action.fcurves.remove(fc)
                removed += 1

    ad = target_arm.animation_data
    if ad:
        scrub_action(ad.action)
        for track in ad.nla_tracks:
            for strip in track.strips:
                scrub_action(strip.action)

    for name in eye_bones:
        pb = target_arm.pose.bones.get(name)
        if pb:
            pb.location = (0.0, 0.0, 0.0)
            pb.lock_location = (True, True, True)

    return removed


def _extra_eye_tip_bones(target_arm: bpy.types.Object, eye_l: str, eye_r: str) -> tuple[str, ...]:
    """目先 等常随 VMD 带位移，一并清理。"""
    tips = []
    for base in (eye_l, eye_r):
        # 目.L → 目先.L
        if base.startswith("目"):
            tip = base.replace("目", "目先", 1)
            if tip in target_arm.data.bones:
                tips.append(tip)
    for name in ("目先.L", "目先.R"):
        if name in target_arm.data.bones and name not in tips:
            tips.append(name)
    return tuple(tips)


def _remove_old_eye_childof(pb: bpy.types.PoseBone):
    for c in list(pb.constraints):
        if c.type != "CHILD_OF":
            continue
        sub = c.subtarget or ""
        tgt = c.target
        # 含 target 已丢失（None）但仍指向 MCH-eye 的残留
        if sub.startswith("MCH-eye"):
            pb.constraints.remove(c)
            continue
        if tgt and (
            tgt.name.startswith("Eyes_Rig") or tgt.name.startswith("Face_Rig")
        ):
            pb.constraints.remove(c)
            continue
        if c.name.startswith("FaceEyesCtrl") or c.name == "子级":
            if tgt is None or (
                tgt
                and (
                    tgt.name.startswith("Eyes_Rig")
                    or tgt.name.startswith("Face_Rig")
                )
            ):
                pb.constraints.remove(c)


# 眼部控制约束名：Damped Track「眼控追踪」（旧方案 Child Of「子级」/ Copy Rotation「眼控旋转」）
_EYE_TRACK_NAME = "眼控追踪"
_LEGACY_EYE_CTRL_NAMES = ("眼控旋转", "子级")


def _add_eye_damped_track(
    eyes_rig: bpy.types.Object,
    target_arm: bpy.types.Object,
    eye_bone: str,
    mch: str,
) -> bpy.types.Constraint:
    """目 → Damped Track「眼控追踪」→ MCH-eye_* 尾端（head_tail=1.0）。

    瞄准型增量约束：输出相对当前朝向的旋转，不叠加父级（頭）旋转、不破坏 rest，
    静止时 MCH-eye 尾端位于眼骨 Y 轴延长线上 → 无对眼、无反向。
    """
    pb = target_arm.pose.bones.get(eye_bone)
    if not pb:
        raise RuntimeError(f"Target armature missing eye bone: {eye_bone}")
    if mch not in eyes_rig.pose.bones:
        raise RuntimeError(f"{eyes_rig.name} missing eye MCH bone: {mch}")

    _mute_mmd_eye_transform(pb)
    _remove_old_eye_childof(pb)
    for c in list(pb.constraints):
        if c.type in ("DAMPED_TRACK", "COPY_ROTATION") and c.name in (
            _EYE_TRACK_NAME,
            *_LEGACY_EYE_CTRL_NAMES,
        ):
            pb.constraints.remove(c)

    c = pb.constraints.new("DAMPED_TRACK")
    c.name = _EYE_TRACK_NAME
    c.target = eyes_rig
    c.subtarget = mch
    c.influence = 1.0
    c.track_axis = "TRACK_Y"
    c.head_tail = 1.0
    return c


def bind_eyeballs_controls(
    eyes_rig: bpy.types.Object,
    target_arm: bpy.types.Object,
    head_bone: str,
    eye_l_bone: str,
    eye_r_bone: str,
):
    """绑定 目.L/R：保持与頭 的父子关系，用 Damped Track 追踪 MCH-eye_* 尾端。

    父级管位置、追踪管眼神旋转；不破坏 rest、无双重变换、无方向反转。
    """
    pairs = (
        (eye_l_bone, "MCH-eye_L"),
        (eye_r_bone, "MCH-eye_R"),
    )
    eye_names = (eye_l_bone, eye_r_bone)
    tip_names = _extra_eye_tip_bones(target_arm, eye_l_bone, eye_r_bone)

    _restore_eye_parent(target_arm, eye_names, head_bone)
    clear_eye_location_animation(target_arm, eye_names + tip_names)

    created = []
    for eye_bone, mch in pairs:
        created.append(_add_eye_damped_track(eyes_rig, target_arm, eye_bone, mch))
    return created


def repair_eyeball_binding(
    eyes_rig: bpy.types.Object,
    target_arm: bpy.types.Object,
    head_bone: str,
    eye_l_bone: str,
    eye_r_bone: str,
    face_rig: bpy.types.Object | None = None,
) -> dict:
    """修复导动作后常见问题：约束目标丢失、目位移动画、root 复制变换丢失。"""
    # 确保 Eyes/Face root 仍跟頭
    bind_eyes_root_to_head(eyes_rig, target_arm, head_bone)
    if face_rig and "MCH-face_root" in face_rig.pose.bones:
        bind_face_root_to_head(face_rig, target_arm, head_bone)

    tip_names = _extra_eye_tip_bones(target_arm, eye_l_bone, eye_r_bone)
    removed = clear_eye_location_animation(
        target_arm, (eye_l_bone, eye_r_bone) + tip_names
    )
    created = bind_eyeballs_controls(
        eyes_rig, target_arm, head_bone, eye_l_bone, eye_r_bone
    )
    try:
        from . import placement as _placement

        _placement.refine_mch_eyes_after_bind(
            eyes_rig, target_arm, eye_l_bone, eye_r_bone
        )
    except Exception:
        pass

    # 校验目标指针
    broken = []
    for bn in (eye_l_bone, eye_r_bone):
        pb = target_arm.pose.bones.get(bn)
        if not pb:
            broken.append(bn)
            continue
        ok = False
        for c in pb.constraints:
            if (
                c.type == "DAMPED_TRACK"
                and c.target == eyes_rig
                and c.name == _EYE_TRACK_NAME
            ):
                ok = True
                break
        if not ok:
            broken.append(bn)

    return {
        "cleared_loc_fcurves": removed,
        "damped_track_count": len(created),
        "broken": broken,
    }
