"""One-click apply merged Face_Rig (face + eyes bones)."""

from __future__ import annotations

import bpy
from bpy.types import Operator

from . import build_rig, constraints, drivers, placement
from .build_rig import (
    MERGED_INTO_PROP,
    host_has_face_ctrl_bones,
    inject_face_and_eyes_into_armature,
    remove_face_ctrl_bones_from_host,
)
from .props import auto_fill_settings
from .rigify_compat import (
    detect_rigify_driven_target,
    effective_rigify_compat,
    looks_like_rigify_control_rig,
    prepare_rigify_eyes_for_face_rig,
)


def _detect_existing_placeholder_hub(mesh_obj: bpy.types.Object) -> str | None:
    sk = mesh_obj.data.shape_keys
    if not sk or not sk.animation_data:
        return None
    for fc in sk.animation_data.drivers:
        for var in fc.driver.variables:
            for t in var.targets:
                if t.id and t.id.name.startswith(".placeholder"):
                    return t.id.name
    return None


def _find_standalone_face_rig() -> bpy.types.Object | None:
    return bpy.data.objects.get("Face_Rig") or bpy.data.objects.get("Eyes_Rig")


def _find_merged_host() -> bpy.types.Object | None:
    """Rigify 宿主上已合并的 Face 控制器。"""
    for obj in bpy.data.objects:
        if obj.type != "ARMATURE":
            continue
        if obj.get(MERGED_INTO_PROP) or (
            looks_like_rigify_control_rig(obj) and host_has_face_ctrl_bones(obj)
        ):
            return obj
    return None


def _find_existing_ctrl_rig() -> bpy.types.Object | None:
    """已存在的控制器：独立 Face_Rig，或已合并进 Rigify 的宿主。"""
    return _find_standalone_face_rig() or _find_merged_host()


def _ctrl_rig_is_incomplete(rig: bpy.types.Object) -> bool:
    """True if Face controls exist but morph/Look drivers were never finished."""
    if not bpy.data.objects.get(".placeholder"):
        return True
    ad = rig.animation_data
    if not ad or not ad.drivers:
        return True
    has_look = any(
        "MCH-eye_" in (fc.data_path or "") and "rotation_euler" in (fc.data_path or "")
        for fc in ad.drivers
    )
    return not has_look


def _remove_object(name: str):
    obj = bpy.data.objects.get(name)
    if not obj:
        return
    data = obj.data
    bpy.data.objects.remove(obj, do_unlink=True)
    if data and getattr(data, "users", 1) == 0:
        if isinstance(data, bpy.types.Armature):
            bpy.data.armatures.remove(data)
        elif isinstance(data, bpy.types.Mesh):
            bpy.data.meshes.remove(data)


def _remove_incomplete_ctrl_setup() -> bool:
    """Remove incomplete Face_Rig / merged bones / .placeholder so apply can retry."""
    cleaned = False

    merged = _find_merged_host()
    if merged and _ctrl_rig_is_incomplete(merged):
        remove_face_ctrl_bones_from_host(merged)
        cleaned = True

    standalone = _find_standalone_face_rig()
    if standalone and _ctrl_rig_is_incomplete(standalone):
        _remove_object(standalone.name)
        _remove_object("Eyes_Rig")
        _remove_object("Face_Rig")
        cleaned = True

    if cleaned:
        _remove_object(".placeholder")
    return cleaned


def _ensure_object_mode(context):
    """Enter OBJECT mode with a valid active object (needed for later mode_set)."""
    view = context.view_layer
    active = view.objects.active or context.object
    if active is None:
        for name in ("Face_Rig",):
            cand = bpy.data.objects.get(name)
            if cand:
                active = cand
                break
        if active is None:
            for obj in view.objects:
                active = obj
                break
    if active is None:
        return
    view.objects.active = active
    try:
        active.select_set(True)
    except Exception:
        pass
    if active.mode != "OBJECT":
        with context.temp_override(
            active_object=active,
            object=active,
            selected_objects=[active],
            selected_editable_objects=[active],
        ):
            bpy.ops.object.mode_set(mode="OBJECT")


class FACE_EYES_OT_auto_detect(Operator):
    bl_idname = "face_eyes_ctrl.auto_detect"
    bl_label = "自动识别目标"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        msg = auto_fill_settings(context)
        self.report({"INFO"}, msg)
        context.scene.face_eyes_ctrl.last_report = msg
        return {"FINISHED"}


class FACE_EYES_OT_apply(Operator):
    bl_idname = "face_eyes_ctrl.apply"
    bl_label = "一键应用控制器"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.face_eyes_ctrl
        auto_fill_settings(context)

        arm = s.target_armature
        mesh = s.target_mesh

        if not arm or arm.type != "ARMATURE":
            self.report({"ERROR"}, "请指定目标骨架")
            return {"CANCELLED"}
        if not mesh or mesh.type != "MESH":
            self.report({"ERROR"}, "请指定目标网格（需含 Shape Key）")
            return {"CANCELLED"}
        if not mesh.data.shape_keys:
            self.report({"ERROR"}, "目标网格没有 Shape Key / Morph")
            return {"CANCELLED"}

        head = s.head_bone
        eye_l = s.eye_l_bone
        eye_r = s.eye_r_bone
        for bone_name, label in ((head, "头部"), (eye_l, "左眼"), (eye_r, "右眼")):
            if bone_name not in arm.data.bones:
                self.report({"ERROR"}, f"目标骨架缺少{label}骨骼: {bone_name}")
                return {"CANCELLED"}

        cleaned = _remove_incomplete_ctrl_setup()
        if _find_existing_ctrl_rig():
            self.report(
                {"ERROR"},
                "已存在完整的 Face 控制器（独立 Face_Rig 或已合并进 Rigify），请先删除后再应用",
            )
            return {"CANCELLED"}

        ph_name = ".placeholder"
        face_new = None
        merged_into_rigify = False
        rigify_host = None

        try:
            _ensure_object_mode(context)
            view = context.view_layer
            view.objects.active = mesh if mesh.name in view.objects else arm
            try:
                view.objects.active.select_set(True)
            except Exception:
                pass

            drivers.prepare_tongxiao_slider_min(mesh, -1.0)

            if s.binding_mode == "COMPAT":
                drivers.set_morph_slider_min(mesh, ["まばたき", "笑い"], -0.2)

            compat = effective_rigify_compat(s.rigify_compat, arm)
            rigify_stats = None

            if compat:
                rigify_host = detect_rigify_driven_target(arm)
                if not rigify_host:
                    self.report(
                        {"ERROR"},
                        "Rigify 兼容已开启，但未找到驱动目标骨架的 Rigify 控制骨架",
                    )
                    return {"CANCELLED"}
                # 骨骼合并进 Rigify；不再创建独立 Face_Rig 物体
                face_new, cols = inject_face_and_eyes_into_armature(rigify_host, "")
                merged_into_rigify = True
                rigify_stats = prepare_rigify_eyes_for_face_rig(arm, eye_l, eye_r)
            else:
                # --- 非 Rigify：保持原逻辑（独立 Face_Rig）---
                face_new, cols = build_rig.create_face_and_eyes_rigs("")
                face_new.parent = None
                face_new.location = (0.0, 0.0, 0.0)
                face_new.rotation_euler = (0.0, 0.0, 0.0)

            # Face 对齐：独立 Face_Rig 整骨架平移；Rigify 注入只平移 Face 子树
            # （MCH-face_root+后代），避免宿主手臂/腿 rest 被撕开，同时保持表情 CTL 相对 root。
            if merged_into_rigify:
                placement.align_face_root_only_to_head(face_new, arm, head)
            else:
                placement.align_face_rig_to_target(face_new, arm, head)
            # Eyes 对齐两种模式都要：只改眼控相关骨，不碰身体链
            placement.align_eyes_rig_to_target(face_new, arm, head, eye_l, eye_r)
            constraints.bind_face_root_to_head(face_new, arm, head)
            build_rig.apply_bone_collection_visibility(face_new, "Face_Rig")
            constraints.bind_eyes_root_to_head(face_new, arm, head)
            constraints.bind_eyeballs_controls(face_new, arm, head, eye_l, eye_r)
            # 补偿 MCH→CTL 阻尼追踪对目骨静止朝向的拉偏
            placement.refine_mch_eyes_after_bind(face_new, arm, eye_l, eye_r)

            mapped = drivers.morph_names_present(mesh)
            all_morphs = drivers.all_mesh_morph_names(mesh)
            if not mapped:
                self.report(
                    {"WARNING"},
                    "目标网格没有与映射表同名的 Morph，仅完成骨骼绑定",
                )

            existing_hub = _detect_existing_placeholder_hub(mesh)
            if existing_hub and existing_hub != ph_name:
                self.report(
                    {"WARNING"},
                    f"目标网格 Morph 原由 {existing_hub} 驱动，将改挂到 {ph_name}",
                )

            root = arm.parent
            placeholder = placement.create_placeholder_for_target(mesh, "", root)
            mesh_cols = list(mesh.users_collection)
            if mesh_cols:
                placement.move_to_collection(placeholder, mesh_cols[0])

            morph_drivers_list = drivers.get_custom_morph_drivers() if s.binding_mode == "COMPAT" else None
            applied, missing = drivers.build_placeholder_morph_drivers(
                placeholder, face_new, face_new, all_morphs, morph_drivers_list
            )
            drivers.prepare_tongxiao_slider_min(placeholder, -1.0)
            if s.binding_mode == "COMPAT":
                drivers.set_morph_slider_min(placeholder, ["まばたき", "笑い"], -0.2)
            mirrored = drivers.build_mesh_mirror_drivers(mesh, placeholder, all_morphs)
            look_n = drivers.build_eye_look_drivers(face_new, face_new)
            build_rig.apply_face_ctrl_colors(face_new)

            if merged_into_rigify:
                mode_note = f"Rigify合并→{face_new.name}"
            else:
                mode_note = "完整绑定" + ("(不使用びっくり)" if s.binding_mode == "COMPAT" else "(使用びっくり)")
            msg = (
                f"完成[{mode_note}]: 控制器骨架={face_new.name}, "
                f"集合={cols['face_ctrl'].name}, "
                f"Morph驱动={applied}, 全量镜像={mirrored}, Look驱动={look_n}, "
                f"缺失映射Morph={len(missing)}"
            )
            if cleaned:
                msg = "已清理不完整绑定并重新应用。" + msg
            if rigify_stats:
                msg += (
                    f", 静音约束={rigify_stats['muted_constraints']}, "
                    f"隐藏眼控={rigify_stats['hidden_bones']}"
                )
            if missing:
                msg += f" ({', '.join(missing[:8])}{'...' if len(missing) > 8 else ''})"
            s.last_report = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}

        except Exception as e:
            if merged_into_rigify and rigify_host is not None:
                remove_face_ctrl_bones_from_host(rigify_host)
            elif face_new is not None and face_new.name in ("Face_Rig", "Eyes_Rig"):
                _remove_object(face_new.name)
            _remove_object("Face_Rig")
            _remove_object("Eyes_Rig")
            _remove_object(".placeholder")
            s.last_report = f"失败: {e}"
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}


CLASSES = (
    FACE_EYES_OT_auto_detect,
    FACE_EYES_OT_apply,
)
