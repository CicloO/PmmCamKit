"""MMD 相机自适应烘焙 + 相机 VMD 导出

思路：
1. 逐帧采样源相机，换算为 MMD 相机参数（目标点/欧拉角/视角/距离）。
2. 按画面跳变自动识别切镜，切镜处用相邻两帧关键帧（MMD 视为硬切）。
3. 同一镜头内按"画面误差"自适应选关键帧（最小间隔 2 帧），
   并为每段拟合 VMD 插值曲线（X/Y/Z/旋转/距离/视角 6 条，0~127 量化）。
   误差按 MMD 的回放方式评估：贝塞尔曲线插值，视角按小数插值，含半帧。
4. VMD 视角只能存整数度：关键帧优先落在视角接近整数的帧，
   残余误差沿视线平移相机补偿（只在关键帧上，曲线平滑过渡，无锯齿）。
5. 曲线写入 Blender F-Curve 的贝塞尔手柄（预览与 MMD 一致），
   导出时从手柄原样还原 VMD 曲线参数。
"""
from __future__ import annotations

import bisect
import math
import struct

import bpy
import numpy as np
from mathutils import Euler, Matrix, Vector

# 通道：0-2 目标点 xyz，3-5 旋转 xyz（YXZ 欧拉），6 视角(rad)，7 距离
N_CH = 8
# 曲线组（Blender 轴）：x, y, z, rot, fov, dis
GROUPS = ((0,), (1,), (2,), (3, 4, 5), (6,), (7,))
CH_GROUP = (0, 1, 2, 3, 3, 3, 4, 5)
LINEAR = (20, 20, 107, 107)  # x1, y1, x2, y2

_RX90 = Matrix.Rotation(math.pi / 2, 3, "X")
_RXN90 = Matrix.Rotation(-math.pi / 2, 3, "X")
_REF_XY = ((0.0, 0.0), (0.8, 0.8), (-0.8, 0.8), (0.8, -0.8), (-0.8, -0.8))
_EPS = (1e-6, 1e-6, 1e-6, 1e-7, 1e-7, 1e-7, 1e-7, 1e-6)


# ============================================================================
# 相机几何
# ============================================================================

def _cam_pose(p):
    """MMD 参数 → (相机旋转矩阵, 相机位置)。"""
    r_empty = Euler((p[3], p[4], p[5]), "YXZ").to_matrix()
    view = r_empty @ Vector((0.0, 1.0, 0.0))
    pos = Vector((p[0], p[1], p[2])) + view * p[7]
    return r_empty @ _RX90, pos


def _half_height(p, persp):
    """深度为 1 处画面半高（透视），或正交时的画面半高。"""
    if persp:
        return math.tan(p[6] / 2)
    return 25 * abs(p[7]) / 45 / 2


class _Ref:
    """某一时刻源相机的参考点（世界坐标）与其屏幕坐标。"""
    __slots__ = ("pts", "ndc")

    def __init__(self, p, persp, depth, aspect):
        rot, pos = _cam_pose(p)
        h = _half_height(p, persp)
        self.pts, self.ndc = [], []
        for d in (depth, depth * 2):
            for ax, ay in _REF_XY:
                sx, sy = ax * aspect, ay
                local = (Vector((sx * h * d, sy * h * d, -d)) if persp
                         else Vector((sx * h, sy * h, -d)))
                self.pts.append(pos + rot @ local)
                self.ndc.append((sx, sy))


def _err_vec(p, persp, ref: _Ref):
    """模拟相机 p 下各参考点的屏幕偏差向量 (N,2)（单位：画面高度）。"""
    rot, pos = _cam_pose(p)
    rt = rot.transposed()
    h = _half_height(p, persp)
    out = np.empty((len(ref.pts), 2))
    for k, (pt, (nx, ny)) in enumerate(zip(ref.pts, ref.ndc)):
        q = rt @ (pt - pos)
        if persp:
            z = -q.z
            if z < 1e-6:
                out[k] = (5.0, 5.0)
                continue
            out[k] = (q.x / z / h - nx, q.y / z / h - ny)
        else:
            out[k] = (q.x / h - nx, q.y / h - ny)
    return out * 0.5


def _screen_err(p, persp, ref: _Ref):
    """模拟相机 p 下参考点的最大屏幕偏差（单位：画面高度）。"""
    rot, pos = _cam_pose(p)
    rt = rot.transposed()
    h = _half_height(p, persp)
    worst = 0.0
    for pt, (nx, ny) in zip(ref.pts, ref.ndc):
        q = rt @ (pt - pos)
        if persp:
            z = -q.z
            if z < 1e-6:
                return 10.0
            x, y = q.x / z / h, q.y / z / h
        else:
            x, y = q.x / h, q.y / h
        e = max(abs(x - nx), abs(y - ny))
        if e > worst:
            worst = e
    return worst * 0.5


# ============================================================================
# VMD 贝塞尔
# ============================================================================

def _solve_u(x1s, x2s, xs):
    """对每组 (x1,x2)（0~127 整数）求贝塞尔参数 u，使 x(u)=xs。→ (C,N)"""
    x1 = np.asarray(x1s, dtype=np.float64)[:, None] / 127.0
    x2 = np.asarray(x2s, dtype=np.float64)[:, None] / 127.0
    lo = np.zeros((x1.shape[0], xs.shape[0]))
    hi = np.ones_like(lo)
    for _ in range(20):
        u = (lo + hi) * 0.5
        iu = 1 - u
        less = 3 * iu * iu * u * x1 + 3 * iu * u * u * x2 + u * u * u < xs
        lo = np.where(less, u, lo)
        hi = np.where(less, hi, u)
    return (lo + hi) * 0.5


def _basis(u):
    """y(u) = B1·y1 + B2·y2 + B3（y1/y2 为 0~1）：给定 x1/x2 时 y 对 y1/y2 是线性的。"""
    iu = 1 - u
    return 3 * iu * iu * u, 3 * iu * u * u, u * u * u


def _bez_y(c, xs):
    """c: (C,4) 整数控制点 x1,y1,x2,y2；xs: (N,) ∈[0,1] → (C,N)。"""
    c = np.asarray(c, dtype=np.float64)
    b1, b2, b3 = _basis(_solve_u(c[:, 0], c[:, 2], xs))
    return b1 * (c[:, 1:2] / 127) + b2 * (c[:, 3:4] / 127) + b3


def bez_y1(curve, x):
    return float(_bez_y([curve], np.array([x]))[0, 0])


_GRID = np.arange(4, 128, 8)
_GX1, _GX2 = (g.ravel() for g in np.meshgrid(_GRID, _GRID, indexing="ij"))


def _fit_group(xs, ys, ws, m0, m1, y_lo, basis_cache):
    """拟合一组通道共用的 VMD 曲线，返回 (C1 曲线, 自由曲线)。

    给定 x1/x2 后曲线 y 对 y1/y2 是线性的，所以在 (x1,x2) 网格上：
    - C1：两端切线固定为源相机真实速度（m0/m1），y1/y2 由切线直接算出，
      相邻区间在关键帧处速度连续；
    - 自由：y1/y2 用 2×2 正规方程直接解最小二乘最优。
    先粗网格（步长 8）再在最优点附近细化（步长 1）。
    ys: (K,N) 归一化目标，ws: (K,) 权重。
    """
    if ws.sum() <= 0 or xs.size == 0:
        return LINEAR, LINEAR
    lo = round(y_lo * 127)
    W = ws.sum()
    ybar = (ws[:, None] * ys).sum(axis=0) / W   # 多通道加权平均目标

    def basis(x1s, x2s, key):
        if key not in basis_cache:
            basis_cache[key] = _basis(_solve_u(x1s, x2s, xs))
        return basis_cache[key]

    def eval_c1(x1s, x2s, key):
        b1, b2, b3 = basis(x1s, x2s, key)
        y1 = np.clip(np.round(m0 * x1s), lo, 127)
        y2 = np.clip(np.round(127 - m1 * (127 - x2s)), lo, 127)
        pred = b1 * (y1[:, None] / 127) + b2 * (y2[:, None] / 127) + b3
        return ((pred - ybar) ** 2).sum(axis=1), y1, y2

    def eval_free(x1s, x2s, key):
        b1, b2, b3 = basis(x1s, x2s, key)
        r = ybar - b3
        a11 = (b1 * b1).sum(1); a12 = (b1 * b2).sum(1); a22 = (b2 * b2).sum(1)
        c1 = (b1 * r).sum(1); c2 = (b2 * r).sum(1)
        det = a11 * a22 - a12 * a12
        ok = np.abs(det) > 1e-12
        sd = np.where(ok, det, 1.0)
        y1 = np.where(ok, (c1 * a22 - c2 * a12) / sd, 0.0)
        y2 = np.where(ok, (a11 * c2 - a12 * c1) / sd, 1.0)
        # 超出 -128~127 时截断后，固定被截断的一个，重新求另一个的最优
        ylo, yhi = lo / 127, 1.0
        cl1 = (y1 < ylo) | (y1 > yhi)
        cl2 = (y2 < ylo) | (y2 > yhi)
        y1c, y2c = np.clip(y1, ylo, yhi), np.clip(y2, ylo, yhi)
        a11s = np.where(a11 > 1e-12, a11, 1.0)
        a22s = np.where(a22 > 1e-12, a22, 1.0)
        y2 = np.where(cl1 & ~cl2, np.clip((c2 - a12 * y1c) / a22s, ylo, yhi), y2c)
        y1 = np.where(cl2 & ~cl1, np.clip((c1 - a12 * y2c) / a11s, ylo, yhi), y1c)
        y1 = np.round(y1 * 127)
        y2 = np.round(y2 * 127)
        pred = b1 * (y1[:, None] / 127) + b2 * (y2[:, None] / 127) + b3
        return ((pred - ybar) ** 2).sum(axis=1), y1, y2

    out = []
    for ev in (eval_c1, eval_free):
        cost, y1, y2 = ev(_GX1, _GX2, "grid")
        k = int(np.argmin(cost))
        bx1, bx2 = int(_GX1[k]), int(_GX2[k])
        f1 = np.arange(max(0, bx1 - 8), min(127, bx1 + 8) + 1)
        f2 = np.arange(max(0, bx2 - 8), min(127, bx2 + 8) + 1)
        g1, g2 = (g.ravel() for g in np.meshgrid(f1, f2, indexing="ij"))
        cost, y1, y2 = ev(g1, g2, ("fine", bx1, bx2))
        k = int(np.argmin(cost))
        out.append((int(g1[k]), int(y1[k]), int(g2[k]), int(y2[k])))
    return out[0], out[1]


# ============================================================================
# 采样
# ============================================================================

class _Sample:
    __slots__ = ("p", "persp", "view", "pos", "depth", "cam", "cands", "has_target")


def _set_target(s: _Sample, tpos, min_distance, ref_depth):
    """把 MMD 目标点放到视线上、与 tpos 同深度处（tpos=None 则贴着相机）。"""
    if not s.persp:
        s.has_target = False
        return
    if tpos is not None:
        depth = (tpos - s.pos).dot(s.view)
        dis = -max(depth, min_distance)
        s.depth = max(depth, 0.5)
        s.has_target = True
    else:
        dis = -min_distance
        s.has_target = False
        if ref_depth > 0:
            s.depth = ref_depth
        else:  # 世界原点在视线上的深度；原点在背后/贴脸时用默认 5m
            d = (-s.pos).dot(s.view)
            s.depth = d if d >= 1.0 else 5.0
    t = s.pos - s.view * dis
    s.p[0], s.p[1], s.p[2], s.p[7] = t.x, t.y, t.z, dis


def _sample_source(scene, get_cam, get_target, frames, min_distance,
                   ref_depth, factor):
    """逐帧采样源相机。get_target(cam) 返回目标点世界坐标、候选坐标列表
    （多个角色，之后按镜头挑选）或 None。"""
    neg_z = Vector((0, 0, -1))
    out = []
    prev_rot = None
    for f in frames:
        scene.frame_set(f)
        cam = get_cam()
        tgt = get_target(cam)
        m = cam.matrix_world.copy()
        data = cam.data
        view = (m.to_3x3() @ neg_z).normalized()
        rot_m = m.to_3x3().normalized() @ _RXN90
        rot = (rot_m.to_euler("YXZ") if prev_rot is None
               else rot_m.to_euler("YXZ", prev_rot))
        prev_rot = rot

        tan_val = data.sensor_height / data.lens / 2
        if data.sensor_fit != "VERTICAL":
            ratio = data.sensor_width / data.sensor_height
            if data.sensor_fit == "HORIZONTAL":
                tan_val *= factor * ratio
            else:
                tan_val *= min(ratio, factor * ratio)

        s = _Sample()
        s.persp = data.type != "ORTHO"
        s.view = view
        s.pos = m.translation.copy()
        s.cam = cam.name
        s.cands = [v.copy() for v in tgt] if isinstance(tgt, list) else None
        s.p = [0.0, 0.0, 0.0, rot.x, rot.y, rot.z, 2 * math.atan(tan_val), 0.0]
        if not s.persp:
            dis = -(9 / 5) * data.ortho_scale
            if data.sensor_fit != "VERTICAL":
                dis *= factor if data.sensor_fit == "HORIZONTAL" else min(1, factor)
            t = s.pos - view * dis
            s.p[0], s.p[1], s.p[2], s.p[7] = t.x, t.y, t.z, dis
            s.depth, s.has_target = 5.0, False
        else:
            _set_target(s, None if s.cands is not None else tgt,
                        min_distance, ref_depth)
        out.append(s)
    return out


def _pick_candidate(samples):
    """多个候选角色时，选该镜头内平均最靠近画面中心（且在相机前方）的一个。"""
    k = len(samples[0].cands)
    best, best_score = None, None
    for j in range(k):
        score = 0.0
        for s in samples:
            v = s.cands[j] - s.pos
            d = v.dot(s.view)
            score += math.pi if d <= 0 else s.view.angle(v)
        if best_score is None or score < best_score:
            best, best_score = j, score
    return best


def _catmull(p0, p1, p2, p3, t):
    t2, t3 = t * t, t * t * t
    return [0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2
                   + (-a + 3 * b - 3 * c + d) * t3)
            for a, b, c, d in zip(p0, p1, p2, p3)]


# ============================================================================
# 自适应拟合
# ============================================================================

class AdaptiveResult:
    def __init__(self):
        self.keys = []      # [(frame, params[8], persp)]
        self.curves = {}    # frame(区间终点) → [6 条曲线]（作用于上一关键帧→本帧）
        self.cut_after = set()  # 区间终点帧：上一关键帧→本帧为切镜
        self.max_err = 0.0
        self.max_jit = 0.0
        self.cuts = []
        self.bad = []       # [(k0, k1, 跳动, 误差)] 达不到精度的区间
        self.rep = {}       # 各表示方式的镜头数


def _key_params(s: _Sample, fov_integer):
    """关键帧参数：视角取整，并沿视线平移相机补偿。

    平移量使深度 D 与 2D 处的画面缩放误差大小相等、方向相反
    （u=平移/D 满足 k/(1-u) + 2k/(2-u) = 2，k=tan(f/2)/tan(fi/2)），
    比只保证 D 处准确的最大误差约小一半。
    """
    p = list(s.p)
    if fov_integer and s.persp:
        fi = math.radians(max(1, round(math.degrees(p[6]))))
        k = math.tan(p[6] / 2) / math.tan(fi / 2)
        bq = 3 * k - 6
        u = (-bq - math.sqrt(max(0.0, bq * bq - 8 * (4 - 4 * k)))) / 4
        shift = s.depth * u
        if s.has_target:
            # 有目标点（Aim/角色）：保持目标点不动，改距离（相机沿视线前后移）
            p[7] += shift
        else:
            p[0] += s.view.x * shift
            p[1] += s.view.y * shift
            p[2] += s.view.z * shift
        p[6] = fi
    return p


def bake_adaptive(scene, get_cam, get_target, *, min_distance=0.1,
                  ref_depth=0.0, tol=1 / 1080, allow_negative=True,
                  fov_integer=True, origin_keys=frozenset(), min_gap=2,
                  report=None):
    """min_gap=2：同镜头内关键帧至少隔 2 帧（MMD 60fps 以上输出时相邻帧会被当成
    切镜），并评估半帧；min_gap=1：允许相邻帧，只评估整数帧（只能 30fps 输出）。"""
    render = scene.render
    factor = ((render.resolution_y * render.pixel_aspect_y)
              / (render.resolution_x * render.pixel_aspect_x))
    aspect = 1 / factor
    frames = list(range(scene.frame_start, scene.frame_end + 1))
    cur = scene.frame_current
    smp = _sample_source(scene, get_cam, get_target, frames, min_distance,
                         ref_depth, factor)
    scene.frame_set(cur)
    n = len(smp)
    y_lo = -128 / 127 if allow_negative else 0.0
    # 跳动按 tol 控制；平滑偏差在 abs_tol 以内视为看不出来
    abs_tol = tol * 6

    refs = [_Ref(s.p, s.persp, s.depth, aspect) for s in smp]

    # ---- 切镜检测 ----
    move = [0.0] * n
    for i in range(1, n):
        if smp[i].persp != smp[i - 1].persp:
            move[i] = 10.0
        else:
            move[i] = _screen_err(smp[i - 1].p, smp[i].persp, refs[i])
    cut = [False] * n
    for i in range(1, n):
        a = smp[i - 1]
        b = smp[i]
        neigh = max(move[i - 1] if i > 1 else 0.0,
                    move[i + 1] if i + 1 < n else 0.0)
        if a.cam != b.cam or a.persp != b.persp:
            cut[i] = True
        elif move[i] > 0.03 and move[i] > 2.5 * neigh:
            cut[i] = True
        elif (frames[i - 1] in origin_keys and frames[i] in origin_keys
              and move[i] > 0.01 and move[i] > 1.5 * neigh):
            cut[i] = True

    segs = []
    start = 0
    for i in range(1, n):
        if cut[i]:
            segs.append((start, i - 1))
            start = i
    segs.append((start, n - 1))

    # 角色作为参考点：每个镜头挑一个角色，并锁定在该镜头第一帧时的位置
    # （同 M2U 默认的"锁定导出起始帧"；跟随舞蹈动作晃动反而增加曲线负担）
    for a, b in segs:
        if smp[a].cands:
            j = _pick_candidate(smp[a:b + 1])
            anchor = smp[a].cands[j]
            for s in smp[a:b + 1]:
                _set_target(s, anchor, min_distance, ref_depth)

    # 每个镜头选表示方式：目标点放在参考点（Aim/角色）上，还是贴近相机。
    # MMD 在关键帧间插值的是目标点，选目标点路径短的那种：
    # 原地摇镜 → 贴近相机（目标点不动）；绕角色转 → 参考点（目标点不动）。
    res_rep = {"参考点": 0, "贴近相机": 0}
    for a, b in segs:
        seg = smp[a:b + 1]
        if not any(s.has_target for s in seg):
            continue
        path_t = sum((Vector(seg[i].p[:3]) - Vector(seg[i - 1].p[:3])).length
                     for i in range(1, len(seg)))
        path_c = sum((seg[i].pos - seg[i - 1].pos).length for i in range(1, len(seg)))
        if path_c < path_t:
            for s in seg:
                d = s.depth
                _set_target(s, None, min_distance, ref_depth)
                s.depth = d      # 误差评估/补偿仍用参考点的深度
            res_rep["贴近相机"] += 1
        else:
            res_rep["参考点"] += 1
    refs = [_Ref(s.p, s.persp, s.depth, aspect) for s in smp]
    half_frames = min_gap >= 2
    step = 0.5 if half_frames else 1.0

    res = AdaptiveResult()
    res.rep = res_rep
    res.cuts = [frames[i] for i in range(1, n) if cut[i]]
    keyp = {}

    def kp(i):
        if i not in keyp:
            keyp[i] = _key_params(smp[i], fov_integer)
        return keyp[i]

    half_cache = {}

    def half(i, a, b):
        """段 [a,b] 内第 i 与 i+1 帧之间半帧的源参数（Catmull-Rom 估计）。"""
        if i not in half_cache:
            p = _catmull(smp[max(a, i - 1)].p, smp[i].p, smp[i + 1].p,
                         smp[min(b, i + 2)].p, 0.5)
            depth = (smp[i].depth + smp[i + 1].depth) / 2
            half_cache[i] = (p, _Ref(p, smp[i].persp, depth, aspect))
        return half_cache[i]

    def sample_times(k0, k1, a, b):
        """区间 (k0,k1) 内的评估时刻：中间整数帧，以及（60fps 以上输出时）半帧。"""
        out = []
        for i in range(k0, k1):
            if half_frames:
                p, r = half(i, a, b)
                out.append((i + 0.5, r, p))
            if i + 1 < k1:
                out.append((i + 1, refs[i + 1], smp[i + 1].p))
        return out

    def deriv(i, c, a, b):
        """源参数 c 在第 i 帧的速度（每帧），段内中心差分，段端单侧差分。"""
        if a < i < b:
            return (smp[i + 1].p[c] - smp[i - 1].p[c]) / 2
        if i == a and b > a:
            return smp[a + 1].p[c] - smp[a].p[c]
        if i == b and b > a:
            return smp[b].p[c] - smp[b - 1].p[c]
        return 0.0

    key_err = {}

    def key_vec(i):
        """关键帧自身（视角取整+补偿）相对源相机的屏幕误差向量。"""
        if i not in key_err:
            key_err[i] = _err_vec(kp(i), smp[i].persp, refs[i])
        return key_err[i]

    def fit_interval(k0, k1, a, b):
        """拟合区间曲线，返回 (曲线, {时刻: 屏幕误差向量})。

        每组曲线有三种拟合：切线连续（C1）、自由最小二乘、直线。
        旋转三轴共用一条曲线，轴间节奏不同时 C1 反而会在关键帧处拐弯，
        所以几种组合都试一遍，按画面上的跳动+偏差选最好的。
        """
        L = k1 - k0
        p0, p1 = kp(k0), kp(k1)
        st = sample_times(k0, k1, a, b)
        xs = np.array([(t - k0) / L for t, _, _ in st])
        c1, free = [], []
        basis_cache = {}
        for g in GROUPS:
            ys, ws, m0s, m1s = [], [], [], []
            for c in g:
                d = p1[c] - p0[c]
                if abs(d) < _EPS[c]:
                    continue
                ys.append([(sp[c] - p0[c]) / d for _, _, sp in st])
                ws.append(d * d)
                m0s.append(deriv(k0, c, a, b) * L / d)
                m1s.append(deriv(k1, c, a, b) * L / d)
            if not ys or xs.size == 0:
                c1.append(LINEAR)
                free.append(LINEAR)
                continue
            ys, ws = np.array(ys), np.array(ws)
            wn = ws / ws.sum()
            cv_c1, cv_free = _fit_group(xs, ys, ws, float(np.dot(m0s, wn)),
                                        float(np.dot(m1s, wn)), y_lo, basis_cache)
            c1.append(cv_c1)
            free.append(cv_free)
        lin = [LINEAR] * len(GROUPS)
        variants = []
        for curves in (c1, free, lin, c1[:3] + [free[3]] + c1[4:],
                       c1[:3] + [LINEAR] + c1[4:], free[:3] + [LINEAR] + free[4:]):
            if curves not in variants:
                variants.append(curves)

        persp = smp[k0].persp
        e0, e1 = key_vec(k0), key_vec(k1)
        bez_cache = {}
        out = []
        for curves in variants:
            ys = []
            for cv in curves:
                if cv not in bez_cache:
                    bez_cache[cv] = _bez_y([cv], xs)[0]
                ys.append(bez_cache[cv])
            errs = {}
            for j, (t, ref, _) in enumerate(st):
                p = [p0[c] + ys[CH_GROUP[c]][j] * (p1[c] - p0[c]) for c in range(N_CH)]
                errs[t] = _err_vec(p, persp, ref)
            seq = [e0] + [errs[t] for t, _, _ in st] + [e1]
            jit = 0.0
            for u, v, w in zip(seq, seq[1:], seq[2:]):
                d = u - 2 * v + w
                jit = max(jit, float(np.hypot(d[:, 0], d[:, 1]).max()))
            f0, f1 = float(np.abs(e0).max()), float(np.abs(e1).max())
            xq = [0.0] + list(xs) + [1.0]
            err = max(float(np.abs(e).max()) - (f0 + (f1 - f0) * x)
                      for e, x in zip(seq, xq))
            out.append((jit + max(0.0, err - abs_tol) + 0.01 * err, curves, errs))
        out.sort(key=lambda v: v[0])
        # (当前选用的曲线, 误差, 全部候选方案) —— 候选留给后处理按相邻区间重选
        return out[0][1], out[0][2], [(c, e) for _, c, e in out]

    def fov_cross_keys(a, b):
        """段内视角每跨过一个整数度，取最接近该整数的帧作为关键帧（间隔≥min_gap）。"""
        if not fov_integer or not smp[a].persp:
            return []
        degs = [math.degrees(smp[i].p[6]) for i in range(a, b + 1)]
        cands = []
        for j in range(len(degs) - 1):
            lo, hi = sorted((degs[j], degs[j + 1]))
            for k in range(math.ceil(lo), math.floor(hi) + 1):
                if lo < k <= hi or (k == lo and j == 0):
                    i = a + (j if abs(degs[j] - k) <= abs(degs[j + 1] - k) else j + 1)
                    cands.append((abs(math.degrees(smp[i].p[6]) - k), i))
        chosen = []
        for _, i in sorted(cands):
            if i - a < min_gap or b - i < min_gap:
                continue
            if all(abs(i - c) >= min_gap for c in chosen):
                chosen.append(i)
        return sorted(chosen)

    for a, b in segs:
        if a == b:
            res.keys.append(a)
            continue
        # 必选关键帧：段首尾 + 视角穿过整数的帧
        pins = [a] + fov_cross_keys(a, b) + [b]
        fits = {(k0, k1): fit_interval(k0, k1, a, b)
                for k0, k1 in zip(pins, pins[1:])}
        klist = list(pins)

        def E(t, over=None):
            """时刻 t 的屏幕误差向量（over：试算中的临时区间）。"""
            j = bisect.bisect_left(klist, t)
            if j < len(klist) and klist[j] == t:
                return key_vec(int(t))
            iv = (klist[j - 1], klist[j])
            if over and iv in over:
                return over[iv][1][t]
            return fits[iv][1][t]

        def key_floor(i):
            return float(np.abs(key_vec(i)).max())

        def span_cost(k0, k1, over=None):
            """区间 [k0,k1] 上的代价：跳动（误差二阶差分）+ 超出绝对容差的误差。

            关键帧自身的视角取整误差是静态的、看不出来，所以偏差只计
            超出两端关键帧误差线性过渡的部分。返回 (代价, 跳动, 超额偏差, 原始偏差)。
            """
            jit = excess = raw = 0.0
            t = float(k0)
            while t <= k1:
                e = E(t, over)
                m = float(np.abs(e).max())
                raw = max(raw, m)
                j = bisect.bisect_right(klist, t)
                kl, kr = klist[j - 1], klist[min(j, len(klist) - 1)]
                if kl == t or kr == kl:
                    allow = key_floor(kl)
                else:
                    x = (t - kl) / (kr - kl)
                    allow = key_floor(kl) * (1 - x) + key_floor(kr) * x
                excess = max(excess, m - allow)
                if a < t - step and t + step < b:
                    d = E(t - step, over) - 2 * e + E(t + step, over)
                    jit = max(jit, float(np.hypot(d[:, 0], d[:, 1]).max()))
                t += step
            return jit + max(0.0, excess - abs_tol), jit, excess, raw

        final = set()
        cost_cache = {}
        while True:
            worst, worst_c = None, tol
            for iv in fits:
                if iv in final:
                    continue
                if iv not in cost_cache:
                    cost_cache[iv] = span_cost(*iv)[0]
                if cost_cache[iv] > worst_c:
                    worst, worst_c = iv, cost_cache[iv]
            if worst is None:
                break
            k0, k1 = worst
            if k1 - k0 < 2 * min_gap:
                final.add(worst)
                continue
            # 候选：误差或跳动最大的若干帧
            score = []
            for c in range(k0 + min_gap, k1 - min_gap + 1):
                e = E(float(c))
                score.append((float(np.abs(e).max()), c))
            score.sort(reverse=True)
            # 偏差超出绝对容差：无条件在候选里挑代价最小的拆（误差可能分布在
            # 多处，单次拆分未必降低最大值，但逐步细分一定收敛）；
            # 偏差已在容差内、只为降低跳动时：要求明显改善，避免加入有害关键帧
            w_err = span_cost(k0, k1)[2]
            need = math.inf if w_err > abs_tol else worst_c * 0.9
            best, best_cost, best_fit = None, need, None
            for _, c in score[:6]:
                over = {(k0, c): fit_interval(k0, c, a, b),
                        (c, k1): fit_interval(c, k1, a, b)}
                bisect.insort(klist, c)
                cost = span_cost(k0, k1, over)[0]
                klist.remove(c)
                if cost < best_cost:
                    best, best_cost, best_fit = c, cost, over
            if best is None:
                final.add(worst)
                continue
            del fits[worst]
            fits.update(best_fit)
            bisect.insort(klist, best)
            # 两端关键帧处的跳动依赖相邻区间：相邻区间的代价需要重算
            for iv in list(cost_cache):
                if iv[0] in (k0, k1) or iv[1] in (k0, k1):
                    del cost_cache[iv]
                    final.discard(iv)

        # 后处理：关键帧定下后，逐区间在候选曲线方案中重选，
        # 这次把两端关键帧处的拐点（依赖相邻区间）也计入代价
        for _ in range(3):
            changed = False
            for iv in sorted(fits):
                cur_curves, _, alts = fits[iv]
                best, best_cost = None, None
                for curves, errs in alts:
                    fits[iv] = (curves, errs, alts)
                    cost = span_cost(*iv)[0]
                    if best_cost is None or cost < best_cost - 1e-12:
                        best, best_cost = (curves, errs), cost
                fits[iv] = (best[0], best[1], alts)
                changed |= best[0] != cur_curves
            if not changed:
                break

        res.keys.append(a)
        for (k0, k1), (curves, _, _) in sorted(fits.items()):
            res.keys.append(k1)
            res.curves[k1] = curves
            total, jit, _, err = span_cost(k0, k1)
            res.max_err = max(res.max_err, err)
            res.max_jit = max(res.max_jit, jit)
            if total > tol:
                res.bad.append((frames[k0], frames[k1], jit, err))

    res.keys = sorted(set(res.keys))
    seg_start = {a for a, _ in segs}
    out = []
    for i in res.keys:
        out.append((frames[i], kp(i), smp[i].persp))
        if i in seg_start and i > 0:
            res.cut_after.add(frames[i])
    res.curves = {frames[i]: c for i, c in res.curves.items()}
    res.keys = out
    if report:
        ry = render.resolution_y
        report(f"关键帧 {len(out)} 个 / {n} 帧，切镜 {len(res.cuts)} 处，"
               f"最大跳动 {res.max_jit * ry:.1f}px，最大偏差 {res.max_err * ry:.1f}px"
               f"（画面高 {ry}px）"
               + ("，目标点在参考点/贴近相机的镜头 "
                  f"{res.rep['参考点']}/{res.rep['贴近相机']} 个" if any(res.rep.values()) else ""))
    return res


# ============================================================================
# 写入 Blender MMD 相机
# ============================================================================

def apply_to_mmd_camera(root, cam, res: AdaptiveResult):
    action = bpy.data.actions.new(name=root.name)
    dis_action = bpy.data.actions.new(name=root.name + "_dis")
    fcs = [action.fcurves.new(data_path="location", index=i) for i in range(3)]
    fcs += [action.fcurves.new(data_path="rotation_euler", index=i) for i in range(3)]
    fcs.append(action.fcurves.new(data_path="mmd_camera.angle"))
    fcs.append(dis_action.fcurves.new(data_path="location", index=1))
    persp_fc = action.fcurves.new(data_path="mmd_camera.is_perspective")

    keys = res.keys
    nk = len(keys)
    for fc in fcs + [persp_fc]:
        fc.keyframe_points.add(nk)

    for j, (f, p, persp) in enumerate(keys):
        pk = persp_fc.keyframe_points[j]
        pk.co = (f, float(persp))
        pk.interpolation = "CONSTANT"
        for c, fc in enumerate(fcs):
            k = fc.keyframe_points[j]
            k.co = (f, p[c])
            k.handle_left_type = "FREE"
            k.handle_right_type = "FREE"
            k.handle_left = (f, p[c])
            k.handle_right = (f, p[c])
            k.interpolation = "BEZIER"

    for j in range(1, nk):
        f0, p0, _ = keys[j - 1]
        f1, p1, _ = keys[j]
        L = f1 - f0
        curves = res.curves.get(f1)
        is_cut = f1 in res.cut_after or curves is None
        for c, fc in enumerate(fcs):
            k0 = fc.keyframe_points[j - 1]
            k1 = fc.keyframe_points[j]
            if is_cut:
                k0.interpolation = "CONSTANT"
                continue
            x1, y1, x2, y2 = curves[CH_GROUP[c]]
            d = p1[c] - p0[c]
            k0.handle_right = (f0 + x1 / 127 * L, p0[c] + y1 / 127 * d)
            k1.handle_left = (f0 + x2 / 127 * L, p0[c] + y2 / 127 * d)

    for fc in fcs + [persp_fc]:
        fc.update()
    root.animation_data_create().action = action
    cam.animation_data_create().action = dis_action


# ============================================================================
# 相机 VMD 导出（不经过 mmd_tools）
# ============================================================================

def _curve_from_handles(k0, k1):
    L = k1.co.x - k0.co.x
    d = k1.co.y - k0.co.y
    if k0.interpolation != "BEZIER" or L <= 0 or abs(d) < 1e-9:
        return LINEAR, 0.0
    q = lambda v, lo: max(lo, min(127, round(v * 127)))
    return (q((k0.handle_right.x - k0.co.x) / L, 0),
            q((k0.handle_right.y - k0.co.y) / d, -128),
            q((k1.handle_left.x - k0.co.x) / L, 0),
            q((k1.handle_left.y - k0.co.y) / d, -128)), abs(d)


def export_camera_vmd(filepath, root, scale=12.5, frame_offset=1):
    """导出 MMD 相机（mmd_type=CAMERA 的 Empty）的动画为 VMD。

    要求所有通道在相同帧上有关键帧（自适应烘焙的结果满足）；
    否则在并集帧上逐通道采样，曲线退化为线性。返回 (关键帧数, 警告)。
    """
    cam = next(c for c in root.children if c.type == "CAMERA")
    act = root.animation_data and root.animation_data.action
    dact = cam.animation_data and cam.animation_data.action
    if not act:
        raise RuntimeError(f"{root.name} 没有动画")

    def find(a, path, idx=0):
        if not a:
            return None
        for fc in a.fcurves:
            if fc.data_path == path and fc.array_index == idx:
                return fc
        return None

    fcs = [find(act, "location", i) for i in range(3)]
    fcs += [find(act, "rotation_euler", i) for i in range(3)]
    fcs.append(find(act, "mmd_camera.angle"))
    fcs.append(find(dact, "location", 1))
    persp_fc = find(act, "mmd_camera.is_perspective")
    defaults = list(root.location) + list(root.rotation_euler) + [
        root.mmd_camera.angle, cam.location.y]

    frame_sets = [None if fc is None else
                  [round(k.co.x) for k in fc.keyframe_points] for fc in fcs]
    all_frames = sorted({f for s in frame_sets if s for f in s})
    exact = all(s is not None and s == all_frames for s in frame_sets)
    warn = None if exact else "各通道关键帧不一致，已逐帧采样，曲线退化为线性"

    def persp_at(f):
        return bool(persp_fc.evaluate(f) > 0.5) if persp_fc else root.mmd_camera.is_perspective

    out = []
    for j, f in enumerate(all_frames):
        vals = [fc.evaluate(f) if fc else defaults[c] for c, fc in enumerate(fcs)]
        curves = [LINEAR] * 6
        if exact and j > 0:
            rot_best = 0.0
            for c, fc in enumerate(fcs):
                cv, mag = _curve_from_handles(fc.keyframe_points[j - 1],
                                              fc.keyframe_points[j])
                g = CH_GROUP[c]
                if g == 3:
                    if mag > rot_best:
                        rot_best, curves[3] = mag, cv
                else:
                    curves[g] = cv
        out.append((f, vals, curves, persp_at(f)))

    with open(filepath, "wb") as fp:
        fp.write(struct.pack("<30s", b"Vocaloid Motion Data 0002"))
        fp.write(struct.pack("<20s", "カメラ・照明".encode("cp932")))
        fp.write(struct.pack("<II", 0, 0))
        fp.write(struct.pack("<I", len(out)))
        for f, v, cv, persp in out:
            # VMD 曲线组顺序 X Y Z 旋转 距离 视角；VMD 的 Y/Z 对应 Blender 的 z/y
            order = (cv[0], cv[2], cv[1], cv[3], cv[5], cv[4])
            interp = []
            for x1, y1, x2, y2 in order:
                interp += [x1, x2, y1, y2]
            fp.write(struct.pack(
                "<If3f3f24bIb",
                max(0, f - frame_offset),
                v[7] * scale,
                v[0] * scale, v[2] * scale, v[1] * scale,
                v[3], v[5], v[4],
                *interp,
                max(1, round(math.degrees(v[6]))),
                0 if persp else 1))
        fp.write(struct.pack("<II", 0, 0))
    return len(out), warn
