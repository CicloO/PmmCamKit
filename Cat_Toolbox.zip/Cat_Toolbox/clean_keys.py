"""Clean exactly colinear redundant keyframes on target armature / mesh morphs."""

from __future__ import annotations

import bpy


def _actions_on_id(id_data: bpy.types.ID) -> list:
    ad = getattr(id_data, "animation_data", None)
    if not ad:
        return []
    actions = []
    if ad.action:
        actions.append(ad.action)
    for track in getattr(ad, "nla_tracks", []) or []:
        for strip in track.strips:
            if strip.action and strip.action not in actions:
                actions.append(strip.action)
    return actions


def _fcurves_for_action(action) -> list:
    if hasattr(action, "fcurves") and action.fcurves is not None:
        return list(action.fcurves)
    curves = []
    for layer in getattr(action, "layers", []) or []:
        for strip in getattr(layer, "strips", []) or []:
            for ch in getattr(strip, "channelbags", []) or []:
                curves.extend(list(getattr(ch, "fcurves", []) or []))
    return curves


def _is_exactly_colinear(prev, curr, nxt) -> bool:
    """三点在帧-数值平面上是否完全共线（浮点精确相等）。"""
    # (curr - prev) × (nxt - prev) == 0
    ax = curr.co.x - prev.co.x
    ay = curr.co.y - prev.co.y
    bx = nxt.co.x - prev.co.x
    by = nxt.co.y - prev.co.y
    return ax * by == ay * bx


def clean_fcurve(fcurve) -> int:
    """反复删除严格落在相邻键连线上的中间关键帧，直到没有可删点。"""
    pts = fcurve.keyframe_points
    removed_total = 0

    while len(pts) >= 3:
        remove_idx: list[int] = []
        n = len(pts)
        for i in range(1, n - 1):
            if _is_exactly_colinear(pts[i - 1], pts[i], pts[i + 1]):
                remove_idx.append(i)
        if not remove_idx:
            break
        for i in reversed(remove_idx):
            try:
                pts.remove(pts[i])
                removed_total += 1
            except Exception:
                pass

    if removed_total:
        fcurve.update()
    return removed_total


def clean_id_keyframes(id_data: bpy.types.ID) -> int:
    total = 0
    for action in _actions_on_id(id_data):
        for fc in _fcurves_for_action(action):
            total += clean_fcurve(fc)
    return total


def clean_target_keyframes(
    target_arm: bpy.types.Object | None,
    target_mesh: bpy.types.Object | None,
) -> str:
    """仅清理目标骨架与目标网格形态键上完全共线的冗余关键帧。"""
    bone_n = 0
    morph_n = 0
    if target_arm and target_arm.type == "ARMATURE":
        bone_n = clean_id_keyframes(target_arm)
    if target_mesh and target_mesh.type == "MESH" and target_mesh.data.shape_keys:
        morph_n = clean_id_keyframes(target_mesh.data.shape_keys)
    return f"清理完成: 目标骨架删键={bone_n}, 目标形态键删键={morph_n}"
