# Face Eyes Ctrl Transfer

按**范例-2**绑定方式，从内置静态模板生成 `Face_Rig` 并接到 MMD 模型；亦可用于 **Rigify/MMR**（目标骨架仍在）场景。

## 绑定

| 项 | 行为 |
|----|------|
| Face_Rig | 无父级，世界原点 `(0,0,0)` |
| Face `MCH-face_root` | 对齐目標 `頭` 头尾；Copy Transforms → `頭` |
| Eyes `MCH-eyes_root` | 对齐目標 `頭`；Copy Transforms → `頭` |
| Eyes 眼骨 | 按《眼部绑定》对齐 `目.L/R`；CTRL Y 前移 0.1 |
| 目标 `目.L` / `目.R` | **普通模式**：断开与頭父子；Child Of → `MCH-eye_*` |
| Morph | Rig → `.placeholder` → 网格全量镜像（策略 B） |
| Look | `CTL-eye-Look` LOCAL → `MCH-eye_*` 旋转 |

## Rigify 兼容

侧栏 **Rigify兼容**：自动 / 开 / 关。

- **自动**：目标 `頭`/`目` 上若有指向另一骨架（如 `RIG-*`）的 Copy Transforms，则启用兼容
- **兼容开启时**：
  - 将 Face/Eyes 控制器**骨骼合并进 Rigify 控制骨架**（不再创建独立 `Face_Rig` 物体）
  - 静音目标 `目` 上指向 Rigify 的复制约束，并隐藏 Rigify 原眼/睑控制器
  - 形态键 + Look + 目 Child Of 仍由合并后的 CTL 驱动
- **关闭 / 非 Rigify**：逻辑不变，仍创建独立 `Face_Rig`

## 果冻眼

侧栏 **果冻眼绑定**（位于烘焙按钮上方）：

- 按范例原样生成/更新 `Eyes_Physics`（不对齐头/眼）
- 根骨驱动：`PHYS_Bone01.location.x = まばたき*0.05 + 笑い*0.05`
- **瞳小**（写在 `.placeholder`，与 Face_Rig 并存相加）：
  `eye_small*25 + jelly*3`
  （`CTL-eye_small` + `PHYS_Bone03` 变换通道 LOC_X，世界空间）
- 形态键优先读 `.placeholder`，否则用侧栏目标网格

## 使用

1. 侧栏 **FaceEyes** → 自动识别目标  
2. 确认 Rigify 兼容状态 → 一键应用控制器  
3. （可选）果冻眼绑定  
