"""Operator: 果冻眼绑定/解除（Eyes_Physics）。"""

from __future__ import annotations

import bpy
from bpy.types import Operator

from . import jelly_eyes
from .props import auto_fill_settings


class FACE_EYES_OT_jelly_eyes(Operator):
    bl_idname = "face_eyes_ctrl.jelly_eyes"
    bl_label = "果冻眼绑定"
    bl_description = (
        "生成/更新 Eyes_Physics，并挂驱动："
        "根骨←眨眼/笑；瞳小←CTL-eye_small*25 + 尖端变换X*3"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.face_eyes_ctrl
        auto_fill_settings(context)

        try:
            if context.object and context.object.mode != "OBJECT":
                with context.temp_override(
                    active_object=context.object,
                    object=context.object,
                ):
                    bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass

        had_existing = jelly_eyes.find_eyes_physics() is not None
        try:
            msg = jelly_eyes.setup_jelly_eyes(
                context,
                recreate=False,
                jelly_mode=s.jelly_mode,
            )
            s.last_report = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        except Exception as e:
            # 仅清理本次新建失败的半成品
            if not had_existing:
                ep = jelly_eyes.find_eyes_physics()
                if ep:
                    data = ep.data
                    bpy.data.objects.remove(ep, do_unlink=True)
                    if data and data.users == 0:
                        bpy.data.armatures.remove(data)
            s.last_report = f"果冻眼失败: {e}"
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}


class FACE_EYES_OT_jelly_eyes_remove(Operator):
    bl_idname = "face_eyes_ctrl.jelly_eyes_remove"
    bl_label = "删除果冻眼绑定"
    bl_description = "删除 Eyes_Physics 并清理相关驱动（瞳小驱动），不影响其他绑定"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.face_eyes_ctrl
        try:
            msg = jelly_eyes.remove_jelly_eyes(context)
            s.last_report = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        except Exception as e:
            s.last_report = f"删除果冻眼失败: {e}"
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}


CLASSES = (
    FACE_EYES_OT_jelly_eyes,
    FACE_EYES_OT_jelly_eyes_remove,
)
