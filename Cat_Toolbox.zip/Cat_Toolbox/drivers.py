"""Driver helpers for strategy B: Rig → placeholder → mesh."""

from __future__ import annotations

import re
from typing import Iterable

import bpy

from .mapping import (
    EYE_LOOK_DRIVERS,
    MORPH_DRIVERS,
    resolve_morph_name,
)

_KEY_PATH_RE = re.compile(r'key_blocks\["(.+?)"\]')


def _ensure_anim_data(id_data: bpy.types.ID):
    if id_data.animation_data is None:
        id_data.animation_data_create()
    return id_data.animation_data


def remove_drivers_matching(id_data: bpy.types.ID, data_path_substr: str | None = None):
    ad = id_data.animation_data
    if not ad:
        return 0
    to_remove = []
    for fc in ad.drivers:
        if data_path_substr is None or data_path_substr in fc.data_path:
            to_remove.append(fc.data_path if fc.array_index < 0 else (fc.data_path, fc.array_index))
    # Remove via driver_remove API
    removed = 0
    for fc in list(ad.drivers):
        if data_path_substr is None or data_path_substr in fc.data_path:
            try:
                id_data.driver_remove(fc.data_path, fc.array_index)
                removed += 1
            except TypeError:
                try:
                    id_data.driver_remove(fc.data_path)
                    removed += 1
                except Exception:
                    pass
    return removed


def clear_shape_key_drivers(obj: bpy.types.Object) -> int:
    if not obj or obj.type != "MESH" or not obj.data.shape_keys:
        return 0
    return remove_drivers_matching(obj.data.shape_keys)


def add_transform_var(driver, var_name: str, target_obj: bpy.types.Object, bone: str, transform_type: str, space: str = "LOCAL_SPACE"):
    var = driver.variables.new()
    var.name = var_name
    var.type = "TRANSFORMS"
    t = var.targets[0]
    t.id = target_obj
    t.bone_target = bone
    t.transform_type = transform_type
    t.transform_space = space
    return var


def add_single_prop_var(driver, var_name: str, target_obj: bpy.types.Object, data_path: str):
    var = driver.variables.new()
    var.name = var_name
    var.type = "SINGLE_PROP"
    t = var.targets[0]
    t.id = target_obj
    t.data_path = data_path
    return var


def ensure_shape_keys(obj: bpy.types.Object, key_names: Iterable[str]) -> bpy.types.Key:
    """Ensure Basis + listed shape keys exist on mesh object."""
    if obj.data.shape_keys is None:
        obj.shape_key_add(name="Basis", from_mix=False)
    sk = obj.data.shape_keys
    existing = {kb.name for kb in sk.key_blocks}
    for name in key_names:
        if name not in existing:
            kb = obj.shape_key_add(name=name, from_mix=False)
            # Keep as empty morph (same as Basis) — value will be driven
            kb.value = 0.0
            existing.add(name)
    return sk


def prepare_tongxiao_slider_min(mesh_obj: bpy.types.Object, minimum: float = -1.0) -> bool:
    """绑定前将「瞳小」形态键范围下限改为 minimum（默认 -1），以支持负向 CTL。"""
    if not mesh_obj or mesh_obj.type != "MESH" or not mesh_obj.data.shape_keys:
        return False
    kb = mesh_obj.data.shape_keys.key_blocks.get("瞳小")
    if not kb:
        return False
    kb.slider_min = float(minimum)
    return True


def all_mesh_morph_names(mesh_obj: bpy.types.Object) -> set[str]:
    """All shape key names on mesh except Basis (original mirrors the full set)."""
    if not mesh_obj or not mesh_obj.data.shape_keys:
        return set()
    return {kb.name for kb in mesh_obj.data.shape_keys.key_blocks if kb.name != "Basis"}


def build_placeholder_morph_drivers(
    placeholder: bpy.types.Object,
    face_rig: bpy.types.Object,
    eyes_rig: bpy.types.Object,
    morph_names_on_target: set[str],
    morph_drivers: list | None = None,
) -> tuple[int, list[str]]:
    """Create Rig→placeholder drivers for mapped morphs that exist on the target mesh.

    Also ensures placeholder has the full morph key set (same hub role as original .placeholder).
    形态键名经 MORPH_NAME_ALIASES 解析（如 ｷﾘｯ↔怒り目）。

    morph_drivers: 可选的自定义驱动映射列表。为 None 时使用默认 MORPH_DRIVERS。
    """
    drivers_list = MORPH_DRIVERS if morph_drivers is None else morph_drivers

    # Full morph set on placeholder (like original project)
    ensure_shape_keys(placeholder, sorted(morph_names_on_target))
    sk = placeholder.data.shape_keys

    resolved_names: set[str] = set()
    for key_name, _expr, _vars in drivers_list:
        actual = resolve_morph_name(key_name, morph_names_on_target)
        if actual:
            resolved_names.add(actual)

    if sk.animation_data:
        for fc in list(sk.animation_data.drivers):
            m = _KEY_PATH_RE.search(fc.data_path)
            if m and m.group(1) in resolved_names:
                try:
                    sk.driver_remove(fc.data_path)
                except Exception:
                    pass

    applied = 0
    missing = []
    role_map = {"face": face_rig, "eyes": eyes_rig}

    for key_name, expr, vars_spec in drivers_list:
        actual = resolve_morph_name(key_name, morph_names_on_target)
        if not actual:
            missing.append(key_name)
            continue
        data_path = f'key_blocks["{actual}"].value'
        fcurve = sk.driver_add(data_path)
        driver = fcurve.driver
        driver.type = "SCRIPTED"
        driver.expression = expr
        while driver.variables:
            driver.variables.remove(driver.variables[0])
        for var_name, role, bone, transform in vars_spec:
            # LOCAL_SPACE — same as original project
            add_transform_var(driver, var_name, role_map[role], bone, transform, "LOCAL_SPACE")
        applied += 1

    return applied, missing


def build_mesh_mirror_drivers(
    mesh_obj: bpy.types.Object,
    placeholder: bpy.types.Object,
    morph_names: set[str] | None = None,
) -> int:
    """Create placeholder→mesh mirror drivers (expression v1), same as original.

    If morph_names is None, mirror every non-Basis key shared by mesh and placeholder.
    """
    if not mesh_obj.data.shape_keys:
        return 0
    if morph_names is None:
        morph_names = all_mesh_morph_names(mesh_obj)

    ensure_shape_keys(placeholder, sorted(morph_names))
    sk = mesh_obj.data.shape_keys

    if sk.animation_data:
        for fc in list(sk.animation_data.drivers):
            m = _KEY_PATH_RE.search(fc.data_path)
            if m and m.group(1) in morph_names:
                try:
                    sk.driver_remove(fc.data_path)
                except Exception:
                    pass

    count = 0
    for name in morph_names:
        if name not in sk.key_blocks:
            continue
        if name not in placeholder.data.shape_keys.key_blocks:
            continue
        data_path = f'key_blocks["{name}"].value'
        fcurve = sk.driver_add(data_path)
        driver = fcurve.driver
        driver.type = "SCRIPTED"
        driver.expression = "v1"
        while driver.variables:
            driver.variables.remove(driver.variables[0])
        add_single_prop_var(
            driver,
            "v1",
            placeholder,
            f'data.shape_keys.key_blocks["{name}"].value',
        )
        count += 1
    return count


def build_eye_look_drivers(eyes_rig: bpy.types.Object, face_rig: bpy.types.Object) -> int:
    """Rebuild CTL-eye-Look → MCH-eye_L/R rotation drivers (LOCAL_SPACE, same as original)."""
    ad = eyes_rig.animation_data
    if ad:
        for fc in list(ad.drivers):
            if "MCH-eye_" in fc.data_path and "rotation_euler" in fc.data_path:
                try:
                    eyes_rig.driver_remove(fc.data_path, fc.array_index)
                except Exception:
                    try:
                        eyes_rig.driver_remove(fc.data_path)
                    except Exception:
                        pass

    count = 0
    for bone, index, expr, transform in EYE_LOOK_DRIVERS:
        data_path = f'pose.bones["{bone}"].rotation_euler'
        fcurve = eyes_rig.driver_add(data_path, index)
        driver = fcurve.driver
        driver.type = "SCRIPTED"
        driver.expression = expr
        while driver.variables:
            driver.variables.remove(driver.variables[0])
        add_transform_var(driver, "eye_look", face_rig, "CTL-eye-Look", transform, "LOCAL_SPACE")
        count += 1
    return count


def set_morph_slider_min(mesh_obj: bpy.types.Object, morph_names: list[str], minimum: float) -> int:
    """批量设置目标网格的形态键下限值。"""
    if not mesh_obj or mesh_obj.type != "MESH" or not mesh_obj.data.shape_keys:
        return 0
    sk = mesh_obj.data.shape_keys
    count = 0
    for name in morph_names:
        kb = sk.key_blocks.get(name)
        if kb:
            kb.slider_min = float(minimum)
            count += 1
    return count


def get_custom_morph_drivers() -> list:
    """生成兼容绑定模式的自定义 MORPH_DRIVERS 列表。

    替换まばたき和笑い的表达式为工程文件中的版本（带软下限），
    移除びっくり相关驱动。
    """
    from .mapping import MORPH_DRIVERS

    custom = []
    for entry in MORPH_DRIVERS:
        key_name = entry[0]
        if key_name == "びっくり":
            # 兼容模式下取消びっくり驱动
            continue
        if key_name == "まばたき":
            custom.append((
                "まばたき",
                "eye_blink*((-100)*(eye_blink<0)+(-20)*(eye_blink>=0))+ eyes_look*((-15)*(eyes_look<0)+(-3)*(eyes_look>=0)) + eye_wink1_R*(-20)*(eye_wink1_R>0) + eye_wink2_R*(-20)*(eye_wink2_R>0) + eye_wink1_L*(-20)*(eye_wink1_L>0) + eye_wink2_L*(-20)*(eye_wink2_L>0)",
                [
                    ("eyes_look", "eyes", "CTL-eyes", "LOC_Z"),
                    ("eye_blink", "face", "CTL-eye_blink", "LOC_Z"),
                    ("eye_wink1_R", "face", "CTL-eye_wink1_R", "LOC_Z"),
                    ("eye_wink2_R", "face", "CTL-eye_wink2_R", "LOC_Z"),
                    ("eye_wink1_L", "face", "CTL-eye_wink1_L", "LOC_Z"),
                    ("eye_wink2_L", "face", "CTL-eye_wink2_L", "LOC_Z"),
                ],
            ))
        elif key_name == "笑い":
            custom.append((
                "笑い",
                "eye_happy * ((-100)*(eye_happy<0) + (-20)*(eye_happy>=0))",
                [
                    ("eye_happy", "face", "CTL-eye_happy", "LOC_Z"),
                ],
            ))
        else:
            custom.append(entry)
    return custom


def morph_names_present(mesh_obj: bpy.types.Object) -> set[str]:
    if not mesh_obj or not mesh_obj.data.shape_keys:
        return set()
    available = {kb.name for kb in mesh_obj.data.shape_keys.key_blocks}
    present = set()
    for m in MORPH_DRIVERS:
        actual = resolve_morph_name(m[0], available)
        if actual:
            present.add(actual)
    return present


def remove_shape_key_driver(sk: bpy.types.Key, key_name: str) -> bool:
    data_path = f'key_blocks["{key_name}"].value'
    try:
        sk.driver_remove(data_path)
        return True
    except Exception:
        return False
