"""Rigify / MMR compatibility: detect external COPY_TRANSFORMS drivers."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import bpy

COMPAT_AUTO = "AUTO"
COMPAT_ON = "ON"
COMPAT_OFF = "OFF"

COMPAT_ITEMS = (
    (COMPAT_AUTO, "自动", "检测到 Rigify/MMR 时：Face 骨骼合并进 Rigify，并关闭其眼控"),
    (COMPAT_ON, "开启", "强制：Face 骨骼合并进 Rigify 骨架"),
    (COMPAT_OFF, "关闭", "按普通 MMD 创建独立 Face_Rig"),
)

# Rigify 控制端眼/睑相关骨骼名（不含 ORG/DEF/MCH 变形链）
_RIGIFY_EYE_CTRL_EXACT = frozenset(
    {"eyes", "eye.L", "eye.R", "master_eye.L", "master_eye.R"}
)


def resolve_compat_enabled(mode: str, detected: bool) -> bool:
    """Resolve AUTO/ON/OFF + detection result → whether compat mode is active."""
    if mode == COMPAT_ON:
        return True
    if mode == COMPAT_OFF:
        return False
    return bool(detected)


def looks_like_rigify_control_rig(arm: "bpy.types.Object") -> bool:
    """True for generated Rigify control armatures (not the MMD target)."""
    if not arm or arm.type != "ARMATURE":
        return False
    name = arm.name
    if name.startswith("RIG-") or name.startswith("RIG_"):
        return True
    org_n = sum(1 for b in arm.data.bones if b.name.startswith("ORG-"))
    def_n = sum(1 for b in arm.data.bones if b.name.startswith("DEF-"))
    return org_n >= 8 and def_n >= 8


def find_external_copy_transforms_target(
    arm: "bpy.types.Object",
    bone_names: tuple[str, ...],
) -> "bpy.types.Object | None":
    """Return the other armature if any listed bone has COPY_TRANSFORMS to it."""
    if not arm or arm.type != "ARMATURE":
        return None
    for bn in bone_names:
        pb = arm.pose.bones.get(bn)
        if not pb:
            continue
        for c in pb.constraints:
            if c.type != "COPY_TRANSFORMS":
                continue
            tgt = c.target
            if tgt and tgt.type == "ARMATURE" and tgt != arm:
                return tgt
    return None


def detect_rigify_driven_target(arm: "bpy.types.Object") -> "bpy.types.Object | None":
    """If target arm's head/eyes are driven by another armature (MMR), return that driver."""
    from .mapping import EYE_L_BONE_CANDIDATES, EYE_R_BONE_CANDIDATES, HEAD_BONE_CANDIDATES
    from .placement import find_bone

    if not arm or arm.type != "ARMATURE" or looks_like_rigify_control_rig(arm):
        return None
    check: list[str] = []
    for candidates in (HEAD_BONE_CANDIDATES, EYE_L_BONE_CANDIDATES, EYE_R_BONE_CANDIDATES):
        found = find_bone(arm, candidates)
        if found:
            check.append(found)
    if not check:
        return None
    return find_external_copy_transforms_target(arm, tuple(check))


def is_rigify_compat_scene(arm: "bpy.types.Object") -> bool:
    return detect_rigify_driven_target(arm) is not None


def effective_rigify_compat(mode: str, arm: "bpy.types.Object | None") -> bool:
    detected = is_rigify_compat_scene(arm) if arm else False
    return resolve_compat_enabled(mode, detected)


def _is_rigify_eye_control_bone(name: str) -> bool:
    """Animator-facing Rigify eye / eyelid controls (not ORG/DEF/MCH)."""
    if name.startswith(("ORG-", "DEF-", "MCH-")):
        return False
    if name in _RIGIFY_EYE_CTRL_EXACT:
        return True
    lower = name.lower()
    if lower.startswith(("eye.", "eyes", "master_eye", "lid.")):
        return True
    if "eye" in lower and not name.startswith(("ORG-", "DEF-", "MCH-")):
        # e.g. eye_master / eyes_parent style controls if present
        if any(name.startswith(p) for p in ("eye", "lid")):
            return True
    return False


def list_rigify_eye_control_bones(rig: "bpy.types.Object") -> list[str]:
    if not rig or rig.type != "ARMATURE":
        return []
    return [b.name for b in rig.data.bones if _is_rigify_eye_control_bone(b.name)]


def mute_target_eye_rigify_constraints(
    target_arm: "bpy.types.Object",
    eye_bones: tuple[str, ...],
    driver_rig: "bpy.types.Object",
) -> int:
    """Mute constraints on target eye bones that copy from the Rigify control rig."""
    if not target_arm or not driver_rig:
        return 0
    muted = 0
    for bn in eye_bones:
        pb = target_arm.pose.bones.get(bn)
        if not pb:
            continue
        for c in pb.constraints:
            tgt = getattr(c, "target", None)
            if tgt != driver_rig:
                continue
            if c.type in {
                "COPY_TRANSFORMS",
                "COPY_ROTATION",
                "COPY_LOCATION",
                "COPY_SCALE",
                "CHILD_OF",
            }:
                if not c.mute:
                    c.mute = True
                    muted += 1
    return muted


def disable_rigify_eye_controls(rig: "bpy.types.Object") -> dict:
    """Make Rigify eye/lid controllers invisible and non-editable."""
    if not rig or rig.type != "ARMATURE":
        return {"bones": 0, "collections": 0}

    names = list_rigify_eye_control_bones(rig)
    for name in names:
        bone = rig.data.bones.get(name)
        if bone:
            bone.hide = True
        pb = rig.pose.bones.get(name)
        if pb:
            pb.bone.hide = True
            pb.lock_location = (True, True, True)
            pb.lock_rotation = (True, True, True)
            pb.lock_rotation_w = True
            pb.lock_scale = (True, True, True)

    # 若某骨骼集合里几乎全是眼控，一并关掉视口显示
    hidden_cols = 0
    colls = getattr(rig.data, "collections", None)
    if colls is not None:
        name_set = set(names)
        for coll in colls:
            members = [b.name for b in coll.bones]
            if not members:
                continue
            eye_n = sum(1 for n in members if n in name_set or _is_rigify_eye_control_bone(n))
            if eye_n and eye_n >= max(1, int(len(members) * 0.8)):
                if getattr(coll, "is_visible", True):
                    coll.is_visible = False
                    hidden_cols += 1

    return {"bones": len(names), "collections": hidden_cols}


def prepare_rigify_eyes_for_face_rig(
    target_arm: "bpy.types.Object",
    eye_l: str,
    eye_r: str,
) -> dict:
    """Disable Rigify eye drivers on target + hide Rigify eye controls.

    Returns stats including the detected driver rig (or None).
    """
    driver = detect_rigify_driven_target(target_arm)
    eye_bones = tuple(b for b in (eye_l, eye_r) if b in target_arm.data.bones)
    muted = 0
    disabled = {"bones": 0, "collections": 0}
    if driver:
        muted = mute_target_eye_rigify_constraints(target_arm, eye_bones, driver)
        disabled = disable_rigify_eye_controls(driver)
    return {
        "driver": driver.name if driver else None,
        "muted_constraints": muted,
        "hidden_bones": disabled["bones"],
        "hidden_collections": disabled["collections"],
    }
