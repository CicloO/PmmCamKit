"""N-panel UI — 三个独立折叠面板"""
from __future__ import annotations

import bpy
from bpy.types import Panel

from .rigify_compat import effective_rigify_compat, is_rigify_compat_scene


class FACE_EYES_PT_morph_bind(Panel):
    bl_label = "表情形态键控制器绑定"
    bl_idname = "FACE_EYES_PT_morph_bind"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "🐱"
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        s = context.scene.face_eyes_ctrl

        col = layout.column(align=True)
        col.prop(s, "target_armature", text="骨架")
        col.prop(s, "target_mesh", text="网格")
        col.prop(s, "head_bone")
        col.prop(s, "eye_l_bone")
        col.prop(s, "eye_r_bone")
        col.prop(s, "rigify_compat", text="Rigify兼容")

        arm = s.target_armature
        compat = effective_rigify_compat(s.rigify_compat, arm)
        detected = is_rigify_compat_scene(arm) if arm else False
        status = layout.row()
        if compat:
            status.label(text="生效: Face骨骼合并进Rigify", icon="INFO")
        else:
            status.label(text="生效: 独立Face_Rig", icon="CHECKMARK")
        if s.rigify_compat == "AUTO":
            layout.label(
                text=f"自动检测: {'Rigify/MMR' if detected else '普通目标'}")

        layout.separator()
        layout.prop(s, "binding_mode", text="绑定模式")
        layout.operator("face_eyes_ctrl.auto_detect", icon="VIEWZOOM")
        layout.operator("face_eyes_ctrl.apply", icon="PLAY")

        layout.separator()
        layout.prop(s, "jelly_mode", text="果冻眼模式")
        row = layout.row(align=True)
        row.operator("face_eyes_ctrl.jelly_eyes", icon="CONSTRAINT_BONE", text="果冻眼绑定")
        row.operator("face_eyes_ctrl.jelly_eyes_remove", icon="X", text="删除")

        layout.separator()
        row = layout.row(align=True)
        row.prop(context.scene, "frame_start", text="起始")
        row.prop(context.scene, "frame_end", text="结束")
        layout.operator(
            "face_eyes_ctrl.bake",
            text="仅烘焙面部（含左目/右目）",
            icon="KEYTYPE_KEYFRAME_VEC",
        )
        layout.operator(
            "face_eyes_ctrl.bake_mmd",
            text="烘焙面部与MMD标准骨骼",
            icon="KEYFRAME_HLT",
        )

        layout.separator()
        layout.operator("face_eyes_ctrl.clean_keys", icon="KEYFRAME")


class FACE_EYES_PT_camera_bake(Panel):
    bl_label = "MMD相机烘焙"
    bl_idname = "FACE_EYES_PT_camera_bake"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "🐱"
    bl_order = 1

    def draw(self, context):
        layout = self.layout
        s = context.scene.cat_camera_bake

        obj = context.active_object
        if obj and obj.type == "CAMERA":
            row = layout.row()
            row.label(text=f"目标: {obj.name}", icon="CAMERA_DATA")
        else:
            row = layout.row()
            row.label(text="请选中一个相机", icon="ERROR")

        layout.separator()

        layout.prop(s, "scale")
        layout.prop(s, "camera_source", expand=True)
        layout.prop(s, "bake_mode", expand=True)
        if s.bake_mode == "ADAPTIVE":
            layout.prop(s, "target_mode", expand=True)
            layout.prop(s, "precision_px")
            layout.prop(s, "allow_negative")
            layout.prop(s, "allow_step1")
        else:
            layout.prop(s, "step")
            layout.prop(s, "fov_integer")
        layout.prop(s, "min_distance")
        row = layout.row()
        row.enabled = s.bake_mode == "ADAPTIVE" or s.fov_integer
        row.prop(s, "ref_depth")

        layout.separator()
        layout.operator("cat_toolbox.convert_to_mmd_camera", icon="CAMERA_DATA")
        layout.operator("cat_toolbox.export_camera_vmd", icon="EXPORT")
        layout.operator("cat_toolbox.pmm_bind_camera_follow", icon="CONSTRAINT_BONE")


class CAT_TOOLBOX_PT_mmd_select(Panel):
    bl_label = "MMD标准骨骼选择"
    bl_idname = "CAT_TOOLBOX_PT_mmd_select"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "🐱"
    bl_order = 2

    def draw(self, context):
        layout = self.layout

        obj = context.active_object
        if obj and obj.type == "ARMATURE":
            row = layout.row()
            row.label(text=f"骨架: {obj.name}", icon="ARMATURE_DATA")
            layout.separator()
            layout.operator(
                "cat_toolbox.select_mmd_bones",
                icon="BONE_DATA",
                text="选中MMD标准骨骼",
            )
            layout.separator()
        else:
            row = layout.row()
            row.label(text="请先选中一个骨架", icon="ERROR")


class CAT_TOOLBOX_PT_vmd_io(Panel):
    bl_label = "导入/导出VMD"
    bl_idname = "CAT_TOOLBOX_PT_vmd_io"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "🐱"
    bl_order = 3

    def draw(self, context):
        layout = self.layout
        s = context.scene.cat_vmd_io

        row = layout.row(align=True)
        row.operator("cat_toolbox.import_vmd_flow", icon="IMPORT", text="导入VMD")
        row.operator("cat_toolbox.export_vmd", icon="EXPORT", text="导出VMD")

        if s.hidden_armature_name:
            layout.separator()
            layout.operator("cat_toolbox.show_vmd_armature", icon="HIDE_OFF", text="恢复骨骼")

        if s.last_report:
            layout.separator()
            layout.label(text=s.last_report, icon="INFO")


CLASSES = (
    FACE_EYES_PT_morph_bind,
    FACE_EYES_PT_camera_bake,
    CAT_TOOLBOX_PT_mmd_select,
    CAT_TOOLBOX_PT_vmd_io,
)
