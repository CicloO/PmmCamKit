"""Operator：MMD 相机烘焙 / 相机 VMD 导出"""
from __future__ import annotations

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ExportHelper, ImportHelper

from . import camera_adaptive, pmm_camera
from .camera_bake import FnCamera, MMDCamera


def _origin_key_frames(cam):
    """源相机（或其父级）动画的关键帧帧号，作为切镜判断的辅助信息。"""
    frames = set()
    if cam is None:
        return frames
    for holder in (cam.parent, cam):
        ad = holder.animation_data if holder else None
        if ad and ad.action and ad.action.fcurves:
            for fc in ad.action.fcurves:
                frames.update(round(k.co.x) for k in fc.keyframe_points)
            break
    return frames


_TRACK_TYPES = {"TRACK_TO", "DAMPED_TRACK", "LOCKED_TRACK"}


def _track_constraint(constraints):
    for c in constraints:
        if c.type in _TRACK_TYPES and c.target and not c.mute and c.influence > 0:
            return c
    return None


def _find_aim(cam):
    """相机控制器的 Aim：相机自身或其父骨骼链上 Track To 类约束的目标。
    返回 (物体, 骨骼名, head_tail) 或 None。"""
    c = _track_constraint(cam.constraints)
    if c is None and cam.parent and cam.parent.type == "ARMATURE" and cam.parent_type == "BONE":
        pb = cam.parent.pose.bones.get(cam.parent_bone)
        while pb is not None and c is None:
            c = _track_constraint(pb.constraints)
            pb = pb.parent
    if c is None:
        return None
    return c.target, getattr(c, "subtarget", ""), getattr(c, "head_tail", 0.0)


def _point_of(obj, bone="", head_tail=0.0):
    if obj.type == "ARMATURE" and bone and bone in obj.pose.bones:
        pb = obj.pose.bones[bone]
        return obj.matrix_world @ pb.head.lerp(pb.tail, head_tail)
    return obj.matrix_world.translation.copy()


def _find_characters(scene):
    """场景里的 MMD 角色骨架：取センター（没有则全ての親）骨骼。"""
    out = []
    for o in scene.objects:
        if o.type != "ARMATURE" or len(o.data.bones) < 20:
            continue
        for name in ("センター", "全ての親"):
            if name in o.pose.bones:
                out.append((o, name))
                break
    return out


def _make_target_getter(scene, explicit, mode):
    """按优先级决定目标点：选中物体 > 相机控制器 Aim > 对焦物体 > 角色 > 无。
    返回 (get_target(cam), 说明文字)。"""
    if mode == "NONE":
        return (lambda cam: None), "目标点贴近相机"
    if explicit is not None:
        return (lambda cam: _point_of(explicit)), f"目标点：选中的 {explicit.name}"
    chars = _find_characters(scene)
    aims = {}
    used = set()

    def get(cam):
        if cam.name not in aims:
            aims[cam.name] = _find_aim(cam)
        aim = aims[cam.name]
        if aim is not None:
            used.add(f"控制器 {aim[0].name}/{aim[1]}" if aim[1] else f"控制器 {aim[0].name}")
            return _point_of(*aim)
        if cam.data.dof.focus_object:
            used.add(f"对焦物体 {cam.data.dof.focus_object.name}")
            return _point_of(cam.data.dof.focus_object)
        if chars:
            used.add("角色 " + "/".join(a.name for a, _ in chars))
            return [_point_of(a, b) for a, b in chars]
        return None

    return get, used


class CAT_OT_convert_to_mmd_camera(Operator):
    bl_idname = "cat_toolbox.convert_to_mmd_camera"
    bl_label = "执行烘焙"
    bl_description = "将相机动画烘焙为 MMD 格式相机"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == "CAMERA"

    def execute(self, context):
        s = context.scene.cat_camera_bake
        obj = context.active_object

        # 确定烘焙目标：如果选"场景相机"且场景相机不是当前选中，则用场景相机
        targets = [x for x in context.selected_objects if x != obj]
        target = targets[0] if len(targets) == 1 else None

        src = None  # None = newMMDCameraAnimation 内部自动用 scene.camera
        if s.camera_source == "CURRENT":
            src = obj

        if s.bake_mode == "ADAPTIVE":
            return self._bake_adaptive(context, s, src, target)

        mmd_cam = MMDCamera.newMMDCameraAnimation(
            src, target,
            scale=s.scale,
            min_distance=s.min_distance,
            step=s.step,
            fov_integer=s.fov_integer,
            ref_depth=s.ref_depth,
        ).camera()

        context.view_layer.objects.active = mmd_cam
        self.report({"INFO"}, f"相机烘焙完成 → {mmd_cam.parent.name}")
        return {"FINISHED"}

    def _bake_adaptive(self, context, s, src, target):
        scene = context.scene
        if src is None and scene.camera is None:
            self.report({"ERROR"}, "场景没有相机")
            return {"CANCELLED"}

        def get_cam():
            return src if src is not None else scene.camera

        get_target, used = _make_target_getter(scene, target, s.target_mode)

        msgs = []
        res = camera_adaptive.bake_adaptive(
            scene, get_cam, get_target,
            min_distance=s.min_distance,
            ref_depth=s.ref_depth,
            tol=s.precision_px / 1080,
            allow_negative=s.allow_negative,
            fov_integer=True,
            origin_keys=frozenset(_origin_key_frames(get_cam())),
            min_gap=1 if s.allow_step1 else 2,
            report=msgs.append,
        )
        if not isinstance(used, str):
            used = "目标点：" + ("、".join(sorted(used)) if used else "无（贴近相机）")
        msgs.append(used)

        cam = bpy.data.objects.new(name="Camera", object_data=bpy.data.cameras.new("Camera"))
        context.collection.objects.link(cam)
        root = MMDCamera.convertToMMDCamera(cam, scale=s.scale, init_mmd=False).object()
        FnCamera.remove_drivers(cam)
        camera_adaptive.apply_to_mmd_camera(root, cam, res)
        FnCamera.add_drivers(cam)

        context.view_layer.objects.active = cam
        self.report({"INFO"}, f"自适应烘焙完成 → {root.name}：" + "；".join(msgs))
        return {"FINISHED"}


def _find_mmd_camera_root(obj):
    for o in (obj, obj.parent if obj else None):
        if o is not None and getattr(o, "mmd_type", "") == "CAMERA":
            return o
    return None


class CAT_OT_export_camera_vmd(Operator, ExportHelper):
    bl_idname = "cat_toolbox.export_camera_vmd"
    bl_label = "导出相机VMD"
    bl_description = ("将选中的 MMD 相机导出为 VMD（Cat Toolbox 自带导出，"
                      "原样写入烘焙得到的插值曲线，不经过 mmd_tools）")
    bl_options = {"REGISTER"}

    filename_ext = ".vmd"
    filter_glob: StringProperty(default="*.vmd", options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        return _find_mmd_camera_root(context.active_object) is not None

    def execute(self, context):
        root = _find_mmd_camera_root(context.active_object)
        scene = context.scene
        try:
            n, warn = camera_adaptive.export_camera_vmd(
                self.filepath, root,
                scale=scene.cat_vmd_io.export_scale,
                frame_offset=min(1, scene.frame_start),
            )
        except Exception as e:  # noqa: BLE001
            self.report({"ERROR"}, f"导出失败：{e}")
            return {"CANCELLED"}
        if warn:
            self.report({"WARNING"}, f"已导出 {n} 个关键帧；{warn}")
        else:
            self.report({"INFO"}, f"已导出 {n} 个相机关键帧 → {self.filepath}")
        return {"FINISHED"}


class CAT_OT_pmm_bind_camera_follow(Operator, ImportHelper):
    bl_idname = "cat_toolbox.pmm_bind_camera_follow"
    bl_label = "PMM相机追从批量绑定"
    bl_description = ("在 MMD 里先给第一个相机关键帧设置骨骼追从并保存，再用这里选择 PMM："
                      "把追从设置填充给之后未绑定的相机关键帧，另存为「原名_追従.pmm」")
    bl_options = {"REGISTER"}

    filename_ext = ".pmm"
    filter_glob: StringProperty(default="*.pmm", options={"HIDDEN"})
    overwrite_all: BoolProperty(
        name="全部覆盖",
        default=False,
        description="关闭：每个未绑定关键帧继承它之前最近一个已绑定的设置（中途可手动换目标）；"
                    "开启：全部关键帧都改成第一个已绑定的设置",
    )

    def execute(self, context):
        try:
            st = pmm_camera.bind_follow(self.filepath, overwrite_all=self.overwrite_all)
        except Exception as e:  # noqa: BLE001
            self.report({"ERROR"}, f"处理失败：{e}")
            return {"CANCELLED"}
        msg = (f"已写入 {st['path']}：相机关键帧 {st['keys']} 个，绑定 {st['changed']} 个"
               f"（目标：{st['first_target']}）")
        if st["skipped_before_first"]:
            msg += f"；第 {st['first_frame']} 帧之前有 {st['skipped_before_first']} 个关键帧未处理"
        self.report({"INFO"}, msg)
        return {"FINISHED"}


CLASSES = (CAT_OT_convert_to_mmd_camera, CAT_OT_export_camera_vmd,
           CAT_OT_pmm_bind_camera_follow)
