"""果冻眼：从内置模板生成 Eyes_Physics，并挂上范例驱动器。"""

from __future__ import annotations

import bpy
from mathutils import Vector

from .drivers import add_transform_var
from .mapping import resolve_morph_name

EYES_PHYSICS_NAME = "Eyes_Physics"
JELLY_PROP = "face_eyes_jelly"
PHYS_ROOT = "PHYS_Bone01"
PHYS_TIP = "PHYS_Bone03"
PHYS_TIP_LEGACY = "骨骼.002"

# Face_Rig CTL-eye_small → 瞳小 的原系数；果冻尖端 X → 瞳小 的范例系数
TONGXIAO_CTL_SCALE = 25.0
TONGXIAO_JELLY_SCALE = 3.0
TONGXIAO_CTL_BONE = "CTL-eye_small"

# 从范例 Eyes_Physics 导出（原样世界坐标，不对齐头）
EYES_PHYSICS_TEMPLATE = {
    "location": (0.0, 0.0, 3.0),
    "rotation_euler": (0.0, 0.0, 0.0),
    "scale": (1.0, 1.0, 1.0),
    "show_in_front": True,
    "display_type": "TEXTURED",
    "armature_display_type": "OCTAHEDRAL",
    "bones": [
        {
            "name": PHYS_ROOT,
            "parent": None,
            "head": (0.0, 0.0, 0.0),
            "tail": (0.0, 0.0, -1.0 / 3.0),
            "use_connect": False,
            "use_deform": True,
        },
        {
            "name": "PHYS_Bone02",
            "parent": PHYS_ROOT,
            "head": (0.0, 0.0, -1.0 / 3.0),
            "tail": (0.0, 0.0, -2.0 / 3.0),
            "use_connect": True,
            "use_deform": True,
        },
        {
            "name": PHYS_TIP,
            "parent": "PHYS_Bone02",
            "head": (0.0, 0.0, -2.0 / 3.0),
            "tail": (0.0, 0.0, -1.0),
            "use_connect": True,
            "use_deform": True,
        },
    ],
}

# PHYS_Bone01.location.x ← 形态键（配布用）
JELLY_ROOT_DRIVERS = [
    {
        "data_path": f'pose.bones["{PHYS_ROOT}"].location',
        "array_index": 0,
        "expression": "(blink * -5 if blink < 0 else 0) + (smile * -5 if smile < 0 else 0)",
        "variables": [
            {"name": "blink", "bone": "CTL-eye_blink", "transform": "LOC_Z"},
            {"name": "smile", "bone": "CTL-eye_happy", "transform": "LOC_Z"},
        ],
    },
]

# PHYS_Bone01.location.x ← CTL 骨骼变换（仅 blink/happy）
JELLY_ROOT_CTL_DRIVERS = [
    {
        "data_path": f'pose.bones["{PHYS_ROOT}"].location',
        "array_index": 0,
        "expression": "-blink*5 + -smile*5",
        "variables": [
            {"name": "blink", "bone": "CTL-eye_blink", "transform": "LOC_Z"},
            {"name": "smile", "bone": "CTL-eye_happy", "transform": "LOC_Z"},
        ],
    },
]


def find_eyes_physics() -> bpy.types.Object | None:
    return bpy.data.objects.get(EYES_PHYSICS_NAME)


def find_phys_tip_bone(eyes_physics: bpy.types.Object) -> str | None:
    for name in (PHYS_TIP, PHYS_TIP_LEGACY):
        if name in eyes_physics.pose.bones:
            return name
    return None


def find_face_ctrl_rig() -> bpy.types.Object | None:
    """独立 Face_Rig，或已合并 CTL 的 Rigify 宿主。"""
    fr = bpy.data.objects.get("Face_Rig")
    if fr and fr.type == "ARMATURE" and TONGXIAO_CTL_BONE in fr.pose.bones:
        return fr
    for obj in bpy.data.objects:
        if obj.type != "ARMATURE":
            continue
        if TONGXIAO_CTL_BONE in obj.pose.bones:
            return obj
    return None


def resolve_morph_hub(context) -> bpy.types.Object | None:
    """优先 .placeholder，否则侧栏目标网格。"""
    ph = bpy.data.objects.get(".placeholder")
    if ph and ph.type == "MESH" and ph.data.shape_keys:
        return ph
    s = getattr(context.scene, "face_eyes_ctrl", None)
    mesh = s.target_mesh if s else None
    if mesh and mesh.type == "MESH" and mesh.data.shape_keys:
        return mesh
    return None


def _mode_set(obj: bpy.types.Object, mode: str):
    view = bpy.context.view_layer
    view.objects.active = obj
    try:
        obj.select_set(True)
    except Exception:
        pass
    with bpy.context.temp_override(
        active_object=obj,
        object=obj,
        selected_objects=[obj],
        selected_editable_objects=[obj],
    ):
        if obj.mode != mode:
            bpy.ops.object.mode_set(mode=mode)


def create_eyes_physics(collection: bpy.types.Collection | None = None) -> bpy.types.Object:
    """按模板创建 Eyes_Physics（世界坐标原样）。"""
    if find_eyes_physics():
        raise RuntimeError(f"已存在 {EYES_PHYSICS_NAME}")

    tpl = EYES_PHYSICS_TEMPLATE
    arm_data = bpy.data.armatures.new(EYES_PHYSICS_NAME)
    obj = bpy.data.objects.new(EYES_PHYSICS_NAME, arm_data)
    col = collection or bpy.context.scene.collection
    col.objects.link(obj)

    obj.location = tpl["location"]
    obj.rotation_euler = tpl["rotation_euler"]
    obj.scale = tpl["scale"]
    obj.show_in_front = bool(tpl["show_in_front"])
    obj.display_type = tpl["display_type"]
    arm_data.display_type = tpl["armature_display_type"]
    obj[JELLY_PROP] = True

    _mode_set(obj, "EDIT")
    created: dict[str, bpy.types.EditBone] = {}
    for bd in tpl["bones"]:
        eb = arm_data.edit_bones.new(bd["name"])
        eb.head = Vector(bd["head"])
        eb.tail = Vector(bd["tail"])
        if (eb.tail - eb.head).length < 1e-8:
            eb.tail = eb.head + Vector((0.0, 0.0, -0.01))
        eb.use_connect = bool(bd.get("use_connect", False))
        eb.use_deform = bool(bd.get("use_deform", True))
        created[bd["name"]] = eb
    for bd in tpl["bones"]:
        parent = bd.get("parent")
        if parent and parent in created:
            created[bd["name"]].parent = created[parent]
            created[bd["name"]].use_connect = bool(bd.get("use_connect", False))

    _mode_set(obj, "OBJECT")

    if hasattr(arm_data, "collections"):
        bc = None
        for existing in arm_data.collections:
            if existing.name == "骨骼":
                bc = existing
                break
        if bc is None:
            bc = arm_data.collections.new("骨骼")
        for bd in tpl["bones"]:
            bone = arm_data.bones.get(bd["name"])
            if bone:
                try:
                    bc.assign(bone)
                except Exception:
                    pass

    return obj


def apply_root_morph_drivers(
    eyes_physics: bpy.types.Object,
    face_rig: bpy.types.Object,
    *,
    force_mode: str | None = None,
) -> tuple[int, list[str]]:
    """PHYS_Bone01.loc.x 驱动。

    force_mode:
      - "DISTRIBUTE" → 配布用：表达式含条件判断（负值才生效）
      - "PERSONAL"   → 自用：表达式直接取反
      - None         → 自动选择（默认配布用）
    """
    if not face_rig or face_rig.type != "ARMATURE":
        raise RuntimeError("需要 Face_Rig 来读取 CTL 骨骼变换")

    has_ctl = (
        "CTL-eye_blink" in face_rig.pose.bones
        and "CTL-eye_happy" in face_rig.pose.bones
    )
    if not has_ctl:
        raise RuntimeError("Face_Rig 缺少 CTL-eye_blink / CTL-eye_happy 骨骼")

    if force_mode == "DISTRIBUTE":
        drivers_spec = JELLY_ROOT_DRIVERS
    elif force_mode == "PERSONAL":
        drivers_spec = JELLY_ROOT_CTL_DRIVERS
    else:
        drivers_spec = JELLY_ROOT_DRIVERS

    ad = eyes_physics.animation_data
    if ad:
        for fc in list(ad.drivers):
            if "PHYS_Bone" in (fc.data_path or ""):
                try:
                    eyes_physics.driver_remove(fc.data_path, fc.array_index)
                except Exception:
                    try:
                        eyes_physics.driver_remove(fc.data_path)
                    except Exception:
                        pass

    applied = 0
    missing: list[str] = []
    for spec in drivers_spec:
        resolved_vars: list[tuple[str, str]] = []
        for vs in spec["variables"]:
            bone_name = vs.get("bone", "")
            if bone_name not in face_rig.pose.bones:
                missing.append(bone_name)
                continue
            resolved_vars.append((vs["name"], bone_name))
        if len(resolved_vars) != len(spec["variables"]):
            continue

        fcurve = eyes_physics.driver_add(spec["data_path"], spec["array_index"])
        driver = fcurve.driver
        driver.type = "SCRIPTED"
        driver.expression = spec["expression"]
        while driver.variables:
            driver.variables.remove(driver.variables[0])

        for var_name, bone_name in resolved_vars:
            vs = next(v for v in spec["variables"] if v["name"] == var_name)
            add_transform_var(
                driver,
                var_name,
                face_rig,
                bone_name,
                vs["transform"],
                "LOCAL_SPACE",
            )
        applied += 1

    return applied, missing


def apply_tongxiao_additive_driver(
    morph_hub: bpy.types.Object,
    eyes_physics: bpy.types.Object,
    face_rig: bpy.types.Object | None,
) -> str:
    """瞳小 = CTL-eye_small*25 + PHYS尖端.loc.x*13（与 Face_Rig 并存相加）。

    写在 morph_hub（通常 .placeholder）上；网格若镜像 placeholder 会一并跟上。
    """
    if not morph_hub or not morph_hub.data.shape_keys:
        raise RuntimeError("形态键来源无效")

    available = {kb.name for kb in morph_hub.data.shape_keys.key_blocks}
    morph = resolve_morph_name("瞳小", available)
    if not morph:
        raise RuntimeError("形态键来源缺少「瞳小」")

    tip = find_phys_tip_bone(eyes_physics)
    if not tip:
        raise RuntimeError(f"{eyes_physics.name} 缺少尖端骨 {PHYS_TIP}")

    sk = morph_hub.data.shape_keys
    data_path = f'key_blocks["{morph}"].value'
    try:
        sk.driver_remove(data_path)
    except Exception:
        pass

    fcurve = sk.driver_add(data_path)
    driver = fcurve.driver
    driver.type = "SCRIPTED"
    while driver.variables:
        driver.variables.remove(driver.variables[0])

    parts: list[str] = []
    if face_rig is not None and TONGXIAO_CTL_BONE in face_rig.pose.bones:
        add_transform_var(
            driver,
            "eye_small",
            face_rig,
            TONGXIAO_CTL_BONE,
            "LOC_X",
            "LOCAL_SPACE",
        )
        parts.append(f"eye_small*{TONGXIAO_CTL_SCALE:g}")

    add_transform_var(
        driver,
        "jelly",
        eyes_physics,
        tip,
        "LOC_X",
        "WORLD_SPACE",
    )
    parts.append(f"jelly*{TONGXIAO_JELLY_SCALE:g}")
    driver.expression = " + ".join(parts) if parts else "0"
    return driver.expression


def setup_jelly_eyes(context, *, recreate: bool = False, jelly_mode: str = "DISTRIBUTE") -> str:
    """生成（或复用）Eyes_Physics，并应用全部相关驱动器。

    jelly_mode:
      - "DISTRIBUTE" → 配布用：强制形态键驱动
      - "PERSONAL"   → 自用：强制CTL骨骼驱动
    """
    hub = resolve_morph_hub(context)
    if not hub:
        raise RuntimeError(
            "需要形态键来源：请先「一键应用控制器」生成 .placeholder，或在侧栏指定目标网格"
        )

    existing = find_eyes_physics()
    created = False
    if existing and recreate:
        data = existing.data
        bpy.data.objects.remove(existing, do_unlink=True)
        if data and data.users == 0:
            bpy.data.armatures.remove(data)
        existing = None

    if existing:
        eyes = existing
        eyes[JELLY_PROP] = True
    else:
        eyes = create_eyes_physics()
        created = True

    face = find_face_ctrl_rig()
    root_n, missing = apply_root_morph_drivers(eyes, face, force_mode=jelly_mode)
    tongxiao_expr = apply_tongxiao_additive_driver(hub, eyes, face)

    action = "生成" if created else "更新驱动"
    mode_label = "配布用" if jelly_mode == "DISTRIBUTE" else "自用"
    msg = (
        f"果冻眼{action}: {eyes.name}, 根骨驱动={root_n}({mode_label}), "
        f"瞳小={tongxiao_expr}, 形态来源={hub.name}"
    )
    if face:
        msg += f", FaceCTL={face.name}"
    if missing:
        msg += f", 缺失形态键={', '.join(missing)}"
    if root_n == 0:
        raise RuntimeError(msg + "（根骨驱动未挂上）")
    return msg


def remove_jelly_eyes(context) -> str:
    """解除果冻眼绑定：删除 Eyes_Physics 物体并清理相关驱动，不影响其他绑定。"""
    report_parts = []

    # 1. 清除形态键上的瞳小驱动
    hub = resolve_morph_hub(context)
    if hub and hub.data.shape_keys:
        available = {kb.name for kb in hub.data.shape_keys.key_blocks}
        morph = resolve_morph_name("瞳小", available)
        if morph:
            sk = hub.data.shape_keys
            data_path = f'key_blocks["{morph}"].value'
            try:
                sk.driver_remove(data_path)
                report_parts.append(f"已清除 {hub.name} 上的「{morph}」驱动")
            except Exception:
                pass

    # 2. 删除 Eyes_Physics 物体
    ep = find_eyes_physics()
    if ep:
        ep_name = ep.name
        arm_data = ep.data
        bpy.data.objects.remove(ep, do_unlink=True)
        if arm_data and arm_data.users == 0:
            bpy.data.armatures.remove(arm_data)
        report_parts.append(f"已删除 {ep_name}")

    if not report_parts:
        return "未找到果冻眼绑定，无需清理"
    return "果冻眼已解除: " + "，".join(report_parts)
