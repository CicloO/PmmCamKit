bl_info = {
    "name": "Cat Toolbox",
    "author": "若梦",
    "version": (0, 14, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > 🐱",
    "description": "Face_Rig / Rigify 合并 / 果冻眼 Eyes_Physics / MMD相机烘焙（自适应） / VMD导入导出",
    "category": "Rigging",
}

import bpy

from . import (
    camera_bake,
    ops_apply,
    ops_bake,
    ops_camera,
    ops_jelly,
    ops_mmd_select,
    ops_vmd_io,
    props,
    ui,
)


CLASSES = (
    props.CLASSES
    + ops_apply.CLASSES
    + ops_bake.CLASSES
    + ops_jelly.CLASSES
    + ops_camera.CLASSES
    + ops_mmd_select.CLASSES
    + ops_vmd_io.CLASSES
    + ui.CLASSES
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.face_eyes_ctrl = bpy.props.PointerProperty(type=props.FaceEyesCtrlSettings)
    bpy.types.Scene.cat_camera_bake = bpy.props.PointerProperty(type=props.CatCameraBakeProps)
    bpy.types.Scene.cat_vmd_io = bpy.props.PointerProperty(type=props.VmdIOProps)


def unregister():
    if hasattr(bpy.types.Scene, "cat_vmd_io"):
        del bpy.types.Scene.cat_vmd_io
    if hasattr(bpy.types.Scene, "cat_camera_bake"):
        del bpy.types.Scene.cat_camera_bake
    if hasattr(bpy.types.Scene, "face_eyes_ctrl"):
        del bpy.types.Scene.face_eyes_ctrl
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
