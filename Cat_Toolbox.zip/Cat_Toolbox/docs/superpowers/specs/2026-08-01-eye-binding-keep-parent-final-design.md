# 眼部控制器绑定：保留父子级 · 最终设计（决策记录）

日期：2026-08-01
状态：待用户审批
前置文档：`2026-07-31-eye-binding-keep-parent-design.md`（本方案的实现蓝图，位于 backup 分支）

## 背景与用户诉求

用户在 Cat_Toolbox 与 MikuMikuRig 的眼部控制器绑定对比中提出：

> Cat_Toolbox 的绑定（无论是否 Rigify 兼容模式）都会破坏原始模型的眼骨骼父子级关系，希望保留原父子级。

实际症状（莉奈娅模型，Rigify 兼容场景）：
- `目.L` / `目.R` 的父级为 `頭`，左右眼 rest 局部坐标系为镜像（roll 约 −164° / +164°）。
- master 现行方案 `bind_eyeballs_child_of` 会先 `_unparent_eye_bones` 切断 `目→頭`，再加 `Child Of → MCH-eye_L/R`，破坏父子级。
- 用户此前在 `backup-eye-binding-fix` 尝试过 Copy Rotation 方案，实测左右眼方向反。

## 候选方案对比

### 方案 A：Copy Rotation 保留父级（4fd448c 思路）
目骨加 `Copy Rotation (LOCAL→LOCAL, REPLACE)` → `MCH-eye_L/R`，父级保留。

**隔离实验结论**（Blender 实测，临时骨架模拟"源/目标父级同为 head"）：
- 头旋转 30° 后，目标局部旋转仍精确等于源局部旋转（diff = 单位四元数）→ **无双重旋转、无泄漏**。
- 因此 `2026-07-31` 文档中"Copy Rotation 会在頭旋转时泄漏/镜像"的判断不成立；当时问题根因更可能是 `MCH-eye` 与目骨 rest 局部旋转未对齐（roll 硬编码不匹配）。

**否决理由**：真实场景中 `目.L` rest 相对 `頭` 有 −164° 局部旋转，`COPY_ROTATION REPLACE` 会直接覆盖目标局部旋转。要让 rest 不被破坏，必须保证 `MCH-eye` 的 rest 局部旋转精确等于 `目` 相对其父级的局部旋转（即 `M_mch = M_root⁻¹ · M_目`）。该对齐数学处理繁琐且易错，任何模型差异都会造成方向偏差——不值得为"少一个约束"冒险。

### 方案 B：Child Of 仅旋转 + 补回父级（不推荐）
Child Of 只开 use_rotation、保留 `目→頭` 父级。但 `MCH-eye` 挂在与 `頭` 同向的 `MCH-eyes_root` 下，Child Of 复制的是含头旋转的世界旋转，与父级叠加造成**双重头旋转**，原理上不可行。

### 方案 C：眼骨直接跟踪 MCH-eye 尾端（**采纳**）
`目.L/R` 保留 `parent=頭`，直接加 `Damped Track「眼控追踪」→ MCH-eye_L/R`（`head_tail=1.0`）：

- Damped Track 是**瞄准型增量约束**，输出相对当前朝向的旋转，天然不与父级（頭）旋转叠加 → 无双重。
- 静止时 MCH-eye 尾端位于眼骨 Y 轴延长线上，约束输出≈零 → 不破坏 rest、无对眼。
- 眼神控制由控制器内部 `MCH-eye_L/R` 承担（`CTL-eye-Look` Look 驱动 + `CTL-eye_L/R` Damped Track），眼骨只做"继承方向"，链路最短、最稳。
- 全程不进入编辑模式，不动 `目先` 子级，不清位移动画关键帧。
- 该方案是用户 7-31 设计文档批准方向的自然演进，且 `568e91d` 已实测修复对眼、`0d621a0` 修复眼珠间距。

## 最终方案

在 master 上落地上述方案 C。**实现已完整存在于 `backup-master-before-d5ed465`（`18db0f7`）分支**，且该分支直接由当前 master 顶端（`d5ed465`）长出，合并路径干净。

### 落地内容（取自 18db0f7，对应 master 差异）
| 文件 | 改动 |
|---|---|
| `constraints.py` | 新增 `bind_eyeballs_keep_parent`：静音 mmd 両目→目 TRANSFORM → `_strip_eye_bindings` 清理旧绑定 → 加 `Damped Track「眼控追踪」→ MCH-eye_L/R 尾端`。删除旧 Child Of 路径死代码（`_unparent_eye_bones`、`set_childof_inverse`、`_add_eye_childof`、`bind_eyeballs_child_of`、`clear_eye_location_animation`）。`repair_eyeball_binding` 改用新函数。 |
| `drivers.py` | 新增 `strip_eye_look_drivers`（烘焙/解绑时移除眼骨上引用 `CTL-eye-Look` 的驱动）。 |
| `bake.py` | `_mute_eye_ctrl_constraints` 静音「眼控追踪」，烘焙时移除 Look 驱动，避免驱动覆盖关键帧。 |
| `placement.py` | `MCH-eye_L/R` 完全复制目骨 head/tail 方向；CTL 沿 MCH 轴向放置（眼珠间距修复）。 |
| `build_rig.py` | 注入模式下 MCH-eye 对齐处理；集合界面优化（94d8110）。 |
| `ops_apply.py` / `ops_bake.py` | 调用点切到 `bind_eyeballs_keep_parent`；文案同步。 |
| `rig_template.py` / `mapping.py` | 清理死驱动数据；保持 master 的镜像 roll + 异号 Look 驱动体系（**不采纳 4fd448c 的同号改动**）。 |

### Rigify 兼容模式（莉奈娅场景）联动
- `prepare_rigify_eyes_for_face_rig` 保持现状：静音 `目.L/R` 上指向 `RIG-*` 的 `MMR_复制*` 约束 + 隐藏 RIG 眼控。
- `頭` 的 MMR 约束不受影响 → 头动画正常；`目.L/R` 位置由父级 `頭` 提供，眼神旋转由「眼控追踪」提供 → 闭环成立。

### 合并路径
master 当前 = `d5ed465`，`18db0f7` 是其直接后代，合并等价于快速前进（或直接 `merge --ff`）。需在用户确认后执行。

**注意**：`18db0f7` 链还包含 `94d8110`「优化集合界面」（只生成面部控制器集合、自动折叠 Outliner）这一非眼部改动。它混在 `build_rig.py` 的改动中，拆开 cherry-pick 成本高于保留。默认一并带入；若用户不想要该 UI 改动，需单独处理。

## 验证清单
1. 绑定后编辑模式下 `目.L/R` 父级仍为 `頭`。
2. 静止姿态与绑定前一致。
3. 旋转 `頭`：眼球只跟随一次，无双重旋转。
4. 拖动 `CTL-eye-Look` / `CTL-eye_L` / `CTL-eye_R` / `CTL-eyes`：双眼同向正确，无对眼、无反向。
5. 烘焙后目骨关键帧生效（不被 Look 驱动覆盖）。
6. 重复应用 / repair 幂等；解绑后无残留约束与驱动。
7. Rigify 兼容模式（注入）+ 独立模式各验证一遍；果冻眼回归。

## 风险与已知限制
- 绑定前眼骨已有手 K 旋转动画的通道会被「眼控追踪」接管（与旧方案行为一致）。
- 若 `MCH-eye_L/R` 在注入模式下未精确对齐目骨（模板硬编码位置），眼珠静止姿态可能轻微偏移——需在实现中复用 `placement` 的对齐逻辑到注入路径。
- `backup-eye-binding-fix`（4fd448c）分支废弃，不再合并。
