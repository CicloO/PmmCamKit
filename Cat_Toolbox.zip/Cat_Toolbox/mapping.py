"""Default Face_Rig / Eyes_Rig → morph driver mapping (strategy B)."""

from __future__ import annotations

# Morph drivers written on .placeholder shape keys.
# Each entry: shape_key, expression, list of (var_name, rig_role, bone, transform_type)
# rig_role: "face" | "eyes"
MORPH_DRIVERS = [
    (
        "まばたき",
        "-eyes*15 + -eye_blink*100",
        [
            ("eyes", "eyes", "CTL-eyes", "LOC_Z"),
            ("eye_blink", "face", "CTL-eye_blink", "LOC_Z"),
        ],
    ),
    (
        "びっくり",
        "eyes*15 + eye_blink*100 + eye_happy*100",
        [
            ("eyes", "eyes", "CTL-eyes", "LOC_Z"),
            ("eye_blink", "face", "CTL-eye_blink", "LOC_Z"),
            ("eye_happy", "face", "CTL-eye_happy", "LOC_Z"),
        ],
    ),
    (
        "上",
        "eyes*15 + brow_raise*100",
        [
            ("eyes", "eyes", "CTL-eyes", "LOC_Z"),
            ("brow_raise", "face", "CTL-brow_raise", "LOC_Z"),
        ],
    ),
    (
        "下",
        "-eyes*15 + -brow_raise*100",
        [
            ("eyes", "eyes", "CTL-eyes", "LOC_Z"),
            ("brow_raise", "face", "CTL-brow_raise", "LOC_Z"),
        ],
    ),
    (
        "笑い",
        "-eye_happy*100",
        [("eye_happy", "face", "CTL-eye_happy", "LOC_Z")],
    ),
    (
        "じと目",
        "-eye_halflid*100",
        [("eye_halflid", "face", "CTL-eye_halflid", "LOC_X")],
    ),
    (
        "ウィンク２",
        "-eye_wink_L*100",
        [("eye_wink_L", "face", "CTL-eye_wink2_L", "LOC_Z")],
    ),
    (
        "ウィンク",
        "-eye_wink1_L*100",
        [("eye_wink1_L", "face", "CTL-eye_wink1_L", "LOC_Z")],
    ),
    (
        "ｳｨﾝｸ２右",
        "-eye_wink_R*100",
        [("eye_wink_R", "face", "CTL-eye_wink2_R", "LOC_Z")],
    ),
    (
        "ウィンク右",
        "-eye_wink_R*100",
        [("eye_wink_R", "face", "CTL-eye_wink1_R", "LOC_Z")],
    ),
    (
        "ｷﾘｯ",
        "-eye_expr*100",
        [("eye_expr", "face", "CTL-eye_expr", "LOC_X")],
    ),
    (
        "慈愛",
        "eye_expr*100",
        [("eye_expr", "face", "CTL-eye_expr", "LOC_X")],
    ),
    (
        "にこり",
        "brow_2*100",
        [("brow_2", "face", "CTL-brow_2", "LOC_Z")],
    ),
    (
        "真面目",
        "-brow_2*100",
        [("brow_2", "face", "CTL-brow_2", "LOC_Z")],
    ),
    (
        "怒り",
        "-brow_1*100",
        [("brow_1", "face", "CTL-brow_1", "LOC_Z")],
    ),
    (
        "困る",
        "brow_1*100",
        [("brow_1", "face", "CTL-brow_1", "LOC_Z")],
    ),
    (
        "瞳小",
        "eye_small*25",
        [("eye_small", "face", "CTL-eye_small", "LOC_X")],
    ),
    (
        "口角下げ",
        "-mouth_corner*100",
        [("mouth_corner", "face", "CTL-mouth_corner", "LOC_Z")],
    ),
    (
        "口横狭げ",
        "mouth_corner*100",
        [("mouth_corner", "face", "CTL-mouth_corner", "LOC_X")],
    ),
    (
        "にやり",
        "mouth_corner*100",
        [("mouth_corner", "face", "CTL-mouth_corner", "LOC_Z")],
    ),
    (
        "口横広げ",
        "-mouth_corner*100",
        [("mouth_corner", "face", "CTL-mouth_corner", "LOC_X")],
    ),
    ("う", "-mouth_U*50", [("mouth_U", "face", "CTL-mouth_U", "LOC_Z")]),
    ("お", "-mouth_O*50", [("mouth_O", "face", "CTL-mouth_O", "LOC_Z")]),
    ("え", "-mouth_E*50", [("mouth_E", "face", "CTL-mouth_E", "LOC_Z")]),
    ("い", "-mouth_I*50", [("mouth_I", "face", "CTL-mouth_I", "LOC_Z")]),
    ("あ", "-mouth_A*50", [("mouth_A", "face", "CTL-mouth_A", "LOC_Z")]),
]

# Eyes_Rig rotation drivers driven by Face_Rig CTL-eye-Look
# (data_path bone, array_index, expression, transform_type on CTL-eye-Look)
EYE_LOOK_DRIVERS = [
    ("MCH-eye_L", 2, "-eye_look*50", "LOC_X"),
    ("MCH-eye_R", 2, "eye_look*50", "LOC_X"),
    ("MCH-eye_L", 0, "eye_look*50", "LOC_Z"),
    ("MCH-eye_R", 0, "-eye_look*50", "LOC_Z"),
]

# 规范名 → 模型上可能出现的别名（按顺序取第一个存在的）
MORPH_NAME_ALIASES: dict[str, tuple[str, ...]] = {
    "ｷﾘｯ": ("ｷﾘｯ", "怒り目"),
    "慈愛": ("慈愛", "悲しむ"),
    "口横狭げ": ("口横狭げ", "口横缩げ", "口横狭め"),
    "口横広げ": ("口横広げ",),
    "ｳｨﾝｸ２右": ("ｳｨﾝｸ２右", "ウィンク２右"),
}

# 影响眼球烘焙的 CTL（Look / 单眼 / 双眼主控）
EYE_BAKE_CTL_BONES = frozenset(
    {"CTL-eye-Look", "CTL-eyes", "CTL-eye_L", "CTL-eye_R"}
)


def resolve_morph_name(canonical: str, available: set[str]) -> str | None:
    """把映射表规范名解析为网格上实际存在的形态键名。"""
    for name in MORPH_NAME_ALIASES.get(canonical, (canonical,)):
        if name in available:
            return name
    return None


def morphs_driven_by_ctl(ctl_bone: str) -> list[str]:
    """返回某 CTL 骨骼在映射表中驱动的规范形态键名列表。"""
    out: list[str] = []
    for key_name, _expr, vars_spec in MORPH_DRIVERS:
        for _var, _role, bone, _tr in vars_spec:
            if bone == ctl_bone:
                out.append(key_name)
                break
    return out

DEFAULT_WIDGET_NAMES = (
    "WGT-Face_Rig_LMT-eye_look.001",
    "WGT-rig_eye.L",
    "WGT-rig_eye.R",
    "WGT-rig_eyes",
    "口字格",
    "圆环",
    "日字格",
    "田字格",
)

# Common MMD bone name candidates (first match wins)
HEAD_BONE_CANDIDATES = ("頭", "头", "Head", "head", "頭親", "頭亲")
EYE_L_BONE_CANDIDATES = ("目.L", "目左", "Eye.L", "eye.L", "左目")
EYE_R_BONE_CANDIDATES = ("目.R", "目右", "Eye.R", "eye.R", "右目")
