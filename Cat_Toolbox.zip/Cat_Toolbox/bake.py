"""Bake CTL-driven morphs and eyeball bones over a frame range onto the target."""

from __future__ import annotations

import re

import bpy
from mathutils import Matrix

from .mapping import EYE_BAKE_CTL_BONES, morphs_driven_by_ctl, resolve_morph_name
from . import drivers

_CTL_PREFIXES = ("CTL-", "CTRL-", "CTR-")
_BONE_PATH_RE = re.compile(r'pose\.bones\["([^"]+)"\]')
_KEY_PATH_RE = re.compile(r'key_blocks\["(.+?)"\]')


def _is_ctl_bone_name(name: str) -> bool:
    return name.startswith(_CTL_PREFIXES)


def _normalize_ctl_name(name: str) -> str:
    """Map legacy CTRL-/CTR- names to CTL- for mapping lookups."""
    if name.startswith("CTRL-"):
        return "CTL-" + name[5:]
    if name.startswith("CTR-") and not name.startswith("CTL-"):
        return "CTL-" + name[4:]
    return name


def _actions_on_object(obj: bpy.types.Object) -> list:
    ad = obj.animation_data
    if not ad:
        return []
    actions = []
    if ad.action:
        actions.append(ad.action)
    for track in getattr(ad, "nla_tracks", []) or []:
        for strip in track.strips:
            if strip.action and strip.action not in actions:
                actions.append(strip.action)
    return actions


def _actions_on_shape_keys(obj: bpy.types.Object) -> list:
    """形态键动画的 action 列表：Key 对象（obj.data.shape_keys）持有 key_blocks 的 fcurve。"""
    sk = obj.data.shape_keys if obj.type == "MESH" else None
    if not sk:
        return []
    return _actions_on_object(sk)


def _morph_keys_with_animation(obj: bpy.types.Object) -> set[str]:
    """obj（.placeholder 或网格）上形态键（shape_key）名集合：存在 fcurve 关键帧动画的。"""
    keys: set[str] = set()
    for action in _actions_on_shape_keys(obj):
        for fc in _fcurves_for_action(action):
            m = _KEY_PATH_RE.search(fc.data_path or "")
            if m:
                keys.add(m.group(1))
    return keys


def _morph_keys_with_driver(obj: bpy.types.Object) -> set[str]:
    """obj 上被 driver 绑定（CTL 驱动）的形态键名集合。"""
    sk = obj.data.shape_keys if obj.type == "MESH" else None
    if not sk:
        return set()
    ad = sk.animation_data
    if not ad:
        return set()
    keys: set[str] = set()
    for fc in ad.drivers:
        m = _KEY_PATH_RE.search(fc.data_path or "")
        if m:
            keys.add(m.group(1))
    return keys


def _fcurves_for_action(action) -> list:
    if hasattr(action, "fcurves") and action.fcurves:
        return list(action.fcurves)
    curves = []
    for layer in getattr(action, "layers", []) or []:
        for strip in getattr(layer, "strips", []) or []:
            for ch in getattr(strip, "channelbags", []) or []:
                curves.extend(list(getattr(ch, "fcurves", []) or []))
    return curves


def ctl_bones_with_animation(rig: bpy.types.Object) -> set[str]:
    """CTL* bones that have transform fcurves on the rig action / NLA."""
    found: set[str] = set()
    if not rig or rig.type != "ARMATURE":
        return found
    for action in _actions_on_object(rig):
        for fc in _fcurves_for_action(action):
            m = _BONE_PATH_RE.search(fc.data_path or "")
            if not m:
                continue
            bone = m.group(1)
            if not _is_ctl_bone_name(bone):
                continue
            path = fc.data_path or ""
            if "location" in path or "rotation" in path or "scale" in path:
                found.add(bone)
    return found


def _collect_bake_targets(
    face_rig: bpy.types.Object | None,
    eyes_rig: bpy.types.Object | None,
    mesh_morphs: set[str],
) -> tuple[set[str], bool, set[str]]:
    """Return (resolved morph names to bake, bake_eyes, animated CTL bone names)."""
    animated: set[str] = set()
    seen_ids: set[int] = set()
    for rig in (face_rig, eyes_rig):
        if not rig:
            continue
        rid = id(rig)
        if rid in seen_ids:
            continue
        seen_ids.add(rid)
        animated |= ctl_bones_with_animation(rig)

    morphs: set[str] = set()
    bake_eyes = False
    for bone in animated:
        canon = _normalize_ctl_name(bone)
        if canon in EYE_BAKE_CTL_BONES or bone in EYE_BAKE_CTL_BONES:
            bake_eyes = True
        for canonical in morphs_driven_by_ctl(canon):
            actual = resolve_morph_name(canonical, mesh_morphs)
            if actual:
                morphs.add(actual)
    return morphs, bake_eyes, animated


def _sample_morph_values(
    mesh: bpy.types.Object,
    morph_names: set[str],
    frame_start: int,
    frame_end: int,
    source: bpy.types.Object | None = None,
) -> dict[str, list[tuple[int, float]]]:
    """从 mesh（默认）或 source 对象采样形态键值。source 通常用于从 .placeholder 采样。"""
    scene = bpy.context.scene
    sample_obj = source if source is not None else mesh
    sk = sample_obj.data.shape_keys
    samples: dict[str, list[tuple[int, float]]] = {n: [] for n in morph_names}
    for frame in range(frame_start, frame_end + 1):
        scene.frame_set(frame)
        bpy.context.view_layer.update()
        for name in morph_names:
            kb = sk.key_blocks.get(name)
            if kb is None:
                continue
            samples[name].append((frame, float(kb.value)))
    return samples


def _sample_eye_matrices(
    arm: bpy.types.Object,
    eye_bones: tuple[str, ...],
    frame_start: int,
    frame_end: int,
) -> dict[str, list[tuple[int, Matrix]]]:
    """按帧采样目骨视觉姿态，并在同一帧转为 LOCAL（matrix_basis）。

    必须在采样帧做 POSE→LOCAL：父级（頭）随身体动画移动时，若延后到
    其它帧再 convert_space，会把父级位姿误差写进 location，导致眼球飞走。
    """
    scene = bpy.context.scene
    samples: dict[str, list[tuple[int, Matrix]]] = {n: [] for n in eye_bones}
    for frame in range(frame_start, frame_end + 1):
        scene.frame_set(frame)
        bpy.context.view_layer.update()
        for name in eye_bones:
            pb = arm.pose.bones.get(name)
            if not pb:
                continue
            # 含约束的最终姿态 → 当前帧父级下的局部矩阵
            local = arm.convert_space(
                pose_bone=pb,
                matrix=pb.matrix.copy(),
                from_space="POSE",
                to_space="LOCAL",
            )
            samples[name].append((frame, local))
    return samples


def _apply_morph_keyframes(
    mesh: bpy.types.Object,
    placeholder: bpy.types.Object | None,
    samples: dict[str, list[tuple[int, float]]],
) -> int:
    """Remove drivers on baked morphs, write keyframes on mesh (and placeholder if present)."""
    sk = mesh.data.shape_keys
    ph_sk = placeholder.data.shape_keys if placeholder and placeholder.data.shape_keys else None
    count = 0
    for name, frames in samples.items():
        if not frames:
            continue
        kb = sk.key_blocks.get(name)
        ph_kb = ph_sk.key_blocks.get(name) if ph_sk else None
        if not kb and not ph_kb:
            continue
        drivers.remove_shape_key_driver(sk, name)
        if ph_sk:
            drivers.remove_shape_key_driver(ph_sk, name)
        for frame, value in frames:
            if kb is not None:
                kb.value = value
                kb.keyframe_insert("value", frame=frame)
            if ph_kb is not None:
                ph_kb.value = value
                ph_kb.keyframe_insert("value", frame=frame)
        count += 1
    return count


def _mute_eye_control(pb: bpy.types.PoseBone):
    """静音 目 骨上插件的「眼控追踪」Damped Track，让烘焙写入的局部关键帧生效。"""
    for c in pb.constraints:
        if c.type == "DAMPED_TRACK" and c.name == "眼控追踪":
            c.mute = True


def _apply_eye_keyframes(
    arm: bpy.types.Object,
    samples: dict[str, list[tuple[int, Matrix]]],
) -> int:
    """静音眼控约束，将已换算好的 LOCAL 矩阵写入目骨关键帧。"""
    count = 0
    for name, frames in samples.items():
        if not frames:
            continue
        pb = arm.pose.bones.get(name)
        if not pb:
            continue
        _mute_eye_control(pb)
        # Prefer quaternion for baking stability
        if pb.rotation_mode == "QUATERNION":
            rot_path = "rotation_quaternion"
        else:
            rot_path = "rotation_euler"
        for frame, local in frames:
            pb.matrix_basis = local
            pb.keyframe_insert("location", frame=frame)
            pb.keyframe_insert(rot_path, frame=frame)
            pb.keyframe_insert("scale", frame=frame)
        count += 1
    return count


def find_placeholder() -> bpy.types.Object | None:
    return bpy.data.objects.get(".placeholder")


def bake_mmd_bone_animation(
    arm: bpy.types.Object,
    bone_names: list[str],
    frame_start: int,
    frame_end: int,
) -> int:
    """按帧烘焙 MMD 标准骨骼的最终姿态（含约束）为局部关键帧。

    采样当帧把 POSE 矩阵转为 LOCAL（matrix_basis），避免父级动画被写进
    局部位移；返回实际写入关键帧的骨骼数量。不存在的骨骼自动跳过。
    """
    if frame_end < frame_start:
        raise RuntimeError("结束帧必须 ≥ 起始帧")
    present = [n for n in bone_names if n in arm.pose.bones]
    if not present:
        return 0

    scene = bpy.context.scene
    samples: dict[str, list[tuple[int, Matrix]]] = {n: [] for n in present}
    for frame in range(frame_start, frame_end + 1):
        scene.frame_set(frame)
        bpy.context.view_layer.update()
        for name in present:
            pb = arm.pose.bones[name]
            local = arm.convert_space(
                pose_bone=pb,
                matrix=pb.matrix.copy(),
                from_space="POSE",
                to_space="LOCAL",
            )
            samples[name].append((frame, local))

    count = 0
    for name, frames in samples.items():
        if not frames:
            continue
        pb = arm.pose.bones[name]
        rot_path = (
            "rotation_quaternion"
            if pb.rotation_mode == "QUATERNION"
            else "rotation_euler"
        )
        for frame, local in frames:
            pb.matrix_basis = local
            pb.keyframe_insert("location", frame=frame)
            pb.keyframe_insert(rot_path, frame=frame)
            pb.keyframe_insert("scale", frame=frame)
        count += 1
    return count


def bake_ctl_animation(
    face_rig: bpy.types.Object | None,
    eyes_rig: bpy.types.Object | None,
    target_arm: bpy.types.Object,
    target_mesh: bpy.types.Object,
    eye_l: str,
    eye_r: str,
    frame_start: int,
    frame_end: int,
    *,
    bake_eyeballs: bool = True,
) -> str:
    """Bake CTL animation over [frame_start, frame_end] onto mesh morphs and 目 bones.

    CTL actions are left intact; drivers on baked morphs are removed so keyframes stick;
    eye-control Damped Track on baked eye bones is muted.
    When bake_eyeballs is False (Rigify compat), only morphs are baked.
    """
    if frame_end < frame_start:
        raise RuntimeError("结束帧必须 ≥ 起始帧")
    if not target_mesh or not target_mesh.data.shape_keys:
        raise RuntimeError("目标网格缺少形态键")

    mesh_morphs = drivers.all_mesh_morph_names(target_mesh)
    morphs, bake_eyes, animated = _collect_bake_targets(face_rig, eyes_rig, mesh_morphs)
    if not bake_eyeballs:
        bake_eyes = False

    # .placeholder 中未被 CTL driver 绑定、但有关键帧动画的形态键（例如手动K帧/外部导入），一并烘焙
    placeholder = find_placeholder()
    placeholder_keyed = set()
    if placeholder and placeholder.type == "MESH" and placeholder.data.shape_keys:
        placeholder_keyed = _morph_keys_with_animation(placeholder) - _morph_keys_with_driver(placeholder)
        placeholder_keyed.discard("Basis")
        placeholder_keyed.discard("--- morph sliders ---")
        # 仅在 placeholder 有该形态键、且未包含在 CTL 解析结果中时加入
        morphs |= placeholder_keyed

    if not animated and not placeholder_keyed:
        raise RuntimeError("未找到带关键帧的 CTL 骨骼或 .placeholder 关键帧，请先完成 Rig 动画")
    if not morphs and not bake_eyes:
        raise RuntimeError(
            f"已找到 CTL 动画 ({', '.join(sorted(animated))})，但没有可烘焙的形态键/眼球映射"
        )

    scene = bpy.context.scene
    prev_frame = scene.frame_current

    try:
        morph_n = 0
        eye_n = 0
        if morphs:
            # CTL 驱动的形态键从目标网格采样；placeholder 上额外手K的形态键从 placeholder 采样
            ctl_morphs = morphs - placeholder_keyed
            extra_morphs = morphs & placeholder_keyed
            samples: dict[str, list[tuple[int, float]]] = {}
            if ctl_morphs:
                samples.update(
                    _sample_morph_values(target_mesh, ctl_morphs, frame_start, frame_end)
                )
            if extra_morphs and placeholder:
                samples.update(
                    _sample_morph_values(target_mesh, extra_morphs, frame_start, frame_end, source=placeholder)
                )
            morph_n = _apply_morph_keyframes(target_mesh, placeholder, samples)
        if bake_eyes:
            eye_bones = tuple(b for b in (eye_l, eye_r) if b in target_arm.pose.bones)
            if eye_bones:
                # Sample while constraints still active
                eye_samples = _sample_eye_matrices(
                    target_arm, eye_bones, frame_start, frame_end
                )
                eye_n = _apply_eye_keyframes(target_arm, eye_samples)
    finally:
        scene.frame_set(prev_frame)
        bpy.context.view_layer.update()

    note = ""
    if not bake_eyeballs:
        note = "（Rigify兼容：跳过眼球烘焙）"
    extra_note = ""
    if placeholder_keyed:
        extra_note = f"，placeholder额外K帧={len(placeholder_keyed)}"
    return (
        f"烘焙完成{note}: 帧 {frame_start}-{frame_end}, "
        f"CTL={len(animated)}, 形态键={morph_n}, 眼球骨={eye_n}{extra_note}"
    )
