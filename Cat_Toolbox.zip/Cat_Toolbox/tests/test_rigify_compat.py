"""Unit tests for Rigify compat mode resolution (no Blender required)."""

from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


def _load_rigify_compat():
    path = Path(__file__).resolve().parents[1] / "rigify_compat.py"
    spec = importlib.util.spec_from_file_location("rigify_compat_under_test", path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


_rc = _load_rigify_compat()


class ResolveCompatEnabledTests(unittest.TestCase):
    def test_on_forces_true(self):
        self.assertTrue(_rc.resolve_compat_enabled(_rc.COMPAT_ON, False))
        self.assertTrue(_rc.resolve_compat_enabled(_rc.COMPAT_ON, True))

    def test_off_forces_false(self):
        self.assertFalse(_rc.resolve_compat_enabled(_rc.COMPAT_OFF, False))
        self.assertFalse(_rc.resolve_compat_enabled(_rc.COMPAT_OFF, True))

    def test_auto_follows_detection(self):
        self.assertTrue(_rc.resolve_compat_enabled(_rc.COMPAT_AUTO, True))
        self.assertFalse(_rc.resolve_compat_enabled(_rc.COMPAT_AUTO, False))


class EyeControlBoneNameTests(unittest.TestCase):
    def test_exact_and_lid_controls(self):
        self.assertTrue(_rc._is_rigify_eye_control_bone("eyes"))
        self.assertTrue(_rc._is_rigify_eye_control_bone("eye.L"))
        self.assertTrue(_rc._is_rigify_eye_control_bone("master_eye.R"))
        self.assertTrue(_rc._is_rigify_eye_control_bone("lid.T.L.002"))

    def test_skips_org_def_mch(self):
        self.assertFalse(_rc._is_rigify_eye_control_bone("ORG-eye.L"))
        self.assertFalse(_rc._is_rigify_eye_control_bone("DEF-lid.T.L"))
        self.assertFalse(_rc._is_rigify_eye_control_bone("MCH-eye.L"))

    def test_skips_unrelated(self):
        self.assertFalse(_rc._is_rigify_eye_control_bone("head"))
        self.assertFalse(_rc._is_rigify_eye_control_bone("spine.006"))


if __name__ == "__main__":
    unittest.main()
