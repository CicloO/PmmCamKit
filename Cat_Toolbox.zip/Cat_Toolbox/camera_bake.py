"""MMD相机烘焙核心模块 — 从 mmd_tools 修改版移植"""
from __future__ import annotations

import math

import bpy
from mathutils import Matrix, Vector


# ============================================================================
# FnCamera：低级工具 — 添加/移除 MMD 相机驱动器
# ============================================================================

class FnCamera:
    @staticmethod
    def add_drivers(camera_object: bpy.types.Object):
        """为 MMD 相机子级添加驱动器，使其属性跟随 Empty 父级。"""
        def __add_driver(id_data, data_path: str, expression: str, index: int = -1):
            d = id_data.driver_add(data_path, index).driver
            d.type = "SCRIPTED"
            if "$empty_distance" in expression:
                v = d.variables.new()
                v.name = "empty_distance"
                v.type = "TRANSFORMS"
                v.targets[0].id = camera_object
                v.targets[0].transform_type = "LOC_Y"
                v.targets[0].transform_space = "LOCAL_SPACE"
                expression = expression.replace("$empty_distance", v.name)
            if "$is_perspective" in expression:
                v = d.variables.new()
                v.name = "is_perspective"
                v.type = "SINGLE_PROP"
                v.targets[0].id_type = "OBJECT"
                v.targets[0].id = camera_object.parent
                v.targets[0].data_path = "mmd_camera.is_perspective"
                expression = expression.replace("$is_perspective", v.name)
            if "$angle" in expression:
                v = d.variables.new()
                v.name = "angle"
                v.type = "SINGLE_PROP"
                v.targets[0].id_type = "OBJECT"
                v.targets[0].id = camera_object.parent
                v.targets[0].data_path = "mmd_camera.angle"
                expression = expression.replace("$angle", v.name)
            if "$sensor_height" in expression:
                v = d.variables.new()
                v.name = "sensor_height"
                v.type = "SINGLE_PROP"
                v.targets[0].id_type = "CAMERA"
                v.targets[0].id = camera_object.data
                v.targets[0].data_path = "sensor_height"
                expression = expression.replace("$sensor_height", v.name)
            d.expression = expression

        __add_driver(camera_object.data, "ortho_scale", "25*abs($empty_distance)/45")
        __add_driver(camera_object, "rotation_euler",
                     "pi if $is_perspective == False and $empty_distance > 1e-5 else 0",
                     index=1)
        __add_driver(camera_object.data, "type", "not $is_perspective")
        __add_driver(camera_object.data, "lens", "$sensor_height/tan($angle/2)/2")

    @staticmethod
    def remove_drivers(camera_object: bpy.types.Object):
        """移除 MMD 相机驱动器。

        BUG FIX：原版修改版中第三行错误地重复删除了 ortho_scale 而未删除 type。
        """
        camera_object.data.driver_remove("ortho_scale")
        camera_object.driver_remove("rotation_euler")
        camera_object.data.driver_remove("type")      # ← 修正：原为 ortho_scale（重复）
        camera_object.data.driver_remove("lens")


# ============================================================================
# MMDCamera：烘焙主逻辑
# ============================================================================

class MMDCamera:
    def __init__(self, obj: bpy.types.Object):
        self.__emptyObj = obj

    @staticmethod
    def _lens_to_angle(cameraObj: bpy.types.Object, factor: float,
                       lens_val: float | None = None) -> float:
        """将焦距（mm）转换为视场角（弧度）。"""
        current_lens = lens_val if lens_val is not None else cameraObj.data.lens
        if current_lens <= 0:
            current_lens = 0.001
        tan_val = cameraObj.data.sensor_height / current_lens / 2
        if cameraObj.data.sensor_fit != "VERTICAL":
            ratio = cameraObj.data.sensor_width / cameraObj.data.sensor_height
            if cameraObj.data.sensor_fit == "HORIZONTAL":
                tan_val *= factor * ratio
            else:  # AUTO
                tan_val *= min(ratio, factor * ratio)
        return 2 * math.atan(tan_val)

    @staticmethod
    def convertToMMDCamera(cameraObj: bpy.types.Object, scale: float = 1.0,
                           init_mmd: bool = True):
        """将普通相机转换为 MMD 相机装备（Empty 父级 + Camera 子级）。

        BUG FIX：原版修改版缺少 init_mmd 参数，导致烘焙时中间相机的
        视角/透视硬编码为默认值。已从官方版补回该逻辑。
        """
        scene = bpy.context.scene
        empty = bpy.data.objects.new(name="MMD_Camera", object_data=None)
        bpy.context.collection.objects.link(empty)

        if not init_mmd:
            render = scene.render
            factor = ((render.resolution_y * render.pixel_aspect_y)
                      / (render.resolution_x * render.pixel_aspect_x))
            original_angle = MMDCamera._lens_to_angle(cameraObj, factor)
            original_persp = cameraObj.data.type != "ORTHO"

        cameraObj.parent = empty
        cameraObj.data.sensor_fit = "VERTICAL"
        cameraObj.data.lens_unit = "MILLIMETERS"
        cameraObj.data.ortho_scale = 25 * scale
        cameraObj.data.clip_end = 500 * scale
        setattr(cameraObj.data, "display_size", 5 * scale)
        cameraObj.location = (0, -45 * scale, 0)
        cameraObj.rotation_mode = "XYZ"
        cameraObj.rotation_euler = (math.radians(90), 0, 0)
        cameraObj.lock_location = (True, False, True)
        cameraObj.lock_rotation = (True, True, True)
        cameraObj.lock_scale = (True, True, True)
        cameraObj.data.dof.focus_object = empty
        FnCamera.add_drivers(cameraObj)

        empty.location = (0, 0, 10 * scale)
        empty.rotation_mode = "YXZ"
        setattr(empty, "empty_display_size", 5 * scale)
        empty.lock_scale = (True, True, True)
        empty.mmd_type = "CAMERA"  # mmd_tools 识别标记
        if init_mmd:
            empty.mmd_camera.angle = math.radians(30)
            empty.mmd_camera.is_perspective = True
        else:
            cameraObj.location = (0, 0, 0)
            empty.mmd_camera.angle = original_angle
            empty.mmd_camera.is_perspective = original_persp

        return MMDCamera(empty)

    @staticmethod
    def newMMDCameraAnimation(
        cameraObj,
        cameraTarget=None,
        scale: float = 1.0,
        min_distance: float = 0.1,
        step: int = 1,
        fov_integer: bool = False,
        ref_depth: float = 0.0,
    ):
        """将源相机动画烘焙到新的 MMD 相机装备。

        Args:
            cameraObj: 源相机对象（None 则使用场景相机）。
            cameraTarget: 相机目标对象（None 则使用 DoF 焦点物体）。
            scale: 场景缩放。
            min_distance: 最小距离（防止穿模）。
            step: 步长，每隔 N 帧采样一帧（1=逐帧）。
            fov_integer: 视角取整并用距离补偿（适配 VMD 整数视角）。
            ref_depth: 补偿参考深度（无目标物体时使用，0=自动取世界原点）。
        """
        scene = bpy.context.scene
        mmd_cam = bpy.data.objects.new(
            name="Camera",
            object_data=bpy.data.cameras.new("Camera"),
        )
        bpy.context.collection.objects.link(mmd_cam)

        # BUG FIX：传递 init_mmd=False，使中间相机继承原始相机的视角/透视
        MMDCamera.convertToMMDCamera(mmd_cam, scale=scale, init_mmd=False)
        mmd_cam_root = mmd_cam.parent

        _camera_override_func = None
        if cameraObj is None:
            if scene.camera is None:
                scene.camera = mmd_cam
                return MMDCamera(mmd_cam_root)

            def _camera_override_func():
                return scene.camera

        _target_override_func = None
        if cameraTarget is None:
            def _target_override_func(camObj):
                return camObj.data.dof.focus_object or camObj

        # 解析用于预检的源相机（可能由 override 提供）
        src_cam: bpy.types.Object | None = cameraObj
        if src_cam is None and _camera_override_func is not None:
            src_cam = _camera_override_func()

        action_name = mmd_cam_root.name
        parent_action = bpy.data.actions.new(name=action_name)
        distance_action = bpy.data.actions.new(name=action_name + "_dis")
        FnCamera.remove_drivers(mmd_cam)

        render = scene.render
        factor = ((render.resolution_y * render.pixel_aspect_y)
                  / (render.resolution_x * render.pixel_aspect_x))
        matrix_rotation = Matrix((
            [1, 0, 0, 0],
            [0, 0, 1, 0],
            [0, -1, 0, 0],
            [0, 0, 0, 1],
        ))
        neg_z_vector = Vector((0, 0, -1))
        frame_start = scene.frame_start
        frame_end = scene.frame_end + 1
        frame_current = scene.frame_current
        frame_count = frame_end - frame_start
        frames = range(frame_start, frame_end)

        # 创建 FCurves — 使用 mmd_camera.* 路径，与 mmd_tools 兼容
        fcurves = []
        for i in range(3):
            fcurves.append(parent_action.fcurves.new(
                data_path="location", index=i))
        for i in range(3):
            fcurves.append(parent_action.fcurves.new(
                data_path="rotation_euler", index=i))
        fcurves.append(parent_action.fcurves.new(
            data_path="mmd_camera.angle"))
        fcurves.append(parent_action.fcurves.new(
            data_path="mmd_camera.is_perspective"))
        fcurves.append(distance_action.fcurves.new(
            data_path="location", index=1))

        for c in fcurves:
            c.keyframe_points.add(frame_count)

        # 收集原始关键帧帧号（用于步长跳过时保留原始关键帧）
        origin_key_frames: set[float] = set()
        if src_cam:
            parent = src_cam.parent
            if (parent and parent.animation_data
                    and parent.animation_data.action
                    and parent.animation_data.action.fcurves):
                for fc in parent.animation_data.action.fcurves:
                    for kp in fc.keyframe_points:
                        origin_key_frames.add(kp.co.x)
            elif (src_cam.animation_data and src_cam.animation_data.action):
                for fc in src_cam.animation_data.action.fcurves:
                    for kp in fc.keyframe_points:
                        origin_key_frames.add(kp.co.x)

        cur_step = 0
        step_gap = step - 1
        # BUG FIX：逐帧独立 to_euler() 会把角度折回 ±180°，跨越 ±180° 时
        # 相邻关键帧数值突变（如 -179° → 178°），导出 VMD 后出现跳帧。
        # 以上一采样帧的欧拉角作为兼容参考，保持旋转曲线连续。
        prev_rotation = None

        for f, x, y, z, rx, ry, rz, fov, persp, dis in zip(
            frames, *(c.keyframe_points for c in fcurves)
        ):
            # 步长跳过逻辑（原版修改版行为）
            if step_gap >= 1:
                if cur_step < step_gap:
                    cur_step += 1
                    if f not in origin_key_frames:
                        continue
                else:
                    cur_step = 0
                    if (f not in origin_key_frames
                            and (f + 1) in origin_key_frames):
                        continue
                if f in origin_key_frames:
                    cur_step = 0

            scene.frame_set(f)
            if _camera_override_func:
                cameraObj = _camera_override_func()
            if _target_override_func:
                cameraTarget = _target_override_func(cameraObj)

            cam_matrix_world = cameraObj.matrix_world
            cam_target_loc = cameraTarget.matrix_world.translation
            rot_matrix = (cam_matrix_world @ matrix_rotation).to_3x3()
            if prev_rotation is None:
                cam_rotation = rot_matrix.to_euler(mmd_cam_root.rotation_mode)
            else:
                cam_rotation = rot_matrix.to_euler(
                    mmd_cam_root.rotation_mode, prev_rotation)
            prev_rotation = cam_rotation
            cam_vec = cam_matrix_world.to_3x3() @ neg_z_vector

            if cameraObj.data.type == "ORTHO":
                cam_dis = -(9 / 5) * cameraObj.data.ortho_scale
                if cameraObj.data.sensor_fit != "VERTICAL":
                    ratio = (cameraObj.data.sensor_width
                             / cameraObj.data.sensor_height)
                    if cameraObj.data.sensor_fit == "HORIZONTAL":
                        cam_dis *= factor
                    else:
                        cam_dis *= min(1, factor)
            else:
                target_vec = (cam_target_loc
                              - cam_matrix_world.translation)
                cam_dis = -max(
                    target_vec.length
                    * cam_vec.dot(target_vec.normalized()),
                    min_distance,
                )
            cam_target_loc = (cam_matrix_world.translation
                              - cam_vec * cam_dis)

            tan_val = (cameraObj.data.sensor_height
                       / cameraObj.data.lens / 2)
            if cameraObj.data.sensor_fit != "VERTICAL":
                ratio = (cameraObj.data.sensor_width
                         / cameraObj.data.sensor_height)
                if cameraObj.data.sensor_fit == "HORIZONTAL":
                    tan_val *= factor * ratio
                else:
                    tan_val *= min(ratio, factor * ratio)
            fov_val = 2 * math.atan(tan_val)

            # VMD 视角是整数度，mmd_tools 导出时 round()。小视角变焦时
            # 每 1° 都是明显跳变。这里先把视角取整，再按参考深度处的画面
            # 大小不变，把相机沿视线前后平移来补偿取整误差。目标点/距离
            # 保持原逻辑，只整体平移，关键帧间插值行为与原版一致。
            if fov_integer and cameraObj.data.type != "ORTHO":
                fov_int = math.radians(max(1, round(math.degrees(fov_val))))
                if cameraTarget is not cameraObj:
                    depth = -cam_dis
                elif ref_depth > 0:
                    depth = ref_depth
                else:  # 无目标：取世界原点在视线上的投影深度
                    depth = (-cam_matrix_world.translation).dot(cam_vec)
                depth = max(depth, min_distance)
                comp_depth = depth * math.tan(fov_val / 2) / math.tan(fov_int / 2)
                cam_target_loc = cam_target_loc + cam_vec * (depth - comp_depth)
                fov_val = fov_int

            x.co, y.co, z.co = ((f, i) for i in cam_target_loc)
            rx.co, ry.co, rz.co = ((f, i) for i in cam_rotation)
            dis.co = (f, cam_dis)
            fov.co = (f, fov_val)
            persp.co = (f, cameraObj.data.type != "ORTHO")
            persp.interpolation = "CONSTANT"
            for kp in (x, y, z, rx, ry, rz, fov, dis):
                kp.interpolation = "LINEAR"

        FnCamera.add_drivers(mmd_cam)

        # 移除帧 0 上的多余关键帧
        for fc in parent_action.fcurves:
            kps = fc.keyframe_points
            for i in range(len(kps) - 1, -1, -1):
                if kps[i].co.x == 0:
                    kps.remove(kps[i])
        mmd_cam_root.animation_data_create().action = parent_action

        for fc in distance_action.fcurves:
            kps = fc.keyframe_points
            for i in range(len(kps) - 1, -1, -1):
                if kps[i].co.x == 0:
                    kps.remove(kps[i])
        mmd_cam.animation_data_create().action = distance_action

        scene.frame_set(frame_current)
        return MMDCamera(mmd_cam_root)

    def object(self) -> bpy.types.Object:
        return self.__emptyObj

    def camera(self) -> bpy.types.Object:
        for i in self.__emptyObj.children:
            if i.type == "CAMERA":
                return i
        raise KeyError(f"{self.__emptyObj.name} 下没有 Camera 子物体")


CLASSES = ()
