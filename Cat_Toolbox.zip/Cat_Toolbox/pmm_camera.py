"""PMM（MMD 工程文件）相机关键帧的"骨骼追从"批量绑定。

MMD 的相机追从（模型+骨骼）按每个相机关键帧单独保存在 PMM 里，VMD 不保存。
读入的相机 VMD 关键帧全部是未绑定状态，这里把已绑定关键帧的追从设置
向后填充给之后未绑定的关键帧（或全部覆盖）。

只原地改写每个关键帧里"追从模型序号/骨骼序号"这 8 个字节，文件其余部分不变。
格式参考 Scallion（MIT，paralleltree/Scallion）对 "Polygon Movie maker 0002" 的解析。
不依赖 bpy，可单独运行：python pmm_camera.py 工程.pmm [--all]
"""
from __future__ import annotations

import os
import struct

SIGNATURE = b"Polygon Movie maker 0002"
ENC = "cp932"


class PmmError(Exception):
    pass


class _Reader:
    def __init__(self, data: bytes):
        self.d = data
        self.o = 0

    def need(self, n):
        if self.o + n > len(self.d):
            raise PmmError(f"文件意外结束（偏移 {self.o}，需要 {n} 字节）")

    def skip(self, n):
        self.need(n)
        self.o += n

    def u8(self):
        self.need(1)
        v = self.d[self.o]
        self.o += 1
        return v

    def i32(self):
        self.need(4)
        v, = struct.unpack_from("<i", self.d, self.o)
        self.o += 4
        return v

    def f32(self):
        self.need(4)
        v, = struct.unpack_from("<f", self.d, self.o)
        self.o += 4
        return v

    def fixed_str(self, n):
        self.need(n)
        b = self.d[self.o:self.o + n]
        self.o += n
        return b.split(b"\0", 1)[0].decode(ENC, "replace")

    def var_str(self):
        return self.fixed_str(self.u8())

    def count(self, limit=10_000_000):
        n = self.i32()
        if not 0 <= n <= limit:
            raise PmmError(f"数量异常 {n}（偏移 {self.o - 4}），可能不是支持的 PMM 版本")
        return n


# 关键帧头：(非初始帧才有的 DataIndex) + 帧号 + 前一帧索引 + 后一帧索引
def _kf_header(r, initial):
    if not initial:
        r.skip(4)
    frame = r.i32()
    r.skip(8)
    return frame


def _skip_model(r: _Reader):
    mid = r.u8()                            # 模型 ID（引用用的序号，不一定连续）
    name = r.var_str()
    r.var_str()                             # 英文名
    r.fixed_str(256)                        # 路径
    r.u8()                                  # 时间轴行数
    bones = [r.var_str() for _ in range(r.count(100000))]
    nmorph = r.count(100000)
    for _ in range(nmorph):
        r.var_str()
    nik = r.count(100000)
    r.skip(4 * nik)
    nep = r.count(100000)
    r.skip(4 * nep)
    r.skip(1 + 1 + 4 + 16)                  # 渲染顺序、显示、选中骨骼、表情面板
    r.skip(r.u8())                          # 骨骼组展开状态
    r.skip(4 + 4)                           # 时间轴顶行、最后帧
    # 骨骼关键帧：插值16 + 位置12 + 四元数16 + 选中1 + 物理1 = 46
    r.skip(len(bones) * (12 + 46))
    r.skip(r.count() * (16 + 46))
    # 表情关键帧：权重4 + 选中1
    r.skip(nmorph * (12 + 5))
    r.skip(r.count() * (16 + 5))
    # 模型关键帧（显示/IK/外部亲）：显示1 + IK n + 外部亲 8m + 选中1
    model_kf = 1 + nik + 8 * nep + 1
    r.skip(12 + model_kf)
    r.skip(r.count() * (16 + model_kf))
    r.skip(len(bones) * 31)                 # 当前骨骼状态
    r.skip(nmorph * 4)                      # 当前表情
    r.skip(nik)                             # 当前 IK 开关
    r.skip(nep * 16)                        # 当前外部亲
    r.skip(1 + 4 + 1 + 1)                   # 加算合成、边线宽、自阴影、计算顺序
    return mid, name, bones


# 相机关键帧：距离4 + 中心12 + 旋转12 + 追从模型4 + 追从骨骼4 + 插值24 + 透视1 + 视角4 + 选中1
_CAM_FOLLOW_OFS = 4 + 12 + 12


class CameraKey:
    __slots__ = ("frame", "follow_ofs", "model", "bone", "fov", "initial")


def parse(data: bytes):
    """解析到相机段为止（并校验之后的灯光段与饰品名称）。返回 (模型列表, 相机关键帧列表)。"""
    r = _Reader(data)
    if not data.startswith(SIGNATURE):
        raise PmmError("不是 MMD 9.x 的 PMM 文件（签名不符）")
    r.skip(30)
    r.skip(8 + 4 + 4 + 1 + 6 + 1)           # 输出尺寸、时间轴宽、视角、选中、面板展开、选中模型
    models = [_skip_model(r) for _ in range(r.u8())]

    keys = []
    for k in range(1 + 1):                  # 初始帧，然后是关键帧列表
        if k == 0:
            items = [True]
        else:
            items = [False] * r.count()
        for initial in items:
            ck = CameraKey()
            ck.initial = initial
            ck.frame = _kf_header(r, initial)
            ck.follow_ofs = r.o + _CAM_FOLLOW_OFS
            r.skip(_CAM_FOLLOW_OFS)
            ck.model = r.i32()
            ck.bone = r.i32()
            r.skip(24 + 1)
            ck.fov = r.i32()
            r.skip(1)
            keys.append(ck)
    r.skip(12 + 12 + 12 + 1)                # 当前相机状态

    # 校验：灯光段 + 饰品名称应当能正常读出
    _kf_header(r, True)
    r.skip(25)
    r.skip(r.count() * (16 + 25))
    r.skip(24)
    r.u8()
    r.i32()
    nacc = r.u8()
    for _ in range(nacc):
        r.fixed_str(100)

    ids = {m[0] for m in models}
    for ck in keys:
        if not (0 <= ck.frame < 10_000_000 and 0 <= ck.fov <= 180
                and (ck.model == -1 or ck.model in ids)):
            raise PmmError("相机关键帧数据异常，可能不是支持的 PMM 版本")
    keys.sort(key=lambda c: c.frame)
    return models, keys


def bind_follow(src_path, dst_path=None, overwrite_all=False):
    """把相机追从设置向后填充给未绑定的关键帧。

    overwrite_all=False：每个未绑定关键帧继承它之前最近一个已绑定关键帧的设置；
    overwrite_all=True：全部关键帧都改成第一个已绑定关键帧的设置。
    dst_path 默认为 "原文件名_追从.pmm"，不覆盖原文件。返回统计信息 dict。
    """
    data = bytearray(open(src_path, "rb").read())
    models, keys = parse(bytes(data))
    bound = [k for k in keys if k.model >= 0]
    if not bound:
        raise PmmError("没有任何已绑定追从的相机关键帧：请先在 MMD 里给第一个相机关键帧设置骨骼追从并保存")

    first = bound[0]
    cur = None
    changed = 0
    for k in keys:
        if overwrite_all:
            target = (first.model, first.bone)
        elif k.model >= 0:
            cur = (k.model, k.bone)
            continue
        else:
            target = cur
        if target is None or (k.model, k.bone) == target:
            continue
        struct.pack_into("<ii", data, k.follow_ofs, *target)
        changed += 1

    if dst_path is None:
        base, ext = os.path.splitext(src_path)
        dst_path = base + "_追従" + ext
    with open(dst_path, "wb") as f:
        f.write(data)

    byid = {mid: (name, bones) for mid, name, bones in models}

    def desc(m, b):
        if m not in byid:
            return "无" if m < 0 else f"模型#{m}"
        name, bones = byid[m]
        return f"{name} / {bones[b] if 0 <= b < len(bones) else b}"

    return {
        "path": dst_path,
        "keys": len(keys),
        "changed": changed,
        "skipped_before_first": sum(1 for k in keys if k.frame < first.frame and k.model < 0),
        "first_frame": first.frame,
        "first_target": desc(first.model, first.bone),
    }


def summary(path):
    models, keys = parse(open(path, "rb").read())
    lines = [f"模型 {len(models)} 个，相机关键帧 {len(keys)} 个"]
    byid = {mid: (name, bones) for mid, name, bones in models}
    for mid, name, bones in models:
        lines.append(f"  [ID {mid}] {name}（骨骼 {len(bones)}）")
    bound = sum(1 for k in keys if k.model >= 0)
    lines.append(f"已绑定追从 {bound} 个，未绑定 {len(keys) - bound} 个")
    for k in keys[:10]:
        tgt = "无" if k.model < 0 else f"{byid[k.model][0]}/{byid[k.model][1][k.bone]}"
        lines.append(f"  帧 {k.frame:5d} 视角 {k.fov:3d} 追从 {tgt}")
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print("用法：python pmm_camera.py 工程.pmm [--all]   （--all：全部关键帧改成第一个已绑定的设置）")
        sys.exit(1)
    for p in args:
        print(summary(p))
        st = bind_follow(p, overwrite_all="--all" in sys.argv)
        print(f"已写入 {st['path']}：共 {st['keys']} 个关键帧，修改 {st['changed']} 个"
              f"（第一个已绑定在第 {st['first_frame']} 帧：{st['first_target']}）")
