"""Operators: bake CTL animation; clean redundant keyframes."""

from __future__ import annotations

import bpy
from bpy.types import Operator

from . import bake, clean_keys
from .build_rig import MERGED_INTO_PROP, host_has_face_ctrl_bones
from .ops_mmd_select import MMD_BONE_NAMES
from .props import auto_fill_settings
from .rigify_compat import looks_like_rigify_control_rig


def _find_face_rig() -> bpy.types.Object | None:
    """独立 Face_Rig，或已合并进 Rigify 的宿主骨架。"""
    face = bpy.data.objects.get("Face_Rig")
    if face:
        return face
    for obj in bpy.data.objects:
        if obj.type != "ARMATURE":
            continue
        if obj.get(MERGED_INTO_PROP):
            return obj
        if looks_like_rigify_control_rig(obj) and host_has_face_ctrl_bones(obj):
            return obj
    return None

def _resolve_bake_inputs(context, op):
    """公共前置校验；返回 (arm, mesh, face, eyes_legacy, frame_start, frame_end)，失败 report 并返回 None。"""
    s = context.scene.face_eyes_ctrl
    auto_fill_settings(context)

    arm = s.target_armature
    mesh = s.target_mesh
    if not arm or arm.type != "ARMATURE":
        op.report({"ERROR"}, "请指定目标骨架")
        return None
    if not mesh or mesh.type != "MESH":
        op.report({"ERROR"}, "请指定目标网格")
        return None

    face = _find_face_rig()
    eyes_legacy = bpy.data.objects.get("Eyes_Rig")
    if not face and not eyes_legacy:
        op.report({"ERROR"}, "场景中找不到 Face_Rig")
        return None

    try:
        if context.object and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
    except Exception:
        pass

    frame_start = int(context.scene.frame_start)
    frame_end = int(context.scene.frame_end)
    return arm, mesh, face, eyes_legacy, frame_start, frame_end


class FACE_EYES_OT_bake(Operator):
    bl_idname = "face_eyes_ctrl.bake"
    bl_label = "仅烘焙面部（含左目/右目）"
    bl_description = "将 Face_Rig 的 CTL 动画烘焙为形态键关键帧，并把左目/右目眼球骨骼姿态烘焙为目标骨架关键帧"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.face_eyes_ctrl
        inputs = _resolve_bake_inputs(context, self)
        if inputs is None:
            return {"CANCELLED"}
        arm, mesh, face, eyes_legacy, frame_start, frame_end = inputs

        try:
            was_hidden = arm.hide_get()
            if was_hidden:
                arm.hide_set(False)

            # 合并骨架：face 同时承担 eyes；旧工程仍可传 Eyes_Rig
            # Rigify 兼容下眼球已由 Face_Rig Child Of 接管，同样烘焙眼球
            msg = bake.bake_ctl_animation(
                face,
                eyes_legacy if eyes_legacy else face,
                arm,
                mesh,
                s.eye_l_bone,
                s.eye_r_bone,
                frame_start,
                frame_end,
                bake_eyeballs=True,
            )

            if was_hidden:
                arm.hide_set(True)

            s.last_report = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        except Exception as e:
            s.last_report = f"烘焙失败: {e}"
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}


class FACE_EYES_OT_bake_mmd(Operator):
    bl_idname = "face_eyes_ctrl.bake_mmd"
    bl_label = "烘焙面部与MMD标准骨骼"
    bl_description = "烘焙面部（形态键/左目/右目），并把 MMD 标准骨骼列表中的骨骼最终姿态烘焙为目标骨架关键帧"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.face_eyes_ctrl
        inputs = _resolve_bake_inputs(context, self)
        if inputs is None:
            return {"CANCELLED"}
        arm, mesh, face, eyes_legacy, frame_start, frame_end = inputs

        try:
            was_hidden = arm.hide_get()
            if was_hidden:
                arm.hide_set(False)

            face_msg = ""
            try:
                face_msg = bake.bake_ctl_animation(
                    face,
                    eyes_legacy if eyes_legacy else face,
                    arm,
                    mesh,
                    s.eye_l_bone,
                    s.eye_r_bone,
                    frame_start,
                    frame_end,
                    bake_eyeballs=True,
                )
            except RuntimeError as e:
                # 面部无动画/无映射时不阻断 MMD 标准骨骼烘焙
                face_msg = f"面部未烘焙: {e}"

            mmd_n = bake.bake_mmd_bone_animation(
                arm, list(MMD_BONE_NAMES), frame_start, frame_end
            )

            if was_hidden:
                arm.hide_set(True)

            if not face_msg.startswith("烘焙完成") and mmd_n == 0:
                raise RuntimeError(face_msg.removeprefix("面部未烘焙: "))

            msg = f"{face_msg}；MMD骨骼={mmd_n}"
            s.last_report = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        except Exception as e:
            s.last_report = f"烘焙失败: {e}"
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}


class FACE_EYES_OT_clean_keys(Operator):
    bl_idname = "face_eyes_ctrl.clean_keys"
    bl_label = "清理多余关键帧"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.face_eyes_ctrl
        auto_fill_settings(context)
        arm = s.target_armature
        mesh = s.target_mesh
        if not arm and not mesh:
            self.report({"ERROR"}, "请指定目标骨架或目标网格")
            return {"CANCELLED"}

        try:
            msg = clean_keys.clean_target_keyframes(arm, mesh)
            s.last_report = msg
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        except Exception as e:
            s.last_report = f"清理失败: {e}"
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}


CLASSES = (
    FACE_EYES_OT_bake,
    FACE_EYES_OT_bake_mmd,
    FACE_EYES_OT_clean_keys,
)
