"""Operator: 一键选中MMD标准骨骼（姿态模式）。"""
from __future__ import annotations

import bpy
from bpy.types import Operator

# MMD标准骨骼名称列表（按选中顺序排列）
MMD_BONE_NAMES = [
    "センター",
    "上半身",
    "上半身1",
    "上半身2",
    "上半身3",
    "首",
    "頭",
    "下半身",
    "左肩",
    "右肩",
    "左腕",
    "右腕",
    "左ひじ",
    "右ひじ",
    "左手首",
    "右手首",
    "左親指０",
    "左親指１",
    "左親指２",
    "右親指０",
    "右親指１",
    "右親指２",
    "左人指１",
    "左人指２",
    "左人指３",
    "右人指１",
    "右人指２",
    "右人指３",
    "左中指１",
    "左中指２",
    "左中指３",
    "右中指１",
    "右中指２",
    "右中指３",
    "左薬指１",
    "左薬指２",
    "左薬指３",
    "右薬指１",
    "右薬指２",
    "右薬指３",
    "左小指１",
    "左小指２",
    "左小指３",
    "右小指１",
    "右小指２",
    "右小指３",
    "左足",
    "右足",
    "左ひざ",
    "右ひざ",
    "左足首",
    "右足首",
    "左つま先",
    "右つま先",
    "左足先EX",
    "右足先EX",
    "左足ＩＫ",
    "右足ＩＫ",
    # 带 .R / .L 后缀的 MMD 标准骨骼
    "肩.R",
    "肩.L",
    "腕.R",
    "腕.L",
    "ひじ.R",
    "ひじ.L",
    "手首.R",
    "手首.L",
    "親指０.R",
    "親指０.L",
    "親指１.R",
    "親指１.L",
    "親指２.R",
    "親指２.L",
    "人指１.R",
    "人指１.L",
    "人指２.R",
    "人指２.L",
    "人指３.R",
    "人指３.L",
    "中指１.R",
    "中指１.L",
    "中指２.R",
    "中指２.L",
    "中指３.R",
    "中指３.L",
    "薬指１.R",
    "薬指１.L",
    "薬指２.R",
    "薬指２.L",
    "薬指３.R",
    "薬指３.L",
    "小指１.R",
    "小指１.L",
    "小指２.R",
    "小指２.L",
    "小指３.R",
    "小指３.L",
    "足.R",
    "足.L",
    "ひざ.R",
    "ひざ.L",
    "足首.R",
    "足首.L",
    "足先EX.R",
    "足先EX.L",
    "つま先.R",
    "つま先.L",
    "足ＩＫ.R",
    "足ＩＫ.L",
]


class CAT_TOOLBOX_OT_select_mmd_bones(Operator):
    bl_idname = "cat_toolbox.select_mmd_bones"
    bl_label = "选中MMD标准骨骼"
    bl_description = "选中MMD标准骨骼（姿态模式），不存在的骨骼自动跳过"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        armature = context.active_object

        if not armature or armature.type != "ARMATURE":
            self.report({"ERROR"}, "请先选中一个骨架物体")
            return {"CANCELLED"}

        # 切换到姿态模式
        try:
            if armature.mode != "POSE":
                with context.temp_override(
                    active_object=armature,
                    object=armature,
                ):
                    bpy.ops.object.mode_set(mode="POSE")
        except Exception as e:
            self.report({"ERROR"}, f"无法切换到姿态模式: {e}")
            return {"CANCELLED"}

        armature.data.bones.active = None

        # 先全部取消选中
        for bone in armature.data.bones:
            bone.select = False

        # 记录实际选中的骨骼
        selected_bones = []
        skipped_bones = []

        for bone_name in MMD_BONE_NAMES:
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is not None:
                pose_bone.bone.select = True
                selected_bones.append(bone_name)
            else:
                skipped_bones.append(bone_name)

        total = len(MMD_BONE_NAMES)
        selected_count = len(selected_bones)
        skipped_count = len(skipped_bones)

        msg_parts = [f"已选中 {selected_count}/{total} 个骨骼"]
        if skipped_count > 0:
            msg_parts.append(f"跳过 {skipped_count} 个（不存在）")

        msg = "，".join(msg_parts)
        self.report({"INFO"}, msg)

        # 如果有选中的骨骼，将第一个设为活动骨骼
        if selected_bones:
            armature.data.bones[selected_bones[0]].select = True
            armature.data.bones.active = armature.data.bones[selected_bones[0]]

        return {"FINISHED"}


CLASSES = (CAT_TOOLBOX_OT_select_mmd_bones,)
