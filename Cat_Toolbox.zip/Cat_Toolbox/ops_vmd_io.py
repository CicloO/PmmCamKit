"""Operator: 一键导入/导出 VMD（封装 mmd_tools）。

导入流程：选中 MMD 骨骼 → 调用 mmd_tools.import_vmd 弹出文件选择 →
待用户选完 VMD 后自动完成：视图中隐藏骨骼 → 选中 Face_Rig → 切换姿态模式。
"""
from __future__ import annotations

import bpy
from bpy.types import Operator

from .build_rig import MERGED_INTO_PROP


def _file_selector_open() -> bool:
    """任意窗口是否仍有打开的文件浏览器（FILE_BROWSER 区域）。"""
    for wm in bpy.data.window_managers:
        for window in wm.windows:
            for area in window.screen.areas:
                if area.type == "FILE_BROWSER":
                    return True
    return False


def _anim_fingerprint(armature: bpy.types.Object | None):
    """骨架动画状态的轻量指纹，用于判断 VMD 是否真的导入成功。"""
    if armature is None:
        return None
    adata = armature.animation_data
    action_name = adata.action.name if (adata and adata.action) else None
    nla = []
    if adata and adata.nla_tracks:
        for track in adata.nla_tracks:
            nla.append((track.name, tuple(s.name for s in track.strips)))
    return (action_name, tuple(nla))


def _find_face_rig() -> bpy.types.Object | None:
    """独立 Face_Rig，或已合并进 Rigify 的宿主骨架。"""
    for name in ("Face_Rig", "Eyes_Rig"):
        obj = bpy.data.objects.get(name)
        if obj:
            return obj
    for obj in bpy.data.objects:
        if obj.type == "ARMATURE" and obj.get(MERGED_INTO_PROP):
            return obj
    return None


def _operator_props(op) -> set[str]:
    """操作符支持的属性名集合（兼容不同 mmd_tools 版本）。"""
    try:
        return {p.identifier for p in op.get_rna_type().properties}
    except Exception:
        return set()


def _enter_pose_mode(context, obj: bpy.types.Object):
    """安全切换到姿态模式：先退出到物体模式，再进入 POSE。"""
    view = context.view_layer
    if context.active_object != obj:
        view.objects.active = obj
    try:
        obj.select_set(True)
    except Exception:
        pass
    override = dict(
        active_object=obj,
        object=obj,
        selected_objects=[obj],
        selected_editable_objects=[obj],
    )
    if obj.mode != "OBJECT":
        with context.temp_override(**override):
            bpy.ops.object.mode_set(mode="OBJECT")
    with context.temp_override(**override):
        bpy.ops.object.mode_set(mode="POSE")


class CAT_TOOLBOX_OT_import_vmd_flow(Operator):
    bl_idname = "cat_toolbox.import_vmd_flow"
    bl_label = "导入VMD"
    bl_description = "选中MMD骨骼后一键完成：选择VMD文件→隐藏骨骼→选中Face_Rig→姿态模式"
    bl_options = {"REGISTER"}

    _timer = None
    _closed_ticks = 0
    _saw_file = False
    _done = False
    _armature = None
    _fingerprint = None
    _frame_range = None

    def invoke(self, context, event):
        if not hasattr(bpy.ops.mmd_tools, "import_vmd"):
            self.report({"ERROR"}, "未找到 mmd_tools 的导入VMD功能，请先启用 MMD Tools 插件")
            return {"CANCELLED"}

        armature = context.active_object
        if not armature or armature.type != "ARMATURE":
            self.report({"ERROR"}, "请先选中一个 MMD 骨骼（Armature）")
            return {"CANCELLED"}

        view = context.view_layer
        view.objects.active = armature
        try:
            armature.select_set(True)
        except Exception:
            pass

        self._armature = armature
        self._fingerprint = _anim_fingerprint(armature)
        self._frame_range = (context.scene.frame_start, context.scene.frame_end)

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.2, window=context.window)
        wm.modal_handler_add(self)

        s = context.scene.cat_vmd_io
        op = bpy.ops.mmd_tools.import_vmd
        supported = _operator_props(op)
        kwargs = {}
        for key in ("scale", "use_pose_mode", "use_mirror", "update_scene_settings"):
            if key in supported:
                kwargs[key] = getattr(s, key)
        if "use_NLA" in supported:
            kwargs["use_NLA"] = s.use_NLA
        elif "use_nla" in supported:
            kwargs["use_nla"] = s.use_NLA
        with context.temp_override(
            active_object=armature,
            object=armature,
            selected_objects=[armature],
            selected_editable_objects=[armature],
        ):
            result = op("INVOKE_DEFAULT", **kwargs)
        if result != {"RUNNING_MODAL"}:
            wm.event_timer_remove(self._timer)
            self._timer = None
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type == "TIMER":
            if self._done:
                return {"FINISHED"}

            file_open = _file_selector_open()
            if file_open:
                self._saw_file = True
                self._closed_ticks = 0
                return {"PASS_THROUGH"}

            # 文件浏览器已关闭：确认 VMD 是否真正导入
            imported = False
            if _anim_fingerprint(self._armature) != self._fingerprint:
                imported = True
            elif (context.scene.frame_start, context.scene.frame_end) != self._frame_range:
                imported = True

            if imported:
                self._done = True
                self._cleanup(context)
                self._finish(context)
                return {"FINISHED"}

            if self._saw_file:
                # 曾打开过文件浏览器，现在关闭且无变化 → 视为取消
                self._closed_ticks += 1
                if self._closed_ticks >= 3:
                    self._done = True
                    self._cleanup(context)
                    self.report({"INFO"}, "已取消 VMD 导入")
                    return {"FINISHED"}
            return {"PASS_THROUGH"}

        if event.type in {"ESC", "RIGHTMOUSE"} and not _file_selector_open():
            self._done = True
            self._cleanup(context)
            self.report({"INFO"}, "已取消 VMD 导入")
            return {"CANCELLED"}

        return {"PASS_THROUGH"}

    def _finish(self, context):
        s = context.scene.cat_vmd_io
        armature = self._armature

        # 1. 视图中暂时隐藏骨骼
        armature.hide_set(True)
        s.hidden_armature_name = armature.name

        # 2. 选中 Face_Rig
        face_rig = _find_face_rig()
        if face_rig is None:
            s.last_report = f"VMD已导入 {armature.name}，骨骼已隐藏，但未找到 Face_Rig"
            self.report({"WARNING"}, "VMD 已导入，骨骼已隐藏，但场景中未找到 Face_Rig")
            return
        if face_rig.hide_get():
            face_rig.hide_set(False)
        view = context.view_layer
        view.objects.active = face_rig
        try:
            face_rig.select_set(True)
        except Exception:
            pass

        # 3. 切换到姿态模式
        try:
            _enter_pose_mode(context, face_rig)
        except Exception as e:
            s.last_report = f"VMD已导入，已选中 {face_rig.name}，但切换姿态模式失败: {e}"
            self.report({"WARNING"}, f"VMD 已导入，已选中 {face_rig.name}，但切换姿态模式失败: {e}")
            return

        s.last_report = f"VMD已导入 {armature.name}，骨骼已隐藏，{face_rig.name} 已进入姿态模式"
        self.report({"INFO"}, f"VMD 导入完成：{armature.name} 已隐藏，{face_rig.name} 已进入姿态模式")

    def _cleanup(self, context):
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None

    def cancel(self, context):
        self._cleanup(context)


class CAT_TOOLBOX_OT_export_vmd(Operator):
    bl_idname = "cat_toolbox.export_vmd"
    bl_label = "导出VMD"
    bl_description = "将选中对象（MMD骨架/模型根物体/带表情的网格/MMD相机/灯光）的动画导出为 VMD 文件（mmd_tools）"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if not hasattr(bpy.ops.mmd_tools, "export_vmd"):
            self.report({"ERROR"}, "未找到 mmd_tools 的导出VMD功能，请先启用 MMD Tools 插件")
            return {"CANCELLED"}

        obj = context.active_object
        if not obj:
            self.report({"ERROR"}, "请先选中一个对象")
            return {"CANCELLED"}

        op = bpy.ops.mmd_tools.export_vmd
        override = dict(
            active_object=obj,
            object=obj,
            selected_objects=[obj],
            selected_editable_objects=[obj],
        )
        with context.temp_override(**override):
            if not op.poll():
                self.report(
                    {"ERROR"},
                    f"{obj.name} 不支持导出 VMD（请选中 MMD骨架 / 模型根物体 / 带表情的网格 / MMD相机 / 灯光）",
                )
                return {"CANCELLED"}

            s = context.scene.cat_vmd_io
            supported = _operator_props(op)
            kwargs = {}
            if "scale" in supported:
                kwargs["scale"] = s.export_scale
            if "use_pose_mode" in supported:
                kwargs["use_pose_mode"] = s.use_pose_mode
            if "use_frame_range" in supported:
                kwargs["use_frame_range"] = s.use_frame_range
            result = op("INVOKE_DEFAULT", **kwargs)

        if result != {"RUNNING_MODAL"}:
            return {"CANCELLED"}
        s.last_report = f"导出VMD：{obj.name}"
        self.report({"INFO"}, f"正在导出 {obj.name} 的动画为 VMD")
        return {"FINISHED"}


class CAT_TOOLBOX_OT_show_vmd_armature(Operator):
    bl_idname = "cat_toolbox.show_vmd_armature"
    bl_label = "恢复骨骼显示"
    bl_description = "恢复一键导入流程中隐藏的 MMD 骨骼"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.cat_vmd_io
        name = s.hidden_armature_name
        if not name:
            self.report({"INFO"}, "当前没有因导入 VMD 而隐藏的骨骼")
            return {"CANCELLED"}
        obj = bpy.data.objects.get(name)
        if obj is None:
            s.hidden_armature_name = ""
            self.report({"WARNING"}, f"找不到骨骼 {name}，已清空记录")
            return {"CANCELLED"}
        obj.hide_set(False)
        view = context.view_layer
        view.objects.active = obj
        try:
            obj.select_set(True)
        except Exception:
            pass
        s.hidden_armature_name = ""
        s.last_report = f"已恢复显示骨骼 {name}"
        self.report({"INFO"}, f"已恢复显示骨骼 {name}")
        return {"FINISHED"}


CLASSES = (
    CAT_TOOLBOX_OT_import_vmd_flow,
    CAT_TOOLBOX_OT_export_vmd,
    CAT_TOOLBOX_OT_show_vmd_armature,
)
