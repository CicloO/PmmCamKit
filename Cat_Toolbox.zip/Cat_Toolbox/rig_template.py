"""Static Face_Rig / Eyes_Rig template — full parameters from 面部绑定_范例.blend."""

RIG_META = {
  "Face_Rig": {
    "object": {
      "show_in_front": True,
      "display_type": "TEXTURED"
    },
    "armature": {
      "display_type": "OCTAHEDRAL",
      "show_names": False,
      "show_axes": False,
      "bone_collections": [
        {
          "name": "CTL",
          "is_visible": True
        },
        {
          "name": "MCH",
          "is_visible": False
        },
        {
          "name": "ROOT",
          "is_visible": False
        }
      ]
    }
  },
  "Eyes_Rig": {
    "object": {
      "show_in_front": True,
      "display_type": "TEXTURED"
    },
    "armature": {
      "display_type": "OCTAHEDRAL",
      "show_names": False,
      "show_axes": False,
      "bone_collections": [
        {
          "name": "CTL",
          "is_visible": True
        },
        {
          "name": "MCH",
          "is_visible": False
        }
      ]
    },
    "drivers": [
      {
        "data_path": "pose.bones[\"MCH-eye_L\"].rotation_euler",
        "array_index": 2,
        "expression": "-eye_look*50",
        "variables": [
          {
            "name": "eye_look",
            "type": "TRANSFORMS",
            "id": "Face_Rig",
            "bone_target": "CTL-eye-Look",
            "transform_type": "LOC_X",
            "transform_space": "LOCAL_SPACE"
          }
        ]
      },
      {
        "data_path": "pose.bones[\"MCH-eye_R\"].rotation_euler",
        "array_index": 2,
        "expression": "eye_look*50",
        "variables": [
          {
            "name": "eye_look",
            "type": "TRANSFORMS",
            "id": "Face_Rig",
            "bone_target": "CTL-eye-Look",
            "transform_type": "LOC_X",
            "transform_space": "LOCAL_SPACE"
          }
        ]
      },
      {
        "data_path": "pose.bones[\"MCH-eye_L\"].rotation_euler",
        "array_index": 0,
        "expression": "eye_look*50",
        "variables": [
          {
            "name": "eye_look",
            "type": "TRANSFORMS",
            "id": "Face_Rig",
            "bone_target": "CTL-eye-Look",
            "transform_type": "LOC_Z",
            "transform_space": "LOCAL_SPACE"
          }
        ]
      },
      {
        "data_path": "pose.bones[\"MCH-eye_R\"].rotation_euler",
        "array_index": 0,
        "expression": "-eye_look*50",
        "variables": [
          {
            "name": "eye_look",
            "type": "TRANSFORMS",
            "id": "Face_Rig",
            "bone_target": "CTL-eye-Look",
            "transform_type": "LOC_Z",
            "transform_space": "LOCAL_SPACE"
          }
        ]
      }
    ]
  }
}

FACE_RIG_BONES = [
  {
    "name": "MCH-face_root",
    "parent": None,
    "head": [
      0.0,
      -0.000432,
      1.4028
    ],
    "tail": [
      0.0,
      -0.000432,
      1.4828
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "MCH",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": None,
    "constraints": []
  },
  {
    "name": "ROOT-eye_middle",
    "parent": "MCH-face_root",
    "head": [
      0.0,
      -0.086875,
      1.457333
    ],
    "tail": [
      0.0,
      -0.096875,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "ROOT",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "WGT-Face_Rig_LMT-eye_look.001",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        1.570796,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 2.0,
      "transform_from": None,
      "widget": "frame"
    },
    "constraints": []
  },
  {
    "name": "LMT-brow_raise",
    "parent": "ROOT-eye_middle",
    "head": [
      0.0,
      -0.086875,
      1.5
    ],
    "tail": [
      0.0,
      -0.096875,
      1.5
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-brow_raise",
    "parent": "LMT-brow_raise",
    "head": [
      0.0,
      -0.086875,
      1.5
    ],
    "tail": [
      0.0,
      -0.089375,
      1.5
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-brow_1",
    "parent": "ROOT-eye_middle",
    "head": [
      -0.01,
      -0.086875,
      1.5
    ],
    "tail": [
      -0.01,
      -0.096875,
      1.5
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-brow_1",
    "parent": "LMT-brow_1",
    "head": [
      -0.01,
      -0.086875,
      1.5
    ],
    "tail": [
      -0.01,
      -0.089375,
      1.5
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-brow_2",
    "parent": "ROOT-eye_middle",
    "head": [
      0.01,
      -0.086875,
      1.5
    ],
    "tail": [
      0.01,
      -0.096875,
      1.5
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-brow_2",
    "parent": "LMT-brow_2",
    "head": [
      0.01,
      -0.086875,
      1.5
    ],
    "tail": [
      0.01,
      -0.089375,
      1.5
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-eye_happy",
    "parent": "ROOT-eye_middle",
    "head": [
      -0.015,
      -0.086875,
      1.457333
    ],
    "tail": [
      -0.015,
      -0.096875,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_happy",
    "parent": "LMT-eye_happy",
    "head": [
      -0.015,
      -0.086875,
      1.457333
    ],
    "tail": [
      -0.015,
      -0.089375,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-eye_blink",
    "parent": "ROOT-eye_middle",
    "head": [
      0.015,
      -0.086875,
      1.457333
    ],
    "tail": [
      0.015,
      -0.096875,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_blink",
    "parent": "LMT-eye_blink",
    "head": [
      0.015,
      -0.086875,
      1.457333
    ],
    "tail": [
      0.015,
      -0.089375,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-eye_small",
    "parent": "ROOT-eye_middle",
    "head": [
      0.0,
      -0.086875,
      1.471
    ],
    "tail": [
      0.0,
      -0.096875,
      1.471
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        1.570796,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_small",
    "parent": "LMT-eye_small",
    "head": [
      0.0,
      -0.086875,
      1.471
    ],
    "tail": [
      0.0,
      -0.089375,
      1.471
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      True,
      True
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-eye_look",
    "parent": "ROOT-eye_middle",
    "head": [
      0.0,
      -0.086875,
      1.457333
    ],
    "tail": [
      0.0,
      -0.096875,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "田字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "den"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye-Look",
    "parent": "LMT-eye_look",
    "head": [
      0.0,
      -0.086875,
      1.457333
    ],
    "tail": [
      0.0,
      -0.089375,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "ROOT-mouth",
    "parent": "MCH-face_root",
    "head": [
      -0.0,
      -0.086875,
      1.391826
    ],
    "tail": [
      0.0,
      -0.096875,
      1.391826
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "ROOT",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "WGT-Face_Rig_LMT-eye_look.001",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        1.570796,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "frame"
    },
    "constraints": []
  },
  {
    "name": "LMT-mouth_corner",
    "parent": "ROOT-mouth",
    "head": [
      -0.0,
      -0.086875,
      1.391826
    ],
    "tail": [
      0.0,
      -0.096875,
      1.391826
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "田字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "den"
    },
    "constraints": []
  },
  {
    "name": "CTL-mouth_corner",
    "parent": "LMT-mouth_corner",
    "head": [
      -0.0,
      -0.086875,
      1.391826
    ],
    "tail": [
      0.0,
      -0.089375,
      1.391826
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-mouth_U",
    "parent": "ROOT-mouth",
    "head": [
      0.0,
      -0.086875,
      1.365
    ],
    "tail": [
      0.0,
      -0.096875,
      1.365
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "口字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "kou"
    },
    "constraints": []
  },
  {
    "name": "CTL-mouth_U",
    "parent": "LMT-mouth_U",
    "head": [
      0.0,
      -0.086875,
      1.375
    ],
    "tail": [
      0.0,
      -0.089375,
      1.375
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.02,
        "max_z": 0.0
      }
    ]
  },
  {
    "name": "LMT-mouth_I",
    "parent": "ROOT-mouth",
    "head": [
      -0.006,
      -0.086875,
      1.365
    ],
    "tail": [
      -0.006,
      -0.096875,
      1.365
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "口字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "kou"
    },
    "constraints": []
  },
  {
    "name": "CTL-mouth_I",
    "parent": "LMT-mouth_I",
    "head": [
      -0.006,
      -0.086875,
      1.375
    ],
    "tail": [
      -0.006,
      -0.089375,
      1.375
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.02,
        "max_z": 0.0
      }
    ]
  },
  {
    "name": "LMT-mouth_A",
    "parent": "ROOT-mouth",
    "head": [
      -0.012,
      -0.086875,
      1.365
    ],
    "tail": [
      -0.012,
      -0.096875,
      1.365
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "口字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "kou"
    },
    "constraints": []
  },
  {
    "name": "CTL-mouth_A",
    "parent": "LMT-mouth_A",
    "head": [
      -0.012,
      -0.086875,
      1.375
    ],
    "tail": [
      -0.012,
      -0.089375,
      1.375
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.02,
        "max_z": 0.0
      }
    ]
  },
  {
    "name": "LMT-mouth_E",
    "parent": "ROOT-mouth",
    "head": [
      0.006,
      -0.086875,
      1.365
    ],
    "tail": [
      0.006,
      -0.096875,
      1.365
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "口字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "kou"
    },
    "constraints": []
  },
  {
    "name": "CTL-mouth_E",
    "parent": "LMT-mouth_E",
    "head": [
      0.006,
      -0.086875,
      1.375
    ],
    "tail": [
      0.006,
      -0.089375,
      1.375
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.02,
        "max_z": 0.0
      }
    ]
  },
  {
    "name": "LMT-mouth_O",
    "parent": "ROOT-mouth",
    "head": [
      0.012,
      -0.086875,
      1.365
    ],
    "tail": [
      0.012,
      -0.096875,
      1.365
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "口字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "kou"
    },
    "constraints": []
  },
  {
    "name": "CTL-mouth_O",
    "parent": "LMT-mouth_O",
    "head": [
      0.012,
      -0.086875,
      1.375
    ],
    "tail": [
      0.012,
      -0.089375,
      1.375
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.02,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.02,
        "max_z": 0.0
      }
    ]
  },
  {
    "name": "ROOT-eye_L",
    "parent": "MCH-face_root",
    "head": [
      0.06,
      -0.086875,
      1.457333
    ],
    "tail": [
      0.06,
      -0.096875,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "ROOT",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "WGT-Face_Rig_LMT-eye_look.001",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        1.570796,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "frame"
    },
    "constraints": []
  },
  {
    "name": "LMT-eye_halflid",
    "parent": "ROOT-eye_L",
    "head": [
      0.04,
      -0.086875,
      1.471
    ],
    "tail": [
      0.04,
      -0.096875,
      1.471
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "口字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        1.570796,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "kou"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_halflid",
    "parent": "LMT-eye_halflid",
    "head": [
      0.03,
      -0.086875,
      1.471
    ],
    "tail": [
      0.03,
      -0.089375,
      1.471
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      True,
      True
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.02,
        "max_x": 0.0,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-eye_wink1_L",
    "parent": "ROOT-eye_L",
    "head": [
      0.06,
      -0.086875,
      1.457333
    ],
    "tail": [
      0.06,
      -0.096875,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_wink1_L",
    "parent": "LMT-eye_wink1_L",
    "head": [
      0.06,
      -0.086875,
      1.457333
    ],
    "tail": [
      0.06,
      -0.089375,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-eye_wink2_L",
    "parent": "ROOT-eye_L",
    "head": [
      0.066,
      -0.086875,
      1.457333
    ],
    "tail": [
      0.066,
      -0.096875,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_wink2_L",
    "parent": "LMT-eye_wink2_L",
    "head": [
      0.066,
      -0.086875,
      1.457333
    ],
    "tail": [
      0.066,
      -0.089375,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "ROOT-eye_R",
    "parent": "MCH-face_root",
    "head": [
      -0.06,
      -0.086875,
      1.457333
    ],
    "tail": [
      -0.06,
      -0.096875,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "ROOT",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "WGT-Face_Rig_LMT-eye_look.001",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        1.570796,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "frame"
    },
    "constraints": []
  },
  {
    "name": "LMT-eye_expr",
    "parent": "ROOT-eye_R",
    "head": [
      -0.04,
      -0.086875,
      1.471
    ],
    "tail": [
      -0.04,
      -0.096875,
      1.471
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        1.570796,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_expr",
    "parent": "LMT-eye_expr",
    "head": [
      -0.04,
      -0.086875,
      1.471
    ],
    "tail": [
      -0.04,
      -0.089375,
      1.471
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      True,
      True
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-eye_wink1_R",
    "parent": "ROOT-eye_R",
    "head": [
      -0.06,
      -0.086875,
      1.457333
    ],
    "tail": [
      -0.06,
      -0.096875,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_wink1_R",
    "parent": "LMT-eye_wink1_R",
    "head": [
      -0.06,
      -0.086875,
      1.457333
    ],
    "tail": [
      -0.06,
      -0.089375,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  },
  {
    "name": "LMT-eye_wink2_R",
    "parent": "ROOT-eye_R",
    "head": [
      -0.066,
      -0.086875,
      1.457333
    ],
    "tail": [
      -0.066,
      -0.096875,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "日字格",
      "scale": [
        1.0,
        1.0,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "nichi"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_wink2_R",
    "parent": "LMT-eye_wink2_R",
    "head": [
      -0.066,
      -0.086875,
      1.457333
    ],
    "tail": [
      -0.066,
      -0.089375,
      1.457333
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      True,
      True,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "圆环",
      "scale": [
        0.8,
        1.0,
        0.8
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        0.0,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "ring"
    },
    "constraints": [
      {
        "name": "限定位置",
        "type": "LIMIT_LOCATION",
        "mute": False,
        "influence": 1.0,
        "owner_space": "LOCAL",
        "use_transform_limit": True,
        "use_min_x": True,
        "use_max_x": True,
        "use_min_y": False,
        "use_max_y": False,
        "use_min_z": True,
        "use_max_z": True,
        "min_x": -0.01,
        "max_x": 0.01,
        "min_y": 0.0,
        "max_y": 0.0,
        "min_z": -0.01,
        "max_z": 0.01
      }
    ]
  }
]

EYES_RIG_BONES = [
  {
    "name": "MCH-eyes_root",
    "parent": None,
    "head": [
      0.0,
      -0.000432,
      1.4028
    ],
    "tail": [
      0.0,
      -0.000432,
      1.4828
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "MCH",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": None,
    "constraints": [
      {
        "name": "复制变换",
        "type": "COPY_TRANSFORMS",
        "mute": False,
        "influence": 1.0,
        "target": "女主（如诩绑定）_arm",
        "subtarget": "頭",
        "mix_mode": "REPLACE",
        "head_tail": 0.0,
        "target_space": "WORLD",
        "owner_space": "WORLD"
      }
    ]
  },
  {
    "name": "MCH-eye_L",
    "parent": "MCH-eyes_root",
    "head": [
      0.024552,
      -0.022107,
      1.4556
    ],
    "tail": [
      0.024552,
      -0.061219,
      1.4556
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "MCH",
    "rotation_mode": "ZXY",
    "lock_location": [
      True,
      True,
      True
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": None,
    "constraints": [
      {
        "name": "阻尼追踪",
        "type": "DAMPED_TRACK",
        "mute": False,
        "influence": 0.5,
        "target": "Eyes_Rig",
        "subtarget": "CTL-eye_L",
        "track_axis": "TRACK_Y",
        "head_tail": 0.0
      }
    ]
  },
  {
    "name": "MCH-eye_R",
    "parent": "MCH-eyes_root",
    "head": [
      -0.024552,
      -0.022107,
      1.455447
    ],
    "tail": [
      -0.024552,
      -0.06122,
      1.4556
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "MCH",
    "rotation_mode": "ZXY",
    "lock_location": [
      True,
      True,
      True
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": None,
    "constraints": [
      {
        "name": "阻尼追踪",
        "type": "DAMPED_TRACK",
        "mute": False,
        "influence": 0.5,
        "target": "Eyes_Rig",
        "subtarget": "CTL-eye_R",
        "track_axis": "TRACK_Y",
        "head_tail": 0.0
      }
    ]
  },
  {
    "name": "CTL-eyes",
    "parent": "MCH-eyes_root",
    "head": [
      0.0,
      -0.122107,
      1.4556
    ],
    "tail": [
      0.0,
      -0.161219,
      1.4556
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "WGT-rig_eyes",
      "scale": [
        0.4,
        0.4,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        1.570796,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "eyes_master"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_L",
    "parent": "CTL-eyes",
    "head": [
      0.024552,
      -0.122107,
      1.4556
    ],
    "tail": [
      0.024552,
      -0.161219,
      1.4556
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "WGT-rig_eye.L",
      "scale": [
        0.5,
        0.5,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        1.570796,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "eye_l"
    },
    "constraints": []
  },
  {
    "name": "CTL-eye_R",
    "parent": "CTL-eyes",
    "head": [
      -0.024552,
      -0.122107,
      1.455447
    ],
    "tail": [
      -0.024552,
      -0.161219,
      1.4556
    ],
    "use_connect": False,
    "use_deform": True,
    "hide": False,
    "bone_collection": "CTL",
    "rotation_mode": "QUATERNION",
    "lock_location": [
      False,
      False,
      False
    ],
    "lock_rotation": [
      False,
      False,
      False
    ],
    "lock_scale": [
      False,
      False,
      False
    ],
    "custom_shape": {
      "object": "WGT-rig_eye.R",
      "scale": [
        0.5,
        0.5,
        1.0
      ],
      "translation": [
        0.0,
        0.0,
        0.0
      ],
      "rotation_euler": [
        1.570796,
        0.0,
        0.0
      ],
      "use_bone_size": True,
      "wire_width": 1.0,
      "transform_from": None,
      "widget": "eye_r"
    },
    "constraints": []
  }
]
