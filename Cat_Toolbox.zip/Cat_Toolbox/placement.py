"""Find / place target MMD objects and placeholder for strategy B."""

from __future__ import annotations

import importlib
import sys

import bmesh
import bpy
from mathutils import Vector

from .mapping import DEFAULT_WIDGET_NAMES, HEAD_BONE_CANDIDATES


def find_bone(arm: bpy.types.Object, candidates: tuple[str, ...]) -> str | None:
    names = {b.name for b in arm.data.bones}
    for c in candidates:
        if c in names:
            return c
    lower = {b.name.lower(): b.name for b in arm.data.bones}
    for c in candidates:
        if c.lower() in lower:
            return lower[c.lower()]
    return None


def _is_ctrl_rig(o: bpy.types.Object) -> bool:
    return o.name.startswith("Face_Rig") or o.name.startswith("Eyes_Rig")


def _is_target_armature_candidate(o: bpy.types.Object) -> bool:
    """MMD 目标骨架（排除 Face_Rig / Rigify 控制骨架）。"""
    if o.type != "ARMATURE" or _is_ctrl_rig(o):
        return False
    from .rigify_compat import looks_like_rigify_control_rig

    if looks_like_rigify_control_rig(o):
        return False
    return find_bone(o, HEAD_BONE_CANDIDATES) is not None


def _armature_mmd_score(arm: bpy.types.Object) -> int:
    """Prefer armatures that still have classic MMD 頭/目 names."""
    score = 0
    names = {b.name for b in arm.data.bones}
    if "頭" in names or "头" in names:
        score += 10
    if "目.L" in names or "目.R" in names:
        score += 5
    return score


def guess_mmd_objects(context) -> dict:
    """Guess target armature / mesh / root from selection or scene."""
    result = {"armature": None, "mesh": None, "root": None}
    selected = list(context.selected_objects)

    for obj in selected:
        if _is_target_armature_candidate(obj) and result["armature"] is None:
            result["armature"] = obj
        if obj.type == "MESH" and not obj.name.startswith(".") and result["mesh"] is None:
            if obj.data.shape_keys and obj.name not in DEFAULT_WIDGET_NAMES:
                if not obj.name.startswith("WGT"):
                    result["mesh"] = obj

    for obj in selected:
        if "mmd_root" in obj.keys():
            result["root"] = obj
            break

    root = result["root"]
    if root:
        for child in root.children_recursive:
            if _is_target_armature_candidate(child) and result["armature"] is None:
                result["armature"] = child
            if (
                child.type == "MESH"
                and child.data.shape_keys
                and result["mesh"] is None
                and not child.name.startswith(".")
                and not child.name.startswith("WGT")
            ):
                result["mesh"] = child

    if result["armature"] is None:
        candidates = [o for o in bpy.data.objects if _is_target_armature_candidate(o)]
        if candidates:
            candidates.sort(key=_armature_mmd_score, reverse=True)
            result["armature"] = candidates[0]

    if result["mesh"] is None and result["armature"]:
        arm = result["armature"]
        for obj in bpy.data.objects:
            if obj.type != "MESH" or not obj.data.shape_keys:
                continue
            if obj.name.startswith(".") or obj.name.startswith("WGT"):
                continue
            if obj.parent == arm or (arm.parent and obj.parent == arm.parent):
                result["mesh"] = obj
                break

    return result


def _mmd_tools_model_cls():
    """动态获取 mmd_tools 的 Model 类。

    Blender 4.5 中 mmd_tools 以 extension 方式加载，模块名是
    ``bl_ext.blender_org.mmd_tools.core.model`` 而非 ``mmd_tools.core.model``，
    因此不能直接 ``import mmd_tools``。这里扫描 sys.modules / 用 importlib
    兜底，兼容 3.6 的 scripts/addons 布局与 4.x 的 extension 布局。
    """
    try:
        from mmd_tools.core.model import Model

        return Model
    except Exception:
        pass

    for mod_name in list(sys.modules):
        if mod_name.endswith(".mmd_tools.core.model"):
            try:
                return importlib.import_module(mod_name).Model
            except Exception:
                continue
    return None


def _create_placeholder_with_mmd_tools(parent: bpy.types.Object | None) -> bpy.types.Object | None:
    """用 mmd_tools 的生成逻辑创建/获取 .placeholder。

    只有 MMD root 才能走 mmd_tools 的 _MorphSlider.placeholder()（内部要求
    root.mmd_type == "ROOT"）；非 MMD 骨架返回 None 以便调用方降级。
    """
    if parent is None or getattr(parent, "mmd_type", None) != "ROOT":
        return None
    try:
        Model = _mmd_tools_model_cls()
        if Model is None:
            return None
        model = Model(parent)
        ph = model.morph_slider.placeholder(create=True)
        return ph
    except Exception:
        return None


def create_placeholder_for_target(
    mesh_obj: bpy.types.Object,
    suffix: str,
    parent: bpy.types.Object | None,
) -> bpy.types.Object:
    """Create empty mesh placeholder for strategy B morph hub.

    优先使用 mmd_tools 的 _MorphSlider.placeholder() 生成（与 MMD Tools 共用同一个
    .placeholder，mmd_type 置为 PLACEHOLDER）；mmd_tools 不可用或非 MMD root 时
    降级为本插件原有逻辑（bmesh grid）。
    """
    name = f".placeholder{suffix}"
    if name in bpy.data.objects:
        ph = bpy.data.objects[name]
    else:
        ph = _create_placeholder_with_mmd_tools(parent)
        if ph is None:
            mesh_data = bpy.data.meshes.new(f".placeholder_mesh{suffix}")
            ph = bpy.data.objects.new(name, mesh_data)
            bpy.context.scene.collection.objects.link(ph)
            bm = bmesh.new()
            bmesh.ops.create_grid(bm, size=0.001, x_segments=1, y_segments=1)
            bm.to_mesh(mesh_data)
            bm.free()
        if ph.name != name:
            ph.name = name

    ph.hide_set(True)
    ph.hide_render = True
    ph.hide_viewport = True
    if parent:
        ph.parent = parent
    ph["face_eyes_ctrl_target_mesh"] = mesh_obj.name
    return ph


def align_face_rig_root_to_head(
    face_rig: bpy.types.Object,
    target_arm: bpy.types.Object,
    head_bone: str,
):
    """兼容旧接口：改为编辑模式对齐 MCH-face_root（见 align_face_rig_to_target）。"""
    align_face_rig_to_target(face_rig, target_arm, head_bone)


def _translate_edit_bones_safe(ebones, delta: Vector):
    """整体平移编辑骨，避免 use_connect 子级 head 被平移两次。"""
    if delta.length <= 1e-12:
        return
    for eb in ebones:
        if eb.use_connect and eb.parent:
            # head 已随父级 tail 移动，只补 tail
            eb.tail += delta
        else:
            eb.head += delta
            eb.tail += delta


def _iter_edit_bone_subtree(root_eb):
    """Yield root edit bone and all descendants (depth-first)."""
    stack = [root_eb]
    while stack:
        eb = stack.pop()
        yield eb
        stack.extend(list(eb.children))


def _translate_named_edit_bones_safe(ebones, names: set[str], delta: Vector):
    """平移指定编辑骨集合，避免 use_connect 子级 head 被平移两次。"""
    if delta.length <= 1e-12:
        return
    for name in names:
        eb = ebones.get(name)
        if not eb:
            continue
        if eb.use_connect and eb.parent and eb.parent.name in names:
            eb.tail += delta
        else:
            eb.head += delta
            eb.tail += delta


def align_face_root_only_to_head(
    face_rig: bpy.types.Object,
    target_arm: bpy.types.Object,
    head_bone: str,
):
    """Rigify 注入：MCH-face_root 对齐到頭，并同平移其下全部面部骨。

    只动 Face 子树（root + 后代），不动宿主手臂/腿，也不动 Eyes 骨。
    若只移 root，表情 CTL 相对 root 会错位（与范例不一致）。
    """
    head_b = target_arm.data.bones.get(head_bone)
    if not head_b:
        raise RuntimeError(f"align_face_root_only_to_head: missing head bone {head_bone}")
    if "MCH-face_root" not in face_rig.data.bones:
        raise RuntimeError("Face_Rig missing bone MCH-face_root")

    new_h, new_t = _bone_head_tail_in_rig_space(target_arm, head_b, face_rig)
    view = bpy.context.view_layer
    prev_active = view.objects.active
    _mode_set_armature(face_rig, "EDIT")
    ebones = face_rig.data.edit_bones
    root = ebones["MCH-face_root"]
    delta = new_h - root.head.copy()
    face_names = {eb.name for eb in _iter_edit_bone_subtree(root)}
    _translate_named_edit_bones_safe(ebones, face_names, delta)
    _set_edit_bone(root, new_h, new_t)
    _mode_set_armature(face_rig, "OBJECT")
    if prev_active and prev_active.name in bpy.data.objects:
        view.objects.active = prev_active


def align_face_rig_to_target(
    face_rig: bpy.types.Object,
    target_arm: bpy.types.Object,
    head_bone: str,
):
    """按范例-2：编辑模式将 MCH-face_root 头尾 XYZ 对齐到目標 頭，并整体平移其余面部骨。

    仅用于独立 Face_Rig。Rigify 注入请用 align_face_root_only_to_head，
    否则会把宿主全身骨骼一起平移并搞坏手臂/腿的 rest。
    """
    head_b = target_arm.data.bones.get(head_bone)
    if not head_b:
        raise RuntimeError(f"align_face_rig_to_target: missing head bone {head_bone}")
    if "MCH-face_root" not in face_rig.data.bones:
        raise RuntimeError("Face_Rig missing bone MCH-face_root")

    new_h, new_t = _bone_head_tail_in_rig_space(target_arm, head_b, face_rig)

    view = bpy.context.view_layer
    prev_active = view.objects.active
    _mode_set_armature(face_rig, "EDIT")
    ebones = face_rig.data.edit_bones
    root = ebones["MCH-face_root"]
    delta = new_h - root.head.copy()
    _translate_edit_bones_safe(ebones, delta)
    _set_edit_bone(root, new_h, new_t)
    _mode_set_armature(face_rig, "OBJECT")
    if prev_active and prev_active.name in bpy.data.objects:
        view.objects.active = prev_active

# 范例：控制器在眼前方沿 −Y 前移 0.1（保持 CTL 正朝前，外形不歪）
_CTRL_FORWARD_OFFSET = 0.1
# 范例 CTRL 骨长（纯 −Y 放置时使用）
_REF_CTRL_BONE_LEN = 0.039112


def _bone_head_tail_in_rig_space(
    src_arm: bpy.types.Object,
    src_bone: bpy.types.Bone,
    dst_rig: bpy.types.Object,
) -> tuple[Vector, Vector]:
    """Convert a source bone's head/tail into destination armature local space."""
    inv = dst_rig.matrix_world.inverted()
    head = inv @ (src_arm.matrix_world @ src_bone.head_local)
    tail = inv @ (src_arm.matrix_world @ src_bone.tail_local)
    return head, tail


def _set_edit_bone(eb: bpy.types.EditBone, head: Vector, tail: Vector):
    eb.head = head
    if (tail - head).length < 1e-8:
        tail = head + Vector((0.0, -0.01, 0.0))
    eb.tail = tail


def _align_mch_eye_from_mmd(
    eb: bpy.types.EditBone,
    head: Vector,
    src_tail: Vector,
    align_z: Vector,
):
    """目 → MCH-eye_*：完全复制目骨 head/tail（方向与目骨一致），只设定镜像 roll。

    旧逻辑强制纯 −Y，与 MMD 目骨实际轴向不一致，会导致目骨 Damped Track
    在静止时被拉偏。roll：L→+Z，R→−Z，供 Look 驱动异号表达式同步转眼。
    """
    _set_edit_bone(eb, Vector(head), Vector(src_tail))
    eb.align_roll(align_z)


def _place_ctrl_pure_y(
    eb: bpy.types.EditBone,
    hx: float,
    hy: float,
    hz: float,
    length: float = _REF_CTRL_BONE_LEN,
):
    """CTRL 沿纯 −Y 放置（外形正对前方，不随目骨斜轴倾斜）。"""
    use_len = length if length > 1e-8 else _REF_CTRL_BONE_LEN
    head = Vector((hx, hy, hz))
    tail = Vector((hx, hy - use_len, hz))
    _set_edit_bone(eb, head, tail)


# 范例 Eyes_Rig：两眼 head 间距、各 CTRL 基础 custom_shape_scale
# （主控 0.4；左右单眼 0.5 — 与 面部绑定_范例.blend 一致）
_REF_EYE_SPACING = 0.049104  # |0.024552 - (-0.024552)|
_EYES_CTL_BASE_SCALES = {
    "CTL-eyes": (0.4, 0.4, 1.0),
    "CTL-eye_L": (0.5, 0.5, 1.0),
    "CTL-eye_R": (0.5, 0.5, 1.0),
}


def adapt_eyes_ctrl_custom_shapes(eyes_rig: bpy.types.Object):
    """按目标两眼间距相对范例比例，缩放 CTL-eyes / CTL-eye_L / CTL-eye_R 自定义形状。

    use_bone_size=True 时显示 ∝ 骨长×scale；对齐后骨长已变，需用
    (spacing/ref_spacing)×(ref_len/bone_len) 补偿，使观感随眼距适配。
    """
    ml = eyes_rig.data.bones.get("MCH-eye_L")
    mr = eyes_rig.data.bones.get("MCH-eye_R")
    if not ml or not mr:
        return
    spacing = (Vector(ml.head_local) - Vector(mr.head_local)).length
    if spacing < 1e-8:
        return

    for name, base in _EYES_CTL_BASE_SCALES.items():
        pb = eyes_rig.pose.bones.get(name)
        bone = eyes_rig.data.bones.get(name)
        if not pb or not bone or not hasattr(pb, "custom_shape_scale_xyz"):
            continue
        bone_len = float(bone.length)
        if bone_len < 1e-8:
            continue
        factor = (spacing / _REF_EYE_SPACING) * (_REF_CTRL_BONE_LEN / bone_len)
        factor = max(0.15, min(factor, 8.0))
        pb.custom_shape_scale_xyz = (
            base[0] * factor,
            base[1] * factor,
            base[2] * factor,
        )


def _mode_set_armature(arm: bpy.types.Object, mode: str):
    view = bpy.context.view_layer
    view.objects.active = arm
    try:
        arm.select_set(True)
    except Exception:
        pass
    if arm.mode == mode:
        return
    with bpy.context.temp_override(
        active_object=arm,
        object=arm,
        selected_objects=[arm],
        selected_editable_objects=[arm],
    ):
        bpy.ops.object.mode_set(mode=mode)


def align_eyes_rig_to_target(
    eyes_rig: bpy.types.Object,
    target_arm: bpy.types.Object,
    head_bone: str,
    eye_l_bone: str,
    eye_r_bone: str,
):
    """对齐 Eyes/Face 中的眼控骨骼到目标 頭 / 目.L / 目.R。

    - MCH-eyes_root：头尾对齐頭（静置=姿态，避免自定义形状相对编辑骨偏移）
    - MCH-eye_L/R：完全复制目骨方向（供目骨 Damped Track 静止零输出）
    - CTL-eyes / L / R：纯 −Y 正朝前；与目骨同高；L/R 与对应目骨同 X（同范例）
    """
    head_b = target_arm.data.bones.get(head_bone)
    eye_l_b = target_arm.data.bones.get(eye_l_bone)
    eye_r_b = target_arm.data.bones.get(eye_r_bone)
    if not head_b or not eye_l_b or not eye_r_b:
        raise RuntimeError("align_eyes_rig_to_target: missing head/eye bones on target")

    required = (
        "MCH-eyes_root",
        "MCH-eye_L",
        "MCH-eye_R",
        "CTL-eyes",
        "CTL-eye_L",
        "CTL-eye_R",
    )
    for name in required:
        if name not in eyes_rig.data.bones:
            raise RuntimeError(f"Eyes_Rig missing bone: {name}")

    root_h, root_t = _bone_head_tail_in_rig_space(target_arm, head_b, eyes_rig)
    l_h, l_t = _bone_head_tail_in_rig_space(target_arm, eye_l_b, eyes_rig)
    r_h, r_t = _bone_head_tail_in_rig_space(target_arm, eye_r_b, eyes_rig)

    view = bpy.context.view_layer
    prev_active = view.objects.active
    prev_mode = eyes_rig.mode if eyes_rig == prev_active else "OBJECT"

    _mode_set_armature(eyes_rig, "EDIT")
    ebones = eyes_rig.data.edit_bones

    # 頭 → MCH-eyes_root（必须与頭一致，否则 Copy Transforms 造成 rest/pose 错位）
    _set_edit_bone(ebones["MCH-eyes_root"], root_h, root_t)
    # 目.L/R → MCH-eye_L/R（完整方向 + 镜像 roll）
    _align_mch_eye_from_mmd(ebones["MCH-eye_L"], l_h, l_t, Vector((0.0, 0.0, 1.0)))
    _align_mch_eye_from_mmd(ebones["MCH-eye_R"], r_h, r_t, Vector((0.0, 0.0, -1.0)))

    # 范例放置：与目骨同高；主控在两眼中点前方；L/R 与对应目骨同 X
    mid_x = 0.5 * (l_h.x + r_h.x)
    mid_y = 0.5 * (l_h.y + r_h.y)
    mid_z = 0.5 * (l_h.z + r_h.z)
    ctl_y = mid_y - _CTRL_FORWARD_OFFSET
    _place_ctrl_pure_y(ebones["CTL-eyes"], mid_x, ctl_y, mid_z)
    _place_ctrl_pure_y(ebones["CTL-eye_L"], l_h.x, ctl_y, mid_z)
    _place_ctrl_pure_y(ebones["CTL-eye_R"], r_h.x, ctl_y, mid_z)

    _mode_set_armature(eyes_rig, "OBJECT")
    adapt_eyes_ctrl_custom_shapes(eyes_rig)

    if prev_active and prev_active.name in bpy.data.objects:
        view.objects.active = prev_active
        if prev_mode not in ("OBJECT", "EDIT") and prev_active.type == "ARMATURE":
            try:
                _mode_set_armature(prev_active, prev_mode)
            except Exception:
                pass


def refine_mch_eyes_after_bind(
    eyes_rig: bpy.types.Object,
    target_arm: bpy.types.Object,
    eye_l_bone: str,
    eye_r_bone: str,
    *,
    max_iters: int = 12,
    angle_eps_deg: float = 0.05,
):
    """绑定「眼控追踪」后微调 MCH-eye，使目骨静止朝向回到自然 rest。

    MCH-eye 自身还有指向 CTL 的 Damped Track(0.5)，会把姿态朝向拉偏；
    在编辑模式迭代补偿 rest，直到目骨追踪后的 Y 与静音追踪时一致。
    """
    import math

    pairs = ((eye_l_bone, "MCH-eye_L"), (eye_r_bone, "MCH-eye_R"))
    for eye_name, mch_name in pairs:
        if eye_name not in target_arm.pose.bones or mch_name not in eyes_rig.pose.bones:
            return

    def _y_dir(arm: bpy.types.Object, name: str) -> Vector:
        pb = arm.pose.bones[name]
        return (arm.matrix_world @ pb.matrix).to_3x3() @ Vector((0.0, 1.0, 0.0))

    def _pose_ht(arm: bpy.types.Object, name: str) -> tuple[Vector, Vector, float]:
        pb = arm.pose.bones[name]
        mw = arm.matrix_world @ pb.matrix
        h = mw.translation.copy()
        y = mw.to_3x3() @ Vector((0.0, 1.0, 0.0))
        ln = float(arm.data.bones[name].length)
        return h, h + y * ln, ln

    track_cons = []
    for eye_name, _mch in pairs:
        pb = target_arm.pose.bones[eye_name]
        for c in pb.constraints:
            if c.type == "DAMPED_TRACK" and c.name == "眼控追踪":
                track_cons.append(c)
                c.mute = True
    bpy.context.view_layer.update()

    natural: dict[str, tuple[Vector, Vector, float]] = {}
    for eye_name, mch_name in pairs:
        h, _t, ln = _pose_ht(target_arm, eye_name)
        y = _y_dir(target_arm, eye_name)
        natural[mch_name] = (h, y, ln)

    for c in track_cons:
        c.mute = False
    bpy.context.view_layer.update()

    inv3 = eyes_rig.matrix_world.inverted().to_3x3()
    view = bpy.context.view_layer
    prev_active = view.objects.active
    eps = math.radians(angle_eps_deg)

    for _ in range(max_iters):
        bpy.context.view_layer.update()
        # 在 OBJECT 下采集误差与当前 MCH 姿态
        corrections: list[tuple[str, Vector, Vector, float]] = []
        max_ang = 0.0
        for eye_name, mch_name in pairs:
            act = _y_dir(target_arm, eye_name)
            eh, ey, ln = natural[mch_name]
            ang = act.angle(ey)
            max_ang = max(max_ang, ang)
            if ang < eps:
                continue
            mh, mt, _mln = _pose_ht(eyes_rig, mch_name)
            err_h = eh - mh
            err_t = (eh + ey * ln) - mt
            corrections.append((mch_name, err_h, err_t, ln))
        if max_ang < eps or not corrections:
            break

        _mode_set_armature(eyes_rig, "EDIT")
        ebones = eyes_rig.data.edit_bones
        for mch_name, err_h, err_t, ln in corrections:
            e = ebones[mch_name]
            e.head = Vector(e.head) + inv3 @ err_h
            e.tail = Vector(e.tail) + inv3 @ (err_t + err_h)
            axis = e.tail - e.head
            if axis.length > 1e-8:
                e.tail = e.head + axis.normalized() * ln
            e.align_roll(
                Vector((0.0, 0.0, 1.0))
                if mch_name.endswith("_L")
                else Vector((0.0, 0.0, -1.0))
            )
        _mode_set_armature(eyes_rig, "OBJECT")

    if prev_active and prev_active.name in bpy.data.objects:
        view.objects.active = prev_active


def ensure_collection(name: str) -> bpy.types.Collection:
    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(col)
    return col


def move_to_collection(obj: bpy.types.Object, col: bpy.types.Collection):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    if obj.name not in col.objects:
        col.objects.link(obj)
